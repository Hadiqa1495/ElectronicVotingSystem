﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace EVS_VoteCastingPanel.Helper
{
    class Validation
    {       

        public bool ValidateEmail(string emailAddress)
        {
            string regexPattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$";
            Match matches = Regex.Match(emailAddress, regexPattern);
            return matches.Success;
        }

        public bool ValidateText(string text)
        {
            string regexPattern = @"^[A-Za-z ]*$";
            Match matches = Regex.Match(text, regexPattern);
            return matches.Success;
        }

        public bool ValidateNumeric(string text)
        {
            string regexPattern = @"^[0-9]*$";
            Match matches = Regex.Match(text, regexPattern);
            return matches.Success;
        }

        public bool ValidateAlphaNumeric(string text)
        {
            string regexPattern = @"^[0-9A-Za-z ]*$";
            Match matches = Regex.Match(text, regexPattern);
            return matches.Success;
        }

        public bool ValidateDate(string date)
        {
            try
            {
                DateTime dob = DateTime.Parse(date);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public int calculateAge(string birthDate)
        {
            DateTime dob = DateTime.Parse(birthDate);
            TimeSpan tm = (DateTime.Now - dob);
            int age = (tm.Days / 365);
            return age;
        }
    }
}
