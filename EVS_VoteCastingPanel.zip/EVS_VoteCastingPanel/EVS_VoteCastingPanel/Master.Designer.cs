﻿namespace EVS_VoteCastingPanel
{
    partial class Master
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.voterIdentificationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.biometricReaderSelectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shutdownToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Green;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.voterIdentificationToolStripMenuItem,
            this.biometricReaderSelectionToolStripMenuItem,
            this.logoutToolStripMenuItem,
            this.shutdownToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1582, 58);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // voterIdentificationToolStripMenuItem
            // 
            this.voterIdentificationToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.voterIdentificationToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.voterIdentificationToolStripMenuItem.Margin = new System.Windows.Forms.Padding(50, 10, 50, 10);
            this.voterIdentificationToolStripMenuItem.Name = "voterIdentificationToolStripMenuItem";
            this.voterIdentificationToolStripMenuItem.Padding = new System.Windows.Forms.Padding(50, 0, 50, 0);
            this.voterIdentificationToolStripMenuItem.Size = new System.Drawing.Size(319, 34);
            this.voterIdentificationToolStripMenuItem.Text = "Voter Identification";
            this.voterIdentificationToolStripMenuItem.Click += new System.EventHandler(this.voterIdentificationToolStripMenuItem_Click);
            // 
            // biometricReaderSelectionToolStripMenuItem
            // 
            this.biometricReaderSelectionToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.biometricReaderSelectionToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.biometricReaderSelectionToolStripMenuItem.Margin = new System.Windows.Forms.Padding(50, 10, 50, 10);
            this.biometricReaderSelectionToolStripMenuItem.Name = "biometricReaderSelectionToolStripMenuItem";
            this.biometricReaderSelectionToolStripMenuItem.Padding = new System.Windows.Forms.Padding(50, 0, 50, 0);
            this.biometricReaderSelectionToolStripMenuItem.Size = new System.Drawing.Size(395, 34);
            this.biometricReaderSelectionToolStripMenuItem.Text = "Biometric Reader Selection";
            this.biometricReaderSelectionToolStripMenuItem.Click += new System.EventHandler(this.biometricReaderSelectionToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.logoutToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.logoutToolStripMenuItem.Margin = new System.Windows.Forms.Padding(50, 10, 50, 10);
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Padding = new System.Windows.Forms.Padding(50, 0, 50, 0);
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(190, 34);
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click_1);
            // 
            // shutdownToolStripMenuItem
            // 
            this.shutdownToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.shutdownToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.shutdownToolStripMenuItem.Margin = new System.Windows.Forms.Padding(50, 10, 50, 10);
            this.shutdownToolStripMenuItem.Name = "shutdownToolStripMenuItem";
            this.shutdownToolStripMenuItem.Padding = new System.Windows.Forms.Padding(50, 0, 50, 0);
            this.shutdownToolStripMenuItem.Size = new System.Drawing.Size(222, 34);
            this.shutdownToolStripMenuItem.Text = "Shutdown";
            this.shutdownToolStripMenuItem.Click += new System.EventHandler(this.shutdownToolStripMenuItem_Click_1);
            // 
            // Master
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGreen;
            this.BackgroundImage = global::EVS_VoteCastingPanel.Properties.Resources.Screenshot__280_1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1582, 853);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Master";
            this.Text = "Master";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Master_FormClosing);
            this.Load += new System.EventHandler(this.Master_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem voterIdentificationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem biometricReaderSelectionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shutdownToolStripMenuItem;

    }
}