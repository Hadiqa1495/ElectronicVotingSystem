﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EVS_VoteCastingPanel.DataAccess
{
    class UtilitiesModel
    {
        public string GetVotersCount()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Get_VotersCount";
            // execute the stored procedure and return the results

            return GenericDataAccess.ExecuteScalar(comm);
        }

        public DataTable GetVoters()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Voter";
            // execute the stored procedure and return the results

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetcandidatesByVoterId(int voterId, int electionId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Candidate_ByVoterId";
            // execute the stored procedure and return the results

            DbParameter ElectionTypeId = comm.CreateParameter();
            ElectionTypeId.ParameterName = "@electionId";
            ElectionTypeId.Value = electionId;
            ElectionTypeId.DbType = DbType.Int32;
            comm.Parameters.Add(ElectionTypeId);

            DbParameter VoterId = comm.CreateParameter();
            VoterId.ParameterName = "@voterId";
            VoterId.Value = voterId;
            VoterId.DbType = DbType.Int32;
            comm.Parameters.Add(VoterId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public bool CastVote(int voterId, int candidateId, int electionId)
        {

            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_InsertInto_Vote";

            // execute the stored procedure and return the results
            DbParameter vote_CandidateId = comm.CreateParameter();
            vote_CandidateId.ParameterName = "@vote_CandidateId";
            vote_CandidateId.Value = candidateId;
            vote_CandidateId.DbType = DbType.String;
            vote_CandidateId.Size = 50;
            comm.Parameters.Add(vote_CandidateId);

            DbParameter vote_VoterId = comm.CreateParameter();
            vote_VoterId.ParameterName = "@vote_VoterId";
            vote_VoterId.Value = voterId;
            vote_VoterId.DbType = DbType.String;
            vote_VoterId.Size = 50;
            comm.Parameters.Add(vote_VoterId);

            DbParameter vote_ElectionId = comm.CreateParameter();
            vote_ElectionId.ParameterName = "@vote_ElectionId";
            vote_ElectionId.Value = electionId;
            vote_ElectionId.DbType = DbType.String;
            vote_ElectionId.Size = 50;
            comm.Parameters.Add(vote_ElectionId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public DataTable ValidateVoterVote(int voterId, int electionId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_CustomValidator_Vote";
            // execute the stored procedure and return the results

            DbParameter vote_VoterId = comm.CreateParameter();
            vote_VoterId.ParameterName = "@vote_VoterId";
            vote_VoterId.Value = voterId;
            vote_VoterId.DbType = DbType.String;
            vote_VoterId.Size = 50;
            comm.Parameters.Add(vote_VoterId);

            DbParameter vote_ElectionId = comm.CreateParameter();
            vote_ElectionId.ParameterName = "@vote_ElectionId";
            vote_ElectionId.Value = electionId;
            vote_ElectionId.DbType = DbType.String;
            vote_ElectionId.Size = 50;
            comm.Parameters.Add(vote_ElectionId);

            return GenericDataAccess.ExecuteReader(comm);
        }
    }
}
