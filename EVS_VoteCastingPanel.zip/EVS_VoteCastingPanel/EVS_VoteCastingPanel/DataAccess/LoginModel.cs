﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace EVS_VoteCastingPanel.DataAccess
{
    class LoginModel
    {
        public DataTable GetElectionType()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_ElectionType";

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetElection(int electionTypeId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Election_ByElectionTypeId";

            DbParameter ElectionTypeId = comm.CreateParameter();
            ElectionTypeId.ParameterName = "@etId";
            ElectionTypeId.Value = electionTypeId;
            ElectionTypeId.DbType = DbType.Int32;
            comm.Parameters.Add(ElectionTypeId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetMemberByLoginInfo(int RoleId, string UserName, string Password)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_ByLoginInfo_Member";

            DbParameter roleid = comm.CreateParameter();
            roleid.ParameterName = "@member_RoleId";
            roleid.Value = RoleId;
            roleid.DbType = DbType.Int32;
            comm.Parameters.Add(roleid);

            DbParameter userName = comm.CreateParameter();
            userName.ParameterName = "@member_Username";
            userName.Value = UserName;
            userName.DbType = DbType.String;
            userName.Size = 50;
            comm.Parameters.Add(userName);

            DbParameter password = comm.CreateParameter();
            password.ParameterName = "@member_Password";
            password.Value = Password;
            password.DbType = DbType.String;
            password.Size = 50;
            comm.Parameters.Add(password);
            // execute the stored procedure and return the results

            return GenericDataAccess.ExecuteReader(comm);
        }

        public string GetMd5Hash(string input)
        {
            using (MD5 md5Hash = MD5.Create())
            {
                // Convert the input string to a byte array and compute the hash.
                byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(input));

                // Create a new Stringbuilder to collect the bytes
                // and create a string.
                StringBuilder sBuilder = new StringBuilder();

                // Loop through each byte of the hashed data 
                // and format each one as a hexadecimal string.
                for (int i = 0; i < data.Length; i++)
                {
                    sBuilder.Append(data[i].ToString("x2"));
                }

                // Return the hexadecimal string.
                return sBuilder.ToString();
            }
        }
    }
}
