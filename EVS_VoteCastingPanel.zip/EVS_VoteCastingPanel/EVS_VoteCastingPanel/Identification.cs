﻿using DPUruNet;
using EVS_VoteCastingPanel.DataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EVS_VoteCastingPanel
{
    public partial class Identification : Master
    {
        public Identification(int elecId)
        {
            InitializeComponent();
            electionId = elecId;
        }

        private const int DPFJ_PROBABILITY_ONE = 0x7fffffff;
        private Fmd anyFinger;

        private int count = 0;
        private bool matchesfound = false;
        private bool voteCasted = false;
        private UtilitiesModel obj = new UtilitiesModel();

        /// <summary>
        /// Initialize the form.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Identification_Load(object sender, System.EventArgs e)
        {
            if (CurrentReader.Description != null)
            {
                txtIdentify.Text = string.Empty;
                anyFinger = null;
                count = 0;

                SendMessage(Action.SendMessage, "Place your right thumb finger on the reader.");
                txtIdentify.ForeColor = System.Drawing.Color.Black;
                SendMessage(Action.SendMessage, "Try " + (count + 1) + "!");

                if (!OpenReader())
                {
                    this.Close();
                }

                if (!StartCaptureAsync(this.OnCaptured))
                {
                    this.Close();
                }
            }
            else
            {
                if (_readerSelection == null)
                {
                    _readerSelection = new ReaderSelection();
                    _readerSelection.Sender = this;
                }
                this.Hide();
                _readerSelection.ShowDialog();

                _readerSelection.Dispose();
                _readerSelection = null;
            }
            
        }

        /// <summary>
        /// Handler for when a fingerprint is captured.
        /// </summary>
        /// <param name="captureResult">contains info and data on the fingerprint capture</param>
        private void OnCaptured(CaptureResult captureResult)
        {

            if (count <= 2)
            {
                try
                {
                    // Check capture quality and throw an error if bad.
                    if (!CheckCaptureResult(captureResult)) return;

                    txtIdentify.ForeColor = System.Drawing.Color.Black;
                    SendMessage(Action.SendMessage, "A finger was captured.");

                    DataResult<Fmd> resultConversion = FeatureExtraction.CreateFmdFromFid(captureResult.Data, Constants.Formats.Fmd.ANSI);
                    if (captureResult.ResultCode != Constants.ResultCode.DP_SUCCESS)
                    {
                        Reset = true;
                        throw new Exception(captureResult.ResultCode.ToString());
                    }

                    anyFinger = resultConversion.Data;

                    //get Voters Thumbs 
                    int votersCount = int.Parse(obj.GetVotersCount());
                    Fmd[] fmds = new Fmd[votersCount];

                    tblVoter = new DataTable();
                    tblVoter = obj.GetVoters();
                    if (tblVoter.Rows.Count > 0)
                    {
                        int i = 0;
                        foreach (DataRow dr in tblVoter.Rows)
                        {
                            string fingerPrint = dr["voter_ThumbImpression"].ToString();
                            fmds[i] = Fmd.DeserializeXml(fingerPrint);
                            ++i;
                        }
                    }
                    //get Voters Thumbs 

                    // See the SDK documentation for an explanation on threshold scores.
                    int thresholdScore = DPFJ_PROBABILITY_ONE * 1 / 100000;

                    IdentifyResult identifyResult = Comparison.Identify(anyFinger, 0, fmds, thresholdScore, 4);
                    if (identifyResult.ResultCode != Constants.ResultCode.DP_SUCCESS)
                    {
                        Reset = true;
                        throw new Exception(identifyResult.ResultCode.ToString());
                    }

                    if (identifyResult.Indexes.Length.Equals(0))
                    {
                        txtIdentify.ForeColor = System.Drawing.Color.Red;
                        SendMessage(Action.SendMessage, "No match found! \r\n\r\n");
                        if ((count) < 2)
                        {
                            SendMessage(Action.SendMessage, "Try " + (count + 2) + "! \n");
                        }
                    }
                    else
                    {
                        txtIdentify.ForeColor = System.Drawing.Color.Green;
                        SendMessage(Action.SendMessage, "Match found! \r\n\r\n");
                        //identifyResult.Indexes.Length.ToString()
                    }
                    //If number of matches were greater than 0
                    if (identifyResult.Indexes.Length > 0)
                    {
                        matchesfound = true;

                        //for each matched fmd get its index and map that index to userid index
                        for (int i = 0; i < identifyResult.Indexes.Length; i++)
                        {
                            int index = identifyResult.Indexes[i][0];
                            if (i >= 0)
                            {
                                voterId = int.Parse(tblVoter.Rows[index]["voter_Id"].ToString());

                                DataTable tblVote = obj.ValidateVoterVote(voterId, electionId);
                                if (tblVote.Rows.Count > 0)
                                {
                                    voteCasted = true;
                                    MessageBox.Show("Your vote has been casted already!");
                                }
                                else
                                {
                                    voteCasted = false;
                                }
                            }
                        }
                    }
                    else
                    {
                        matchesfound = false;
                    }
                }
                catch (Exception ex)
                {
                    //Send error message, then close form
                    SendMessage(Action.SendMessage, "Error:  " + ex.Message);
                }

            }
            else
            {
                txtIdentify.ForeColor = System.Drawing.Color.Red;
                SendMessage(Action.SendMessage, "Cannot try more than thrice!");
            }
            count++;

        }

        /// <summary>
        /// Close window.
        /// </summary>
        private void Identification_Closed(object sender, System.EventArgs e)
        {
            CancelCaptureAndCloseReader(this.OnCaptured);
        }

        #region SendMessage
        private enum Action
        {
            SendMessage
        }
        private delegate void SendMessageCallback(Action action, string payload);
        private void SendMessage(Action action, string payload)
        {
            try
            {
                if (this.txtIdentify.InvokeRequired)
                {
                    SendMessageCallback d = new SendMessageCallback(SendMessage);
                    this.Invoke(d, new object[] { action, payload });
                }
                else
                {
                    switch (action)
                    {
                        case Action.SendMessage:
                            txtIdentify.Text += payload + "\r\n\r\n";
                            txtIdentify.SelectionStart = txtIdentify.TextLength;
                            txtIdentify.ScrollToCaret();
                            break;
                    }
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion

        private void btnBack_Click(object sender, EventArgs e)
        {
            if (voteCasted == false && matchesfound == true)
            {
                CastVote castVote = null;
                if (castVote == null)
                {
                    castVote = new CastVote(electionId, voterId);
                    CurrentReader.Dispose();
                    CurrentReader = null;
                }
                this.Hide();
                castVote.ShowDialog();

                castVote.Dispose();
                castVote = null;
            }
            else if(voteCasted==true||matchesfound==false)
            {
                Identification identification = null;
                if (identification == null)
                {
                    identification = new Identification(electionId);
                    CurrentReader.Dispose();
                    CurrentReader = null;
                }
                this.Hide();
                identification.ShowDialog();

                identification.Dispose();
                identification = null;
            }
        }


    }
}
