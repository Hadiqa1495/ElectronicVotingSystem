﻿using DPCtlUruNet;
using DPUruNet;
using EVS_VoteCastingPanel.Helper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EVS_VoteCastingPanel
{
    public partial class Master : Form
    {
        protected FingerprintReader objReader = new FingerprintReader();
        protected ReaderSelection _readerSelection;
        protected DataTable tblVoter;

        protected Reader _reader;
        public Reader CurrentReader
        {
            get { return _reader; }
            set { _reader = value; }
        }

        // Holds fmds enrolled by the enrollment GUI.
        protected Dictionary<int, Fmd> fmds = new Dictionary<int, Fmd>();
        public Dictionary<int, Fmd> Fmds
        {
            get { return fmds; }
            set { fmds = value; }
        }

        private int election_id;
        private int voter_id;

        public int voterId
        {
            get
            {
                return voter_id;
            }
            set
            {
                voter_id = value;
            }
        }

        public int electionId
        {
            get
            {
                return election_id;
            }
            set
            {
                election_id = value;
            }
        }

        public Master()
        {
            InitializeComponent();
        }

        private void Master_Load(object sender, EventArgs e)
        {
            if (objReader.getReaders() == null)
            {
                if (_readerSelection == null)
                {
                    _readerSelection = new ReaderSelection();
                    _readerSelection.Sender = this;
                }
                _readerSelection.ShowDialog();

                _readerSelection.Dispose();
                _readerSelection = null;
            }
            else
            {
                CurrentReader = objReader.getReaders();
            }
        }

        /// <summary>
        /// Reset the UI causing the user to reselect a reader.
        /// </summary>
        public bool Reset
        {
            get { return reset; }
            set { reset = value; }
        }
        private bool reset;

        /// <summary>
        /// Open a device and check result for errors.
        /// </summary>
        /// <returns>Returns true if successful; false if unsuccessful</returns>
        public bool OpenReader()
        {
            reset = false;
            Constants.ResultCode result = Constants.ResultCode.DP_DEVICE_FAILURE;

            // Open reader
            result = CurrentReader.Open(Constants.CapturePriority.DP_PRIORITY_COOPERATIVE);

            if (result != Constants.ResultCode.DP_SUCCESS)
            {
                MessageBox.Show("Error:  " + result);
                reset = true;
                return false;
            }

            return true;
        }

        /// <summary>
        /// Hookup capture handler and start capture.
        /// </summary>
        /// <param name="OnCaptured">Delegate to hookup as handler of the On_Captured event</param>
        /// <returns>Returns true if successful; false if unsuccessful</returns>
        public bool StartCaptureAsync(Reader.CaptureCallback OnCaptured)
        {
            // Activate capture handler
            CurrentReader.On_Captured += new Reader.CaptureCallback(OnCaptured);

            // Call capture
            if (!CaptureFingerAsync())
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Function to capture a finger. Always get status first and calibrate or wait if necessary.  Always check status and capture errors.
        /// </summary>
        /// <param name="fid"></param>
        /// <returns></returns>
        public bool CaptureFingerAsync()
        {
            try
            {
                GetStatus();

                Constants.ResultCode captureResult = CurrentReader.CaptureAsync(Constants.Formats.Fid.ANSI, Constants.CaptureProcessing.DP_IMG_PROC_DEFAULT, CurrentReader.Capabilities.Resolutions[0]);
                if (captureResult != Constants.ResultCode.DP_SUCCESS)
                {
                    reset = true;
                    throw new Exception("" + captureResult);
                }

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:  " + ex.Message);
                return false;
            }
        }

        /// <summary>
        /// Check the device status before starting capture.
        /// </summary>
        /// <returns></returns>
        public void GetStatus()
        {
            Constants.ResultCode result = CurrentReader.GetStatus();

            if ((result != Constants.ResultCode.DP_SUCCESS))
            {
                reset = true;
                throw new Exception("" + result);
            }

            if ((CurrentReader.Status.Status == Constants.ReaderStatuses.DP_STATUS_BUSY))
            {
                Thread.Sleep(50);
            }
            else if ((CurrentReader.Status.Status == Constants.ReaderStatuses.DP_STATUS_NEED_CALIBRATION))
            {
                CurrentReader.Calibrate();
            }
            else if ((CurrentReader.Status.Status != Constants.ReaderStatuses.DP_STATUS_READY))
            {
                throw new Exception("Reader Status - " + CurrentReader.Status.Status);
            }
        }

        /// <summary>
        /// Check quality of the resulting capture.
        /// </summary>
        public bool CheckCaptureResult(CaptureResult captureResult)
        {
            if (captureResult.Data == null)
            {
                if (captureResult.ResultCode != Constants.ResultCode.DP_SUCCESS)
                {
                    reset = true;
                    throw new Exception(captureResult.ResultCode.ToString());
                }

                // Send message if quality shows fake finger
                if ((captureResult.Quality != Constants.CaptureQuality.DP_QUALITY_CANCELED))
                {
                    throw new Exception("Quality - " + captureResult.Quality);
                }
                return false;
            }

            return true;
        }

        /// <summary>
        /// Cancel the capture and then close the reader.
        /// </summary>
        /// <param name="OnCaptured">Delegate to unhook as handler of the On_Captured event </param>
        public void CancelCaptureAndCloseReader(Reader.CaptureCallback OnCaptured)
        {
            if (CurrentReader != null)
            {
                // Dispose of reader handle and unhook reader events.
                CurrentReader.Dispose();

                if (reset)
                {
                    CurrentReader = null;
                }
            }
        }

        private Identification _identification;

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Login form = new Login();
            form.Show();
            this.Hide();
        }

        private void shutdownToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CausesValidation = false;
            foreach (Control control in this.Controls)
            {
                control.CausesValidation = false;
            }
            Application.Exit();
        }

        Identification identificationControl;
        private void voterIdentificationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (identificationControl == null)
            {
                identificationControl = new Identification(electionId);
                CurrentReader.Dispose();
                CurrentReader = null;
            }
            this.Hide();
            identificationControl.ShowDialog();

            identificationControl.Dispose();
            identificationControl = null;
        }

        private void biometricReaderSelectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_readerSelection == null)
            {
                _readerSelection = new ReaderSelection();
                _readerSelection.Sender = this;
            }
            _readerSelection.ShowDialog();

            _readerSelection.Dispose();
            _readerSelection = null;
        }

        private void logoutToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            CurrentReader.Dispose();
            CurrentReader = null;
            Login form = new Login();
            form.Show();
            this.Hide();
        }

        private void shutdownToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            CausesValidation = false;
            foreach (Control control in this.Controls)
            {
                control.CausesValidation = false;
            }
            Application.Exit();
        }

        private void Master_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = false;
        }
    }
}