﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EVS_VoteCastingPanel.DataAccess;
using System.IO;
namespace EVS_VoteCastingPanel
{
    public partial class CastVote : Master
    {
        private DataTable tblCandidates;
        UtilitiesModel obj = new UtilitiesModel();

        public CastVote(int elecId, int currVoterId)
        {
            InitializeComponent();
            electionId = elecId;
            voterId = currVoterId;
        }

        private void BindCandidates()
        {
            tblCandidates = obj.GetcandidatesByVoterId(voterId, electionId);
            if (tblCandidates.Rows.Count > 0)
            {
                DataView view = new DataView(tblCandidates);
                DataTable tblSeat = view.ToTable(true, "seatType_Id", "seatType_Name");
                int x = 0; int y = 0; int width = 0;
                if (tblSeat.Rows.Count == 2)
                {
                    x = 100;
                    y = 100;
                    width = 500;
                }
                else
                {
                    x = 20;
                    y = 100;
                    width = 400;
                }
                for (int i = 0; i < tblSeat.Rows.Count; i++)
                {
                    GroupBox gbox = new GroupBox();
                    gbox.AutoSize = true;
                    gbox.Height = 400;
                    int seatType = int.Parse(tblSeat.Rows[i]["seatType_Id"].ToString());
                    gbox.Text = tblSeat.Rows[i]["seatType_Name"].ToString();
                    gbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));

                    if (tblSeat.Rows.Count == 2)
                    {
                        gbox.Width = width;
                        gbox.Location = new Point(x, y);
                        x = x + width + 200;
                    }
                    else
                    {
                        gbox.Width = width;
                        gbox.Location = new Point(x, y);
                        x = x + width + 100;
                    }
                    panel1.Controls.Add(gbox);

                    int X = 50;
                    int Y = 50;
                    foreach (DataRow dr in tblCandidates.Rows)
                    {
                        if (int.Parse(dr["seatType_Id"].ToString()) == seatType)
                        {
                            PictureBox pbox = new PictureBox();
                            byte[] imgData = new byte[0];
                            imgData = (byte[])dr["symbol_ImageContent"];
                            MemoryStream imgStream = new MemoryStream(imgData);
                            pbox.Image = Image.FromStream(imgStream);
                            pbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
                            pbox.SizeMode = PictureBoxSizeMode.StretchImage;
                            pbox.Size = new System.Drawing.Size(150, 150);
                            pbox.Location = new Point(X, Y);
                            gbox.Controls.Add(pbox);

                            Label lbl2 = new Label();
                            lbl2.Text = dr["voter_FirstName"].ToString();
                            lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                            lbl2.Location = new Point(X + 170, Y);
                            lbl2.Width = width - 170 - 100;
                            gbox.Controls.Add(lbl2);
                            Label lbl3 = new Label();
                            lbl3.Text = dr["voter_LastName"].ToString();
                            lbl3.Location = new Point(X + 170, Y + 50);
                            lbl3.Width = width - 170 - 100;
                            lbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                            gbox.Controls.Add(lbl3);
                            RadioButton rBtn = new RadioButton();
                            rBtn.Text = dr["candidate_Id"].ToString();
                            rBtn.ForeColor = System.Drawing.Color.LightGreen;
                            rBtn.Location = new Point(width, Y);
                            gbox.Controls.Add(rBtn);
                            Y += 200;
                        }
                    }
                }
            }
            panel1.Height = panel1.Height + 100;
            btn.Location = new Point(700, (panel1.Height - 100));
        }

        private void CastVote_Load(object sender, EventArgs e)
        {
            BindCandidates();
        }

        Identification identificationControl;
        private void btn_Click(object sender, EventArgs e)
        {
            bool VoteCasted = false;

            foreach (Control pageControls in this.panel1.Controls)
            {
                if (pageControls is GroupBox)
                {
                    VoteCasted = false;
                    foreach (Control control in pageControls.Controls)
                    {
                        if (control is RadioButton)
                        {
                            RadioButton radio = control as RadioButton;
                            if (radio.Checked)
                            {
                                VoteCasted = true;
                                break;
                            }
                            else
                            {
                                VoteCasted = false;

                            }
                        }
                    }
                }
            }

            if (VoteCasted == false)
            {
                MessageBox.Show("Please cast all votes!");
            }
            else
            {
                int[] candidateId = new int[5];
                int i = 0;

                foreach (Control pageControls in this.panel1.Controls)
                {
                    if (pageControls is GroupBox)
                    {
                        foreach (Control control in pageControls.Controls)
                        {
                            if (control is RadioButton)
                            {
                                RadioButton radio = control as RadioButton;
                                if (radio.Checked)
                                {
                                    candidateId[i] = int.Parse(radio.Text);
                                    i++;
                                }
                            }
                        }
                    }
                }
                Array.Resize(ref candidateId, i);
                bool success = false;
                foreach (int candidate in candidateId)
                {
                    success = obj.CastVote(voterId, candidate, electionId);
                    if (!success)
                    {
                        break;
                    }
                }
                if (success)
                {
                    MessageBox.Show("Vote casted successfully!");
                }
                else
                {
                    MessageBox.Show("Sorry failed to cast vote!");
                }

                if (identificationControl == null)
                {
                    identificationControl = new Identification(electionId);
                    CurrentReader.Dispose();
                    CurrentReader = null;
                }
                this.Hide();
                identificationControl.ShowDialog();

                identificationControl.Dispose();
                identificationControl = null;
            }
        }

        private void btn_Validating(object sender, CancelEventArgs e)
        {
            DataTable tblVote = obj.ValidateVoterVote(voterId, electionId);
            if (tblVote.Rows.Count > 0)
            {
                e.Cancel = true;
                err.SetError(btn, "Your vote has been casted already!");

            }
            else
            {
                e.Cancel = false;
                err.SetError(btn, "");
            }
        }

    }
}
