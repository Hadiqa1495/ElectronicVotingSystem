﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EVS_VoteCastingPanel.DataAccess;
using System.Text.RegularExpressions;

namespace EVS_VoteCastingPanel
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            BindElectionType();
        }

        private void comboBoxET_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindElection();
        }
        
        Identification identificationControl;
        private void button1_Click(object sender, EventArgs e)
        {
            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                LoginModel objLogin=new LoginModel();
                string username = txtName.Text;
                string pwd = txtPassword.Text;
                string hash = objLogin.GetMd5Hash(pwd);
                int role = 2;
                DataTable success = objLogin.GetMemberByLoginInfo(role, username, hash);
                if (success.Rows.Count > 0)
                {
                    int electionId = int.Parse(comboBoxE.SelectedValue.ToString());

                    if (identificationControl == null)
                    {
                        identificationControl = new Identification(electionId);
                    }
                    this.Hide();
                    identificationControl.ShowDialog();

                    identificationControl.Dispose();
                    identificationControl = null;
                }
                else
                {
                    label5.Text = "Invalid username or password!";
                }
            } 
        }

        private void comboBoxE_Validating(object sender, CancelEventArgs e)
        {
            if (comboBoxE.SelectedValue.ToString() == "0")
            {
                e.Cancel = true;
                errElection.SetError(comboBoxE, "Invalid Selected Value!");
            }
            else
            {
                e.Cancel = false;
                errElection.SetError(comboBoxE, "");
            }
        }

        private void txtName_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                e.Cancel = true;
                errUsername.SetError(txtName, "Username should not be left blank!");
            }
            else if(!ValidateEmail(txtName.Text))
            {
                e.Cancel = true;
                errUsername.SetError(txtName, "Enter valid email!");         
            }
            else
            {
                e.Cancel = false;
                errUsername.SetError(txtName, "");
            }
        }

        private void textBox2_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                e.Cancel = true;
                errPassword.SetError(txtPassword, "Password should not be left blank!");
            }
            else
            {
                e.Cancel = false;
                errPassword.SetError(txtPassword, "");
            }
        }

        private void BindElectionType()
        {
            LoginModel objElection = new LoginModel();
            DataTable electype = objElection.GetElectionType();
            if (electype.Rows.Count > 0)
            {
                comboBoxET.DataSource = electype;
                comboBoxET.DisplayMember = "electionType_Name";
                comboBoxET.ValueMember = "electionType_Id";
            }

            BindElection();
        }

        private void BindElection()
        {
            try
            {
                LoginModel objElection = new LoginModel();
                int elecTypeId = int.Parse(comboBoxET.SelectedValue.ToString());
                comboBoxE.DataSource = null;
                DataTable elec = objElection.GetElection(elecTypeId);
                if (elec.Rows.Count > 0)
                {
                    comboBoxE.DataSource = elec;
                    comboBoxE.DisplayMember = "election_Day";
                    comboBoxE.ValueMember = "election_Id";
                }
                else
                {
                    Dictionary<int, string> item = new Dictionary<int, string>();
                    item.Add(0, "No results found!");
                    comboBoxE.DataSource = new BindingSource(item, null);
                    comboBoxE.DisplayMember = "Value";
                    comboBoxE.ValueMember = "Key";
                    comboBoxE.SelectedIndex = 0;
                }
            }
            catch
            {

            }
        }

        private bool ValidateEmail(string emailAddress)
        {
            string regexPattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$";
            Match matches = Regex.Match(emailAddress, regexPattern);
            return matches.Success;
        }

        private void btnShutdown_Click(object sender, EventArgs e)
        {
            CausesValidation = false;
            errElection.Clear();
            errUsername.Clear();
            errPassword.Clear();
            Application.Exit();
        }

        private void Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = false;
        }
    }
}
