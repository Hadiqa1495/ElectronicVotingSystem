﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Data;
using System.Net;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class SMS : System.Web.UI.Page
    {
        AdministrativeUnitModel objAdminUnit = new AdministrativeUnitModel();
        DistrictModel objDistrict = new DistrictModel();
        VoterModel objVoter = new VoterModel();
        SMSModel objSMS = new SMSModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (ddlAdminUnit.Items.Count > 0)
                {
                    DataTable tblAdminUnit = objAdminUnit.GetAdminUnit();
                    ViewState["tblAdminUnit"] = tblAdminUnit;
                    ddlAdminUnit.DataSource = tblAdminUnit;
                    ddlAdminUnit.DataValueField = "administrativeUnit_Id";
                    ddlAdminUnit.DataTextField = "administrativeUnit_Name";
                    ddlAdminUnit.DataBind();
                }
            }
        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
            int dist = int.Parse(ddlDistrict.SelectedValue);
            DataTable tblVoter = objSMS.GetPollingStationVoter(dist);

            DataView view = new DataView(tblVoter);
            DataTable tblPS = view.ToTable(true, "pollingStation");
            for (int i = 0; i < tblVoter.Rows.Count; i++)
            {
                hfVoter.Value = tblVoter.Rows[i]["voter_Id"].ToString();
                string MyUsername = "923206227460"; //Your Username At Lifetimesms.com
                string MyPassword = "4382"; //Your Password At Lifetimesms.com
                string senderNumber = "EVS"; //Your Company Brand Name
                string toNumber = tblVoter.Rows[i]["voter_Mobile"].ToString(); //Your cell phone number with country code
                string txt = " ";
                for (int j = 0; j < tblPS.Rows.Count; j++)
                {
                    txt = txt + (j + 1) + ". " + tblVoter.Rows[j]["pollingStation"].ToString() + "<br/>";
                }
                //String URI = "http://Lifetimesms.com" +
                // "/plain?" +
                // "username=" + MyUsername +
                // "&password=" + MyPassword +
                // "&from=" + senderNumber +
                // "&to=" + toNumber +
                // "&message=" + Uri.UnescapeDataString(txt);
                String URI = "http://sendpk.com/api/sms.php?" +
                 "username=" + MyUsername +
                 "&password=" + MyPassword +
                 "&sender=Masking" +
                 "&mobile=" + toNumber +
                 "&message=" + Uri.UnescapeDataString(txt);
                //"&message=" + System.Net.WebUtility.UrlEncode(MessageText);// Visual Studio 12

                try
                {
                    WebRequest req = WebRequest.Create(URI);
                    WebResponse resp = req.GetResponse();
                    lblMessage.Text = "SMS sent successfully.";
                    lblMessage.CssClass = "label label-success";
                }
                catch (WebException ex)
                {
                    lblMessage.Text = "Sorry! Failed to Send SMS";
                    lblMessage.CssClass = "label label-warning";
                }
                break;
            }
        }

        protected void ddlAdminUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.Clear();
            ListItem first = new ListItem("Select District", "0");
            ddlDistrict.Items.Add(first);
            ddlDistrict.Items.FindByValue("0").Selected = true;
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int adminUnit = int.Parse(ddlAdminUnit.SelectedValue);
            DataTable tblDistrict = objDistrict.GetDistrictByAdminUnit(adminUnit);
            if (tblDistrict.Rows.Count > 0)
            {
                ddlDistrict.DataSource = tblDistrict;
                ddlDistrict.DataValueField = tblDistrict.Columns["district_Id"].ToString();
                ddlDistrict.DataTextField = tblDistrict.Columns["district_Name"].ToString();
                ddlDistrict.DataBind();
            }
        }
    }
}