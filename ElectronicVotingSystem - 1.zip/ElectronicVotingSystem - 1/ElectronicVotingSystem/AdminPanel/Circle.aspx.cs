﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class Circle : System.Web.UI.Page
    {
        AdministrativeUnitModel objAdminUnit = new AdministrativeUnitModel();
        DistrictModel objDistrict = new DistrictModel();
        TehsilModel objTehsil = new TehsilModel();
        ChargeModel objCharge = new ChargeModel();
        CircleModel objCircle = new CircleModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (ddlAdminUnit.Items.Count > 0)
                {
                    DataTable tblAdminUnit = objAdminUnit.GetAdminUnit();
                    ddlAdminUnit.DataSource = tblAdminUnit;
                    ddlAdminUnit.DataValueField = tblAdminUnit.Columns["administrativeUnit_Id"].ToString();
                    ddlAdminUnit.DataTextField = tblAdminUnit.Columns["administrativeUnit_Name"].ToString();
                    ddlAdminUnit.DataBind();
                }
            }
        }

        protected void ddlAdminUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.Clear();
            ListItem first = new ListItem("Select District", "0");
            ddlDistrict.Items.Add(first);
            ddlDistrict.Items.FindByValue("0").Selected = true;
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlTehsil.Items.Clear();
            first = new ListItem("Select Tehsil", "0");
            ddlTehsil.Items.Add(first);
            ddlTehsil.Items.FindByValue("0").Selected = true;
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlCharge.Items.Clear();
            first = new ListItem("Select Charge", "0");
            ddlCharge.Items.Add(first);
            ddlCharge.Items.FindByValue("0").Selected = true;
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            gvCircle.Visible = false;
            pnlHeading.Visible = false;

            int adminUnit = int.Parse(ddlAdminUnit.SelectedValue);
            DataTable tblDistrict = objDistrict.GetDistrictByAdminUnit(adminUnit);
            if (tblDistrict.Rows.Count > 0)
            {
                ddlDistrict.DataSource = tblDistrict;
                ddlDistrict.DataValueField = tblDistrict.Columns["district_Id"].ToString();
                ddlDistrict.DataTextField = tblDistrict.Columns["district_Name"].ToString();
                ddlDistrict.DataBind();
            }
        }

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlTehsil.Items.Clear();
            ListItem first = new ListItem("Select Tehsil", "0");
            ddlTehsil.Items.Add(first);
            ddlTehsil.Items.FindByValue("0").Selected = true;
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlCharge.Items.Clear();
            first = new ListItem("Select Charge", "0");
            ddlCharge.Items.Add(first);
            ddlCharge.Items.FindByValue("0").Selected = true;
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvCircle.Visible = false;
            pnlHeading.Visible = false;

            int distId = int.Parse(ddlDistrict.SelectedValue);
            DataTable tblTehsil = objTehsil.GetTehsilByDistrictId(distId);
            if (tblTehsil.Rows.Count > 0)
            {
                ddlTehsil.DataSource = tblTehsil;
                ddlTehsil.DataValueField = tblTehsil.Columns["tehsil_Id"].ToString();
                ddlTehsil.DataTextField = tblTehsil.Columns["tehsil_Name"].ToString();
                ddlTehsil.DataBind();
            }
        }

        protected void ddlTehsil_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlCharge.Items.Clear();
            ListItem first = new ListItem("Select Charge", "0");
            ddlCharge.Items.Add(first);
            ddlCharge.Items.FindByValue("0").Selected = true;
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvCircle.Visible = false;
            pnlHeading.Visible = false;

            ddlCharge.Items.Clear();
            first = new ListItem("Select Charge", "0");
            ddlCharge.Items.Add(first);
            ddlCharge.Items.FindByValue("0").Selected = true;
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int tehsilId = int.Parse(ddlTehsil.SelectedValue);
            DataTable tblCharge = objCharge.GetChargeByTehsilId(tehsilId);
            if (tblCharge.Rows.Count > 0)
            {
                ddlCharge.DataSource = tblCharge;
                ddlCharge.DataValueField = tblCharge.Columns["charge_Id"].ToString();
                ddlCharge.DataTextField = tblCharge.Columns["charge_Name"].ToString();
                ddlCharge.DataBind();
            }
        }

        protected void ddlCharge_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int chargeId = int.Parse(ddlCharge.SelectedValue);
            DataTable tblCircle = objCircle.GetCircleByChargeId(chargeId);
            ViewState["tblCircle"] = tblCircle;
            if (tblCircle.Rows.Count > 0)
            {
                pnlHeading.Visible = true;
                gvCircle.Visible = true;
                gvCircle.DataSource = tblCircle;
                gvCircle.DataBind();
            }
            else
            {
                pnlHeading.Visible = false;
                gvCircle.Visible = false;
            }
        }

        protected void cv_ServerValidate(object source, ServerValidateEventArgs args)
        {
            int chargeId = int.Parse(ddlCharge.SelectedValue);
            string name = txtName.Text;
            DataTable unitExist = objCircle.GetCircleByNameChargeId(name, chargeId);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void btn_Click(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            if (Page.IsValid)
            {
                int chargeId = int.Parse(ddlCharge.SelectedValue);
                string name = txtName.Text;
                bool success = objCircle.SaveCircle(name, chargeId);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "Circle added successfully.";
                    lblMsg.CssClass = "label label-success";
                    txtName.Text = "";

                    gvCircle.Visible = true;
                    chargeId = int.Parse(ddlCharge.SelectedValue);
                    DataTable tblCircle = objCircle.GetCircleByChargeId(chargeId);
                    ViewState["tblCircle"] = tblCircle;
                    gvCircle.DataSource = ViewState["tblCircle"];
                    gvCircle.DataBind();
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to add circle.";
                    lblMsg.CssClass = "label label-warning";
                }
            }
        }

        protected void cv_ServerValidate1(object source, ServerValidateEventArgs args)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            string Name = args.Value;
            GridViewRow gvr = (GridViewRow)((CustomValidator)source).Parent.Parent;
            int index = gvr.RowIndex;
            int Id = int.Parse(((HiddenField)gvCircle.Rows[index].FindControl("hfId")).Value);
            int chargeId = int.Parse(ddlCharge.SelectedValue);

            DataTable unitExist = objCircle.GetCircleByIdNameChargeId(Id, Name, chargeId);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void gvCircle_RowEditing(object sender, GridViewEditEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvCircle.EditIndex = e.NewEditIndex;
            gvCircle.DataSource = ViewState["tblCircle"];
            gvCircle.DataBind();
        }

        protected void gvCircle_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvCircle.EditIndex = -1;
            gvCircle.DataSource = ViewState["tblCircle"];
            gvCircle.DataBind();
        }

        protected void gvCircle_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            if (Page.IsValid)
            {
                int id = int.Parse(((HiddenField)gvCircle.Rows[e.RowIndex].FindControl("hfId")).Value);
                string name = ((TextBox)gvCircle.Rows[e.RowIndex].FindControl("txtName")).Text;
                int chargeId = int.Parse(ddlCharge.SelectedValue);
                Boolean success = objCircle.UpdateCircle(id, name, chargeId);

                gvCircle.EditIndex = -1;
                chargeId = int.Parse(ddlCharge.SelectedValue);
                DataTable tblCircle = objCircle.GetCircleByChargeId(chargeId);
                ViewState["tblCircle"] = tblCircle;
                gvCircle.DataSource = ViewState["tblCircle"];
                gvCircle.DataBind();
            }
        }

        protected void gvCircle_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int id = int.Parse(((HiddenField)gvCircle.Rows[e.RowIndex].FindControl("hfId")).Value);
            objCircle.DeleteCircle(id);

            gvCircle.EditIndex = -1;
            int chargeId = int.Parse(ddlCharge.SelectedValue);
            DataTable tblCircle = objCircle.GetCircleByChargeId(chargeId);
            ViewState["tblCircle"] = tblCircle;
            gvCircle.DataSource = ViewState["tblCircle"];
            gvCircle.DataBind();
        }

        protected void gvCircle_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvCircle.PageIndex = e.NewPageIndex;
            gvCircle.DataSource = ViewState["tblCircle"];
            gvCircle.DataBind();
        }
    }
}