﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Data;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class LocalGovernmentResult : System.Web.UI.Page
    {
        ResultModel objResult = new ResultModel();
        private int electionId;
        private int districtId;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["id"] != null)
                {
                    electionId = int.Parse(Request.QueryString["id"]);

                    linkParty.NavigateUrl = "PartyResultDetail.aspx?elecId=" + electionId;
                    ResultModel objResult = new ResultModel();

                    DataTable tblParty = objResult.GetPartyWinnersLGProvincially(electionId);
                    if (tblParty.Rows.Count > 0)
                    {
                        GvParty.DataSource = tblParty;
                        GvParty.DataBind();
                    }

                    string voteCount = objResult.GetVoteCount(electionId);
                    lblVoteCount.Text = voteCount;

                    DistrictModel objDist = new DistrictModel();
                    DataTable tblDistrict = objDist.GetDistrictByElectionId(electionId);
                    DataSet ds = new DataSet();
                    ds.Tables.Add(tblDistrict);
                    if (tblDistrict.Rows.Count > 0)
                    {
                        MyAccordion.DataSource = ds.Tables[0].DefaultView;
                        MyAccordion.DataBind();
                    }
                }
            }
        }

        protected void MyAccordion_ItemDataBound(object sender, AjaxControlToolkit.AccordionItemEventArgs e)
        {
            if (e.ItemType == AjaxControlToolkit.AccordionItemType.Content)
            {
                AjaxControlToolkit.Accordion rpt = (AjaxControlToolkit.Accordion)e.AccordionItem.FindControl("AccRptLGCons");
                HiddenField hf = (HiddenField)e.AccordionItem.FindControl("hfDist");
                districtId = int.Parse(hf.Value);
                ConstituencyModel objCons = new ConstituencyModel();
                DataTable tblLGCons = objCons.GETLGConstituencyByDistrictElection(districtId, electionId);
                DataSet ds = new DataSet();
                ds.Tables.Add(tblLGCons);
                if (tblLGCons.Rows.Count > 0)
                {
                    rpt.DataSource = ds.Tables[0].DefaultView;
                    rpt.DataBind();
                }
            }
        }

        protected void AccRptLGCons_ItemDataBound(object sender, AjaxControlToolkit.AccordionItemEventArgs e)
        {
            if (e.ItemType == AjaxControlToolkit.AccordionItemType.Content)
            {
                Repeater rpt = (Repeater)e.AccordionItem.FindControl("rptA");
                HiddenField hf = (HiddenField)e.AccordionItem.FindControl("hfCons");
                int LGCons = int.Parse(hf.Value);
                DataTable tblNAResult = objResult.GetLocalGovernmentElectionWinners(electionId, districtId, LGCons);
                if (tblNAResult.Rows.Count > 0)
                {
                    rpt.DataSource = tblNAResult;
                    rpt.DataBind();
                }
            }
        }
    }
}