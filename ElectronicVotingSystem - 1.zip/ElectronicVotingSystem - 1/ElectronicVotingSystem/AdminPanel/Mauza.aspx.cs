﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class Mauza : System.Web.UI.Page
    {
        AdministrativeUnitModel objAdminUnit = new AdministrativeUnitModel();
        DistrictModel objDistrict = new DistrictModel();
        TehsilModel objTehsil = new TehsilModel();
        MauzaModel objMauza = new MauzaModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (ddlAdminUnit.Items.Count > 0)
                {
                    DataTable tblAdminUnit = objAdminUnit.GetAdminUnit();
                    ddlAdminUnit.DataSource = tblAdminUnit;
                    ddlAdminUnit.DataValueField = tblAdminUnit.Columns["administrativeUnit_Id"].ToString();
                    ddlAdminUnit.DataTextField = tblAdminUnit.Columns["administrativeUnit_Name"].ToString();
                    ddlAdminUnit.DataBind();
                }
            }
        }

        protected void ddlAdminUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.Clear();
            ListItem first = new ListItem("Select District", "0");
            ddlDistrict.Items.Add(first);
            ddlDistrict.Items.FindByValue("0").Selected = true;
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlTehsil.Items.Clear();
            first = new ListItem("Select Tehsil", "0");
            ddlTehsil.Items.Add(first);
            ddlTehsil.Items.FindByValue("0").Selected = true;
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvMauza.Visible = false;
            pnlHeading.Visible = false;

            int adminUnit = int.Parse(ddlAdminUnit.SelectedValue);
            DataTable tblDistrict = objDistrict.GetDistrictByAdminUnit(adminUnit);
            if (tblDistrict.Rows.Count > 0)
            {
                ddlDistrict.DataSource = tblDistrict;
                ddlDistrict.DataValueField = tblDistrict.Columns["district_Id"].ToString();
                ddlDistrict.DataTextField = tblDistrict.Columns["district_Name"].ToString();
                ddlDistrict.DataBind();
            }
        }

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlTehsil.Items.Clear();
            ListItem first = new ListItem("Select Tehsil", "0");
            ddlTehsil.Items.Add(first);
            ddlTehsil.Items.FindByValue("0").Selected = true;
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvMauza.Visible = false;
            pnlHeading.Visible = false;

            int distId = int.Parse(ddlDistrict.SelectedValue);
            DataTable tblTehsil = objTehsil.GetTehsilByDistrictId(distId);
            if (tblTehsil.Rows.Count > 0)
            {
                ddlTehsil.DataSource = tblTehsil;
                ddlTehsil.DataValueField = tblTehsil.Columns["tehsil_Id"].ToString();
                ddlTehsil.DataTextField = tblTehsil.Columns["tehsil_Name"].ToString();
                ddlTehsil.DataBind();
            }
        }

        protected void ddlTehsil_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int tehsilId = int.Parse(ddlTehsil.SelectedValue);
            DataTable tblMauza = objMauza.GetMauzaByTehsilId(tehsilId);
            ViewState["tblMauza"] = tblMauza;
            if (tblMauza.Rows.Count > 0)
            {
                gvMauza.Visible = true;
                pnlHeading.Visible = true;
                gvMauza.DataSource = tblMauza;
                gvMauza.DataBind();
            }
            else
            {
                gvMauza.Visible = false;
                pnlHeading.Visible = false;
            }
        }

        protected void cv_ServerValidate(object source, ServerValidateEventArgs args)
        {
            int tehsilId = int.Parse(ddlTehsil.SelectedValue);
            string name = txtName.Text;
            DataTable unitExist = objMauza.GetMauzaByNameTehsilId(name, tehsilId);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void btnTehsil_Click(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            if (Page.IsValid)
            {
                int tehsilId = int.Parse(ddlTehsil.SelectedValue);
                string name = txtName.Text;
                bool success = objMauza.SaveMauza(name, tehsilId);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "Electoral Area added successfully.";
                    lblMsg.CssClass = "label label-success";
                    txtName.Text = "";

                    tehsilId = int.Parse(ddlTehsil.SelectedValue);
                    DataTable tblMauza = objMauza.GetMauzaByTehsilId(tehsilId);
                    ViewState["tblMauza"] = tblMauza;
                    if (tblMauza.Rows.Count > 0)
                    {
                        gvMauza.Visible = true;
                        gvMauza.DataSource = tblMauza;
                        gvMauza.DataBind();
                    }
                    else
                    {
                        gvMauza.Visible = false;
                    }

                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to add electoral area.";
                    lblMsg.CssClass = "label label-warning";
                }
            }
        }

        protected void cv_ServerValidate1(object source, ServerValidateEventArgs args)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            string Name = args.Value;
            GridViewRow gvr = (GridViewRow)((CustomValidator)source).Parent.Parent;
            int index = gvr.RowIndex;
            int Id = int.Parse(((HiddenField)gvMauza.Rows[index].FindControl("hfId")).Value);
            int tehsilId = int.Parse(ddlTehsil.SelectedValue);
            DataTable unitExist = objMauza.GetMauzaByIdNameTehsilId(Id, Name, tehsilId);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void gvMauza_RowEditing(object sender, GridViewEditEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvMauza.EditIndex = e.NewEditIndex;
            gvMauza.DataSource = ViewState["tblMauza"];
            gvMauza.DataBind();
        }

        protected void gvMauza_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvMauza.EditIndex = -1;
            gvMauza.DataSource = ViewState["tblMauza"];
            gvMauza.DataBind();
        }

        protected void gvMauza_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            if (Page.IsValid)
            {
                int id = int.Parse(((HiddenField)gvMauza.Rows[e.RowIndex].FindControl("hfId")).Value);
                string name = ((TextBox)gvMauza.Rows[e.RowIndex].FindControl("txtName")).Text;
                int tehsilId = int.Parse(ddlTehsil.SelectedValue);
                Boolean success = objMauza.UpdateMauza(id, name, tehsilId);
                if (success)
                {
                    lblMsg.Text = "Electoral area updated successfully!";
                    lblMsg.CssClass = "label label-success";
                    txtName.Text = "";
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to update electoral area.";
                    lblMsg.CssClass = "label label-warning";
                }

                gvMauza.EditIndex = -1;
                tehsilId = int.Parse(ddlTehsil.SelectedValue);
                DataTable tblMauza = objMauza.GetMauzaByTehsilId(tehsilId);
                if (tblMauza.Rows.Count > 0)
                {
                    gvMauza.Visible = true;
                    ViewState["tblMauza"] = tblMauza;
                    gvMauza.DataSource = ViewState["tblMauza"];
                    gvMauza.DataBind();
                }
                else
                {
                    gvMauza.Visible = false;
                }
            }
        }

        protected void gvMauza_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int id = int.Parse(((HiddenField)gvMauza.Rows[e.RowIndex].FindControl("hfId")).Value);
            Boolean success = objMauza.DeleteMauza(id);
            if (success)
            {
                lblMsg.Text = "Electoral area deleted successfully.";
                lblMsg.CssClass = "label label-success";
                txtName.Text = "";
            }
            else
            {
                lblMsg.Text = "Sorry! Failed to delete electoral area.";
                lblMsg.CssClass = "label label-warning";
            }

            gvMauza.EditIndex = -1;
            int tehsilId = int.Parse(ddlTehsil.SelectedValue);
            DataTable tblMauza = objMauza.GetMauzaByTehsilId(tehsilId);
            if (tblMauza.Rows.Count > 0)
            {
                gvMauza.Visible = true;
                ViewState["tblMauza"] = tblMauza;
                gvMauza.DataSource = ViewState["tblMauza"];
                gvMauza.DataBind();
            }
            else
            {
                gvMauza.Visible = false;
            }
        }

        protected void gvMauza_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvMauza.PageIndex = e.NewPageIndex;
            gvMauza.DataSource = ViewState["tblMauza"];
            gvMauza.DataBind();
        }
    }
}