﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class SearchPollingStation : System.Web.UI.Page
    {
        PollingStationModel objPollingStation = new PollingStationModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataTable tblPollingStation = objPollingStation.GetPollingStation();
                ViewState["tblPollingStation"] = tblPollingStation;
                if (tblPollingStation.Rows.Count > 0)
                {
                    lblMsg.Visible = false;
                    gvPollingStation.Visible = true;
                    gvPollingStation.DataSource = tblPollingStation;
                    gvPollingStation.DataBind();
                    lblMsg.Text = "";
                }
                else
                {
                    lblMsg.Visible = true;
                    lblMsg.Text = "Sorry !!! No Record Exists.";
                    lblMsg.CssClass = "label label-warning";
                    gvPollingStation.Visible = false;
                }
            }
        }

        protected void gvPollingStation_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvPollingStation.PageIndex = e.NewPageIndex;
            gvPollingStation.DataSource = ViewState["tblPollingStation"];
            gvPollingStation.DataBind();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string search = txtSearch.Text;
            if (search != null)
            {
                DataTable tblPollingStation = objPollingStation.GetPollingStationReport(search);
                ViewState["tblPollingStation"] = tblPollingStation;
                if (tblPollingStation.Rows.Count > 0)
                {
                    lblMsg.Visible = false;
                    gvPollingStation.Visible = true;
                    gvPollingStation.DataSource = tblPollingStation;
                    gvPollingStation.DataBind();
                    lblMsg.Text = "";
                }
                else
                {
                    lblMsg.Visible = true;
                    lblMsg.Text = "Sorry !!! No Record Found.";
                    lblMsg.CssClass = "label label-warning";
                    gvPollingStation.Visible = false;
                }
            }
        }
    }
}