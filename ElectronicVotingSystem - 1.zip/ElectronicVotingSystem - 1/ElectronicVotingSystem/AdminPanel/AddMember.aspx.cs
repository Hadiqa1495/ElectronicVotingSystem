﻿using ElectronicVotingSystem.DataAccess;
using ElectronicVotingSystem.AdminPanel.UserControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class AddMember : System.Web.UI.Page
    {
        int index;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                index = 2;
                ViewState["controls"] = index;
            }
        }

        protected void btnSignup_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                ucAddMember addMember = ((ucAddMember)upAddMember1.FindControl("addMember1"));
                int roleId = int.Parse(((DropDownList)(((ucMemberList)addMember.FindControl("ucMemberList1")).FindControl("ddlMember"))).SelectedValue);
                string firstName = ((TextBox)addMember.FindControl("txtFirstName")).Text;
                string lastName = ((TextBox)addMember.FindControl("txtLastName")).Text;
                string email = ((TextBox)addMember.FindControl("txtEmail")).Text;
                string password = ((TextBox)addMember.FindControl("txtPassword")).Text;
                string hashPassword = Utilities.GetMd5Hash(password);
                // Execute the insert command
                bool success = MemberModel.SaveMember(roleId, firstName, lastName, email, hashPassword);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "Account created successfully.";
                    lblMsg.CssClass = "label label-success";
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to create account.";
                    lblMsg.CssClass = "label label-warning";
                }
            }
        }
    }
}