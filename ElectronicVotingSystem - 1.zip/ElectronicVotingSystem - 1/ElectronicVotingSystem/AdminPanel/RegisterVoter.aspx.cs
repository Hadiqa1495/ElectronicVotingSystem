﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class RegisterVoter : System.Web.UI.Page
    {
        AdministrativeUnitModel objAdminUnit = new AdministrativeUnitModel();
        DistrictModel objDistrict = new DistrictModel();
        TehsilModel objTehsil = new TehsilModel();
        MauzaModel objMauza = new MauzaModel();
        BlockModel objBlock = new BlockModel();
        VoterModel objVoter = new VoterModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (ddlAdminUnit.Items.Count > 0)
                {
                    DataTable tblAdminUnit = objAdminUnit.GetAdminUnit();
                    ViewState["tblAdminUnit"] = tblAdminUnit;
                    ddlAdminUnit.DataSource = tblAdminUnit;
                    ddlAdminUnit.DataValueField = "administrativeUnit_Id";
                    ddlAdminUnit.DataTextField = "administrativeUnit_Name";
                    ddlAdminUnit.DataBind();
                }
            }
            else
            {
                ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                ddlMauza.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                ddlBlock.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            }
        }

        protected void ddlAdminUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            clearDistrictList(); clearTehsilList(); clearMauzaList(); clearBlockList();

            int adminUnit = int.Parse(ddlAdminUnit.SelectedValue);
            DataTable tblDistrict = objDistrict.GetDistrictByAdminUnit(adminUnit);
            if (tblDistrict.Rows.Count > 0)
            {
                ddlDistrict.DataSource = tblDistrict;
                ddlDistrict.DataValueField = tblDistrict.Columns["district_Id"].ToString();
                ddlDistrict.DataTextField = tblDistrict.Columns["district_Name"].ToString();
                ddlDistrict.DataBind();
            }
        }

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            clearTehsilList(); clearMauzaList(); clearBlockList();

            int distId = int.Parse(ddlDistrict.SelectedValue);
            DataTable tblTehsil = objTehsil.GetTehsilByDistrictId(distId);
            if (tblTehsil.Rows.Count > 0)
            {
                ddlTehsil.DataSource = tblTehsil;
                ddlTehsil.DataValueField = tblTehsil.Columns["tehsil_Id"].ToString();
                ddlTehsil.DataTextField = tblTehsil.Columns["tehsil_Name"].ToString();
                ddlTehsil.DataBind();
            }
        }

        protected void ddlTehsil_SelectedIndexChanged(object sender, EventArgs e)
        {
            clearMauzaList(); clearBlockList();

            int tehsilId = int.Parse(ddlTehsil.SelectedValue);
            DataTable tblMauza = objMauza.GetMauzaByTehsilId(tehsilId);

            if (tblMauza.Rows.Count > 0)
            {
                ddlMauza.DataSource = tblMauza;
                ddlMauza.DataValueField = tblMauza.Columns["mauza_Id"].ToString();
                ddlMauza.DataTextField = tblMauza.Columns["mauza_Name"].ToString();
                ddlMauza.DataBind();
            }
        }

        protected void ddlMauza_SelectedIndexChanged(object sender, EventArgs e)
        {
            clearBlockList();

            int mauzaId = int.Parse(ddlMauza.SelectedValue);
            DataTable tblBlock = objBlock.GetBlockByMauzaId(mauzaId);
            if (tblBlock.Rows.Count > 0)
            {
                ddlBlock.DataSource = tblBlock;
                ddlBlock.DataTextField = "block_Number";
                ddlBlock.DataValueField = "block_Id";
                ddlBlock.DataBind();
            }
        }

        protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
        {
            cvImage.Text = "";
            string fileExtension = System.IO.Path.GetExtension(fuImage.FileName);
            int fileSize = fuImage.PostedFile.ContentLength;
            if (fileExtension.ToLower() != ".jpg" && fileExtension.ToLower() != ".png" && fileExtension.ToLower() != ".jpeg")
            {
                cvImage.Text = cvImage.Text + "Only .jpg, .png and .jpeg are allowed.";
                args.IsValid = false;
            }
            else if (fileSize > 1024 * 1024)
            {
                cvImage.Text = cvImage.Text + "Image size (10KB) exceeded.";
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void CustomValidator2_ServerValidate(object source, ServerValidateEventArgs args)
        {
            string cnic = txtCnic.Text;
            DataTable unitExist = objVoter.GetVoterByCnic(cnic);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void btn_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                byte[] n_Image_Size = new byte[fuImage.PostedFile.ContentLength];
                HttpPostedFile Posted_Image = fuImage.PostedFile;
                Posted_Image.InputStream.Read(n_Image_Size, 0, (int)fuImage.PostedFile.ContentLength);
                string imgName = fuImage.PostedFile.FileName;

                string imageType = fuImage.PostedFile.ContentType;

                string fName = txtFirstName.Text;
                string lNAme = txtLastName.Text;
                DateTime dob = DateTime.Parse(txtDob.Text);
                string cnic = txtCnic.Text;
                string gender = rbGender.SelectedItem.Value;
                string religion = rblReligion.SelectedItem.Value;
                int house = int.Parse(txtHouse.Text);
                string street = txtStreet.Text;
                string mobile = txtMobile.Text;
                int blockId = int.Parse(ddlBlock.SelectedValue);
                bool success = objVoter.SaveVoter(fName, lNAme, dob, cnic, gender, religion, house, street, mobile, imgName,imageType, n_Image_Size, blockId);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "Voter added successfully!";
                    lblMsg.CssClass = "label label-success";
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to add voter.";
                    lblMsg.CssClass = "label label-warning";
                }
            }
        }

        private void clearDistrictList()
        {
            ddlDistrict.Items.Clear();
            ListItem first = new ListItem("Select District", "0");
            ddlDistrict.Items.Add(first);
            ddlDistrict.Items.FindByValue("0").Selected = true;
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
        }

        private void clearTehsilList()
        {
            ddlTehsil.Items.Clear();
            ListItem first = new ListItem("Select Tehsil", "0");
            ddlTehsil.Items.Add(first);
            ddlTehsil.Items.FindByValue("0").Selected = true;
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
        }

        private void clearMauzaList()
        {
            ddlMauza.Items.Clear();
            ListItem first = new ListItem("Select Electoral Area", "0");
            ddlMauza.Items.Add(first);
            ddlMauza.Items.FindByValue("0").Selected = true;
            ddlMauza.Items.FindByValue("0").Attributes.Add("style", "display:none;");
        }

        private void clearBlockList()
        {
            ddlBlock.Items.Clear();
            ListItem first = new ListItem("Select Block", "0");
            ddlBlock.Items.Add(first);
            ddlBlock.Items.FindByValue("0").Selected = true;
            ddlBlock.Items.FindByValue("0").Attributes.Add("style", "display:none;");
        }
    }
}