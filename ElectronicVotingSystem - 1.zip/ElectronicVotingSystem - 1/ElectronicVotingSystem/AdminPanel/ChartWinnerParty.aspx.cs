﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class ChartWinnerParty : System.Web.UI.Page
    {
        ElectionModel objElection = new ElectionModel();
        ChartsModel objChart = new ChartsModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindElectionType();
                BindElection();
            }
            int id = int.Parse(ddlElection.SelectedValue);

            DataTable dt = objChart.PartyVSSeatsWinByElectionType(id);

            chartVote.DataSource = dt;
            chartVote.Series[0].XValueMember = "party_Name";
            chartVote.Series[0].YValueMembers = "totalSeats";

            chartVote.DataBind();
            if (!IsPostBack)
            {
                BindElectionTypeA();
                BindElectionA();
                BindSeatType();
            }
            int idA = int.Parse(ddlElectionA.SelectedValue);
            string seat = (ddlSeat.SelectedItem).ToString();
            DataTable dtA = objChart.PartyVSSeatsWinBySeatType(idA, seat);

            chartParty.DataSource = dtA;
            chartParty.Series[0].XValueMember = "party_Name";
            chartParty.Series[0].YValueMembers = "result_SeatCount";

            chartParty.DataBind();
        }

        protected void ddlElection_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = int.Parse(ddlElection.SelectedValue);
            DataTable dt = objChart.PartyVSSeatsWinByElectionType(id);

            chartVote.DataSource = dt;
            chartVote.Series[0].XValueMember = "party_Name";
            chartVote.Series[0].YValueMembers = "totalSeats";

            chartVote.DataBind();
        }

        protected void ddlElectionType_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindElection();
        }

        private void BindElectionType()
        {
            DataTable tblElectionType = objElection.GetElectionType();
            ddlElectionType.DataSource = tblElectionType;
            ddlElectionType.DataTextField = tblElectionType.Columns["electionType_Name"].ToString();
            ddlElectionType.DataValueField = tblElectionType.Columns["electionType_Id"].ToString();
            ddlElectionType.DataBind();
        }

        private void BindElection()
        {
            ddlElection.Items.Clear();
            int etId = int.Parse(ddlElectionType.SelectedValue);
            DataTable tblElection = objElection.GetElectionFiltered(etId);
            if (tblElection.Rows.Count > 0)
            {
                tblElection.Columns.Add("Election", typeof(string), "election_StartingYear + ' ----- ' + election_EndingYear");
                ddlElection.DataSource = tblElection;
                ddlElection.DataTextField = "Election";
                ddlElection.DataValueField = "election_Id";
                ddlElection.DataBind();
            }
        }

        protected void ddlElection_SelectedIndexChangedA(object sender, EventArgs e)
        {
            int id = int.Parse(ddlElectionA.SelectedValue);

            string seat = (ddlSeat.SelectedValue).ToString();
            DataTable dt = objChart.PartyVSSeatsWinBySeatType(id, seat);

            chartParty.DataSource = dt;
            chartParty.Series[0].XValueMember = "party_Name";
            chartParty.Series[0].YValueMembers = "result_SeatCount";

            chartParty.DataBind();
        }

        protected void ddlElectionType_SelectedIndexChangedA(object sender, EventArgs e)
        {
            BindElectionA();
            BindSeatType();
        }

        private void BindElectionTypeA()
        {
            DataTable tblElectionType = objElection.GetElectionType();
            ddlElectionTypeA.DataSource = tblElectionType;
            ddlElectionTypeA.DataTextField = tblElectionType.Columns["electionType_Name"].ToString();
            ddlElectionTypeA.DataValueField = tblElectionType.Columns["electionType_Id"].ToString();
            ddlElectionTypeA.DataBind();
        }

        private void BindElectionA()
        {
            ddlElectionA.Items.Clear();
            int etId = int.Parse(ddlElectionTypeA.SelectedValue);
            DataTable tblElection = objElection.GetElectionFiltered(etId);
            if (tblElection.Rows.Count > 0)
            {
                tblElection.Columns.Add("Election", typeof(string), "election_StartingYear + ' ----- ' + election_EndingYear");
                ddlElectionA.DataSource = tblElection;
                ddlElectionA.DataTextField = "Election";
                ddlElectionA.DataValueField = "election_Id";
                ddlElectionA.DataBind();
            }
        }

        private void BindSeatType()
        {
            ddlSeat.Items.Clear();
            int etid = int.Parse(ddlElectionTypeA.SelectedValue);
            DataTable tblSeat = objChart.GetSeatType(etid);
            if (tblSeat.Rows.Count > 0)
            {
                ddlSeat.DataSource = tblSeat;
                ddlSeat.DataTextField = "seatType_Name";
                ddlSeat.DataValueField = "seatType_Name";
                ddlSeat.DataBind();
            }
        }

        protected void ddlSeat_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = int.Parse(ddlElectionA.SelectedValue);

            string seat = (ddlSeat.SelectedValue).ToString();
            DataTable dt = objChart.PartyVSSeatsWinBySeatType(id, seat);

            chartParty.DataSource = dt;
            chartParty.Series[0].XValueMember = "party_Name";
            chartParty.Series[0].YValueMembers = "result_SeatCount";

            chartParty.DataBind();
        }
    }
}