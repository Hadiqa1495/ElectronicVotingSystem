﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class WiseChairman : System.Web.UI.Page
    {
        ElectionModel objElection = new ElectionModel();
        AdministrativeUnitModel objAdminUnit = new AdministrativeUnitModel();
        DistrictModel objDistrict = new DistrictModel();
        ConstituencyModel objCons = new ConstituencyModel();
        SymbolModel objSymbol = new SymbolModel();
        PartyModel objParty = new PartyModel();
        VoterModel objVoter = new VoterModel();
        CandidateModel objCandidate = new CandidateModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                panelCandidate.Visible = false;
                lblSymbol.Visible = false;
                ddlSymbol.Visible = false;
                rfvSymbol.Enabled = false;
                ddlParty.Visible = true;
                rfvParty.Enabled = true;

                ddlUC.Visible = false;
                lblUC.Visible = false;

                BindElection();
                BindAdminUnit();
                BindParty();
                BindSymbol();
                BindLGCons();
            }
            else
            {
                ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                ddlParty.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                ddlSymbol.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                ddlUC.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                if (ddlLGCons.Items.Count != 0)
                {
                    ddlLGCons.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                }
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string cnic = txtSearch.Text;
            DataTable tblVoter = objVoter.GetVoterByCnic(cnic);
            if (tblVoter.Rows.Count > 0)
            {
                panelCandidate.Visible = true;

                imgVoter.ImageUrl = "DisplayVoterImage.ashx?imgId=" + tblVoter.Rows[0]["voter_CNIC"];
                //ViewState["img"] = tblVoter.Rows[0]["voter_Image"].ToString();
                hfVoter.Value = tblVoter.Rows[0]["voter_Id"].ToString();
                lblName.Text = tblVoter.Rows[0]["voter_FirstName"].ToString() + " " + tblVoter.Rows[0]["voter_LastName"].ToString();
                lblCnic.Text = tblVoter.Rows[0]["voter_CNIC"].ToString();
                lblMobile.Text = tblVoter.Rows[0]["voter_Mobile"].ToString();

            }
            else
            {
                panelCandidate.Visible = false;
                lblVoter.Text = "Please register your vote first!";
                lblVoter.CssClass = "label label-warning";
            }
        }

        protected void ddlAdminUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            gvBlock.Visible = false;
            pnlHeading.Visible = false;

            clearDistrictList();
            ClearLGCons();
            clearUCList();

            int adminUnit = int.Parse(ddlAdminUnit.SelectedValue);
            DataTable tblDistrict = objDistrict.GetDistrictByAdminUnit(adminUnit);
            if (tblDistrict.Rows.Count > 0)
            {
                ddlDistrict.DataSource = tblDistrict;
                ddlDistrict.DataValueField = tblDistrict.Columns["district_Id"].ToString();
                ddlDistrict.DataTextField = tblDistrict.Columns["district_Name"].ToString();
                ddlDistrict.DataBind();
            }
        }

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            gvBlock.Visible = false;
            pnlHeading.Visible = false;
            clearUCList();
            BindLGCons();
        }

        private void clearUCList()
        {
            ddlUC.Visible = false;
            rfvUC.Visible = false;
            lblUC.Visible = false;

            ddlUC.Items.Clear();
            ListItem first = new ListItem("Select Union Council", "0");
            ddlUC.Items.Add(first);
            ddlUC.Items.FindByValue("0").Selected = true;
            ddlUC.Items.FindByValue("0").Attributes.Add("style", "display:none;");
        }

        protected void rblParty_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (rblParty.SelectedValue == "Independent")
            {
                lblParty.Visible = false;
                ddlParty.Visible = false;
                rfvParty.Enabled = false;
                lblSymbol.Visible = true;
                ddlSymbol.Visible = true;
                rfvSymbol.Enabled = true;
                ddlSymbol.SelectedIndex = 0;
                ddlParty.SelectedIndex = 0;
            }
            else
            {
                lblSymbol.Visible = false;
                ddlSymbol.Visible = false;
                rfvSymbol.Enabled = false;
                lblParty.Visible = true;
                ddlParty.Visible = true;
                rfvParty.Enabled = true;
                ddlParty.SelectedIndex = 0;
                ddlSymbol.SelectedIndex = 0;
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                int constituency;
                if (ddlUC.Visible == true)
                {
                    constituency = int.Parse(ddlUC.SelectedValue);
                }
                else
                {
                    constituency = int.Parse(ddlLGCons.SelectedValue);
                }
                int voter = int.Parse(hfVoter.Value);

                int LGindex = ddlLGCons.SelectedIndex;
                DataTable tblLG = (DataTable)ViewState["tblLG"];
                int LGtype = int.Parse(tblLG.Rows[--LGindex]["constituency_ConstituencyTypeId"].ToString());
                int seatType;
                if (LGtype == 3)
                {
                    seatType = 4;
                }
                else if (LGtype == 4)
                {
                    seatType = 7;
                }
                else
                {
                    seatType = 10;
                }
                int symbolId;
                int partyId;
                symbolId = int.Parse(ddlSymbol.SelectedValue);
                partyId = int.Parse(ddlParty.SelectedValue);
                int elec = int.Parse(ddlElection.SelectedValue);
                bool success = objCandidate.SaveCandidate(voter, seatType, symbolId, elec, partyId, constituency);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "Candidate added successfully!";
                    lblMsg.CssClass = "label label-success";
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to add Candidate.";
                    lblMsg.CssClass = "label label-warning";
                }
                BindGridview();
            }
        }

        private void BindAdminUnit()
        {
            if (ddlAdminUnit.Items.Count > 0)
            {
                DataTable tblAdminUnit = objAdminUnit.GetAdminUnit();
                ViewState["tblAdminUnit"] = tblAdminUnit;
                ddlAdminUnit.DataSource = tblAdminUnit;
                ddlAdminUnit.DataValueField = "administrativeUnit_Id";
                ddlAdminUnit.DataTextField = "administrativeUnit_Name";
                ddlAdminUnit.DataBind();
            }
        }

        private void BindElection()
        {
            int electionTypeId = 15;
            if (ddlElection.Items.Count > 0)
            {
                DataTable tblElection = objElection.GetElection(electionTypeId);
                tblElection.Columns.Add("Election", typeof(string), "election_StartingYear + ' - ' + election_EndingYear");
                ViewState["tblElection"] = tblElection;
                ddlElection.DataSource = tblElection;
                ddlElection.DataValueField = "election_Id";
                ddlElection.DataTextField = "Election";
                ddlElection.DataBind();
            }
        }

        private void BindSymbol()
        {
            DataTable tblSymbol = objSymbol.GetSymbolFiltered();
            if (tblSymbol.Rows.Count > 0)
            {
                ddlSymbol.DataSource = tblSymbol;
                ddlSymbol.DataTextField = "symbol_Name";
                ddlSymbol.DataValueField = "symbol_Id";
                ddlSymbol.DataBind();
            }
        }

        private void BindParty()
        {
            DataTable tblParty = objParty.GetParty();
            if (tblParty.Rows.Count > 0)
            {
                ddlParty.DataSource = tblParty;
                ddlParty.DataTextField = "party_Name";
                ddlParty.DataValueField = "party_Id";
                ddlParty.DataBind();
            }
        }

        private void clearDistrictList()
        {
            ddlDistrict.Items.Clear();
            ListItem first = new ListItem("Select District", "0");
            ddlDistrict.Items.Add(first);
            ddlDistrict.Items.FindByValue("0").Selected = true;
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
        }

        private void ClearLGCons()
        {
            ddlLGCons.Items.Clear();
            ListItem first = new ListItem("Select Local Government Constituency", "0");
            ddlLGCons.Items.Add(first);
            ddlLGCons.Items.FindByValue("0").Selected = true;
            ddlLGCons.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            lblUC.Visible = false;
            ddlUC.Visible = false;
            rfvUC.Visible = false;
        }

        private void BindGridview()
        {
            int electId = int.Parse(ddlElection.SelectedValue);
            int constituency;
            if (ddlUC.Visible == true)
            {
                constituency = int.Parse(ddlUC.SelectedValue);
            }
            else
            {
                constituency = int.Parse(ddlLGCons.SelectedValue);
            }
            int LGindex = ddlLGCons.SelectedIndex;
            DataTable tblLG = (DataTable)ViewState["tblLG"];
            int LGtype = int.Parse(tblLG.Rows[--LGindex]["constituency_ConstituencyTypeId"].ToString());
            int seatType;
            if (LGtype == 3)
            {
                seatType = 4;
            }
            else if (LGtype == 4)
            {
                seatType = 7;
            }
            else
            {
                seatType = 10;
            }
            if (electId != 0 && constituency != 0 && seatType != 0)
            {

                DataTable tblCandidate = objCandidate.GetCandidateByElectionSeatType(electId, seatType, constituency);
                if (tblCandidate.Rows.Count > 0)
                {
                    gvBlock.Visible = true;
                    pnlHeading.Visible = true;
                    gvBlock.DataSource = tblCandidate;
                    ViewState["tblCandidate"] = tblCandidate;
                    gvBlock.DataBind();
                }
                else
                {
                    gvBlock.Visible = false;
                    pnlHeading.Visible = false;
                }
            }
        }

        protected void gvBlock_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = int.Parse(((HiddenField)gvBlock.Rows[e.RowIndex].FindControl("hfId")).Value);

            Boolean success = objCandidate.DeleteCandidate(id);
            gvBlock.EditIndex = -1;
            if (success)
            {
                lblMsg.Text = "Candidate deleted successfully!";
                lblMsg.CssClass = "label label-success";

                BindGridview();
            }
            else
            {
                lblMsg.Text = "Sorry! Failed to delete candidate.";
                lblMsg.CssClass = "label label-warning";
            }
        }

        private void BindUCList()
        {
            clearUCList();
            lblUC.Visible = true;
            ddlUC.Visible = true;
            rfvUC.Visible = true;

            int parentId = int.Parse(ddlLGCons.SelectedValue);


            gvBlock.Visible = false;

            DataTable tblUC = objCons.GetUCByLGCons(parentId);
            if (tblUC.Rows.Count > 0)
            {
                ddlUC.DataSource = tblUC;
                ddlUC.DataValueField = tblUC.Columns["constituency_Id"].ToString();
                ddlUC.DataTextField = tblUC.Columns["constituency_Name"].ToString();
                ddlUC.DataBind();
            }
        }

        private void BindLGCons()
        {
            if (int.Parse(ddlDistrict.SelectedValue) != 0)
            {
                ddlLGCons.Items.Clear();
                ListItem first = new ListItem("Select Local Government Constituency", "0");
                ddlLGCons.Items.Add(first);
                ddlLGCons.Items.FindByValue("0").Selected = true;
                ddlLGCons.Items.FindByValue("0").Attributes.Add("style", "display:none;");

                int distId = int.Parse(ddlDistrict.SelectedValue);
                if (ddlLGCons.Items.Count > 0)
                {
                    DataTable tblLG = objCons.GetConstituency(distId);
                    ddlLGCons.DataSource = tblLG;
                    ViewState["tblLG"] = tblLG;
                    ddlLGCons.DataTextField = tblLG.Columns["constituency_Name"].ToString();
                    ddlLGCons.DataValueField = tblLG.Columns["constituency_Id"].ToString();
                    ddlLGCons.DataBind();
                }
            }
        }

        protected void ddlLGCons_SelectedIndexChanged(object sender, EventArgs e)
        {
            gvBlock.Visible = false;
            pnlHeading.Visible = false;
            int LGindex = ddlLGCons.SelectedIndex;
            DataTable tblLG = (DataTable)ViewState["tblLG"];
            int LGtype = int.Parse(tblLG.Rows[--LGindex]["constituency_ConstituencyTypeId"].ToString());
            if (LGtype == 3 || LGtype == 4)
            {
                BindUCList();
            }
            else
            {
                clearUCList();
                BindGridview();
            }
        }

        protected void ddlUC_SelectedIndexChanged(object sender, EventArgs e)
        {
            gvBlock.Visible = false;
            pnlHeading.Visible = false;
            BindGridview();
        }

        protected void cv_ServerValidate(object source, ServerValidateEventArgs args)
        {
            int voter = int.Parse(hfVoter.Value);
            int electionId = int.Parse(ddlElection.SelectedValue);
            DataTable unitExist = objCandidate.GetCVCandidate(voter, electionId);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void cvParty_ServerValidate(object source, ServerValidateEventArgs args)
        {
            int constituency;
            if (ddlUC.Visible == true)
            {
                constituency = int.Parse(ddlUC.SelectedValue);
            }
            else
            {
                constituency = int.Parse(ddlLGCons.SelectedValue);
            }
            int LGindex = ddlLGCons.SelectedIndex;
            DataTable tblLG = (DataTable)ViewState["tblLG"];
            int LGtype = int.Parse(tblLG.Rows[--LGindex]["constituency_ConstituencyTypeId"].ToString());
            int seatType;
            if (LGtype == 3)
            {
                seatType = 4;
            }
            else if (LGtype == 4)
            {
                seatType = 7;
            }
            else
            {
                seatType = 10;
            }
            int symbolId = int.Parse(ddlSymbol.SelectedValue);
            int partyId = int.Parse(ddlParty.SelectedValue);
            int electionId = int.Parse(ddlElection.SelectedValue);
            DataTable unitExist = objCandidate.GetCVCandidateCons(constituency, electionId, symbolId, partyId, seatType);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void gvBlock_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvBlock.PageIndex = e.NewPageIndex;
            gvBlock.DataSource = ViewState["tblCandidate"];
            gvBlock.DataBind();
        }

        protected void ddlElection_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGridview();
        }
    }
}