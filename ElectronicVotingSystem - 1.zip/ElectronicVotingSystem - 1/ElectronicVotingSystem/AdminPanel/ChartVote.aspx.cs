﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Data;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class ChartVote : System.Web.UI.Page
    {
        ElectionModel objElection = new ElectionModel();
        ChartsModel objChart = new ChartsModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                BindElectionType();
                BindElection();
                BindChart();
            }

            DataTable dt = objChart.electionVSVote();
            chartElection.DataSource = dt;
            chartElection.Series[0].XValueMember = "Election";
            chartElection.Series[0].YValueMembers = "totalVotes";
            chartElection.DataBind();
        }

        protected void ddlElection_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindChartA();
        }

        protected void ddlElectionType_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindElection();
            BindChartA();
        }

        private void BindElectionType()
        {
            DataTable tblElectionType = objElection.GetElectionType();
            ddlElectionType.DataSource = tblElectionType;
            ddlElectionType.DataTextField = tblElectionType.Columns["electionType_Name"].ToString();
            ddlElectionType.DataValueField = tblElectionType.Columns["electionType_Id"].ToString();
            ddlElectionType.DataBind();
        }

        private void BindElection()
        {
            ddlElection.Items.Clear();
            int etId = int.Parse(ddlElectionType.SelectedValue);
            DataTable tblElection = objElection.GetElectionFiltered(etId);
            if (tblElection.Rows.Count > 0)
            {
                tblElection.Columns.Add("Election", typeof(string), "election_StartingYear + ' ----- ' + election_EndingYear");
                ddlElection.DataSource = tblElection;
                ddlElection.DataTextField = "Election";
                ddlElection.DataValueField = "election_Id";
                ddlElection.DataBind();
            }
        }

        private void BindChart()
        {

            int id = int.Parse(ddlElection.SelectedValue);

            DataTable dtA = objChart.VoteVSConstituency(id);

            chartVote.DataSource = dtA;
            chartVote.Series[0].XValueMember = "highestLevelCons";
            chartVote.Series[0].YValueMembers = "totalVotes";

            chartVote.DataBind();
        }

        private void BindChartA()
        {
            int id = int.Parse(ddlElection.SelectedValue);
            DataTable dt = objChart.VoteVSConstituency(id);

            chartVote.DataSource = dt;
            chartVote.Series[0].XValueMember = "highestLevelCons";
            chartVote.Series[0].YValueMembers = "totalVotes";

            chartVote.DataBind();
        }

    }
}