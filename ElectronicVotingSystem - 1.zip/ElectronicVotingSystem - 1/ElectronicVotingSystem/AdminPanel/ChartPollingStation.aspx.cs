﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class ChartPollingStation : System.Web.UI.Page
    {
        ChartsModel objChart = new ChartsModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataTable dt = objChart.pollingstationVSDistrict();
                chartPollingStation.DataSource = dt;
                chartPollingStation.Series[0].XValueMember = "district_Name";
                chartPollingStation.Series[0].YValueMembers = "totalPollingstations";

                chartPollingStation.DataBind();

                DataTable dtA = objChart.pollingstationVSConstituency();

                chartPollingStationA.DataSource = dtA;
                chartPollingStationA.Series[0].XValueMember = "highestLevelCons";
                chartPollingStationA.Series[0].YValueMembers = "totalPollingStation";
                chartPollingStationA.DataBind();
            }
        }
    }
}