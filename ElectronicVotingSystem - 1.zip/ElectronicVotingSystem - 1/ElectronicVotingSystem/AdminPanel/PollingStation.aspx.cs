﻿using ElectronicVotingSystem.DataAccess;
using GoogleMaps.LocationServices;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class PollingStation : System.Web.UI.Page
    {
        AdministrativeUnitModel objAdminUnit = new AdministrativeUnitModel();
        DistrictModel objDistrict = new DistrictModel();
        TehsilModel objTehsil = new TehsilModel();
        MauzaModel objMauza = new MauzaModel();
        BlockModel objBlock = new BlockModel();
        PollingStationModel objPollingStation = new PollingStationModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (ddlAdminUnit.Items.Count > 0)
                {
                    DataTable tblAdminUnit = objAdminUnit.GetAdminUnit();
                    ddlAdminUnit.DataSource = tblAdminUnit;
                    ddlAdminUnit.DataValueField = tblAdminUnit.Columns["administrativeUnit_Id"].ToString();
                    ddlAdminUnit.DataTextField = tblAdminUnit.Columns["administrativeUnit_Name"].ToString();
                    ddlAdminUnit.DataBind();
                }
            }
            else
            {
                ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                ddlMauza.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                ddlBlock.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            }
        }

        protected void ddlAdminUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.Clear();
            ListItem first = new ListItem("Select District", "0");
            ddlDistrict.Items.Add(first);
            ddlDistrict.Items.FindByValue("0").Selected = true;
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlTehsil.Items.Clear();
            first = new ListItem("Select Tehsil", "0");
            ddlTehsil.Items.Add(first);
            ddlTehsil.Items.FindByValue("0").Selected = true;
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlMauza.Items.Clear();
            first = new ListItem("Select Electoral Area", "0");
            ddlMauza.Items.Add(first);
            ddlMauza.Items.FindByValue("0").Selected = true;
            ddlMauza.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlBlock.Items.Clear();
            first = new ListItem("Select Block Code", "0");
            ddlBlock.Items.Add(first);
            ddlBlock.Items.FindByValue("0").Selected = true;
            ddlBlock.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvPollingStation.Visible = false;

            int id = int.Parse(ddlAdminUnit.SelectedValue);
            DataTable adminId = objAdminUnit.GetAdminUnitTypeByAdminUnit(id);
            DataTable tblDistrict = objDistrict.GetDistrictByAdminUnit(id);
            if (tblDistrict.Rows.Count > 0)
            {
                ddlDistrict.DataSource = tblDistrict;
                ddlDistrict.DataValueField = tblDistrict.Columns["district_Id"].ToString();
                ddlDistrict.DataTextField = tblDistrict.Columns["district_Name"].ToString();
                ddlDistrict.DataBind();
            }
        }

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlTehsil.Items.Clear();
            ListItem first = new ListItem("Select Tehsil", "0");
            ddlTehsil.Items.Add(first);
            ddlTehsil.Items.FindByValue("0").Selected = true;
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlMauza.Items.Clear();
            first = new ListItem("Select Electoral Area", "0");
            ddlMauza.Items.Add(first);
            ddlMauza.Items.FindByValue("0").Selected = true;
            ddlMauza.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlBlock.Items.Clear();
            first = new ListItem("Select Block Code", "0");
            ddlBlock.Items.Add(first);
            ddlBlock.Items.FindByValue("0").Selected = true;
            ddlBlock.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvPollingStation.Visible = false;

            int distId = int.Parse(ddlDistrict.SelectedValue);
            DataTable tblTehsil = objTehsil.GetTehsilByDistrictId(distId);
            if (tblTehsil.Rows.Count > 0)
            {
                ddlTehsil.DataSource = tblTehsil;
                ddlTehsil.DataValueField = tblTehsil.Columns["tehsil_Id"].ToString();
                ddlTehsil.DataTextField = tblTehsil.Columns["tehsil_Name"].ToString();
                ddlTehsil.DataBind();
            }
            BindGridView();
        }

        protected void ddlTehsil_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlMauza.Items.Clear();
            ListItem first = new ListItem("Select Electoral Area", "0");
            ddlMauza.Items.Add(first);
            ddlMauza.Items.FindByValue("0").Selected = true;
            ddlMauza.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlBlock.Items.Clear();
            first = new ListItem("Select Block Code", "0");
            ddlBlock.Items.Add(first);
            ddlBlock.Items.FindByValue("0").Selected = true;
            ddlBlock.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int tehsilId = int.Parse(ddlTehsil.SelectedValue);
            DataTable tblMauza = objMauza.GetMauzaByTehsilId(tehsilId);
            if (tblMauza.Rows.Count > 0)
            {
                ddlMauza.DataSource = tblMauza;
                ddlMauza.DataValueField = tblMauza.Columns["mauza_Id"].ToString();
                ddlMauza.DataTextField = tblMauza.Columns["mauza_Name"].ToString();
                ddlMauza.DataBind();
            }
        }

        protected void ddlMauza_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlBlock.Items.Clear();
            ListItem first = new ListItem("Select Block Code", "0");
            ddlBlock.Items.Add(first);
            ddlBlock.Items.FindByValue("0").Selected = true;
            ddlBlock.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int mauzaId = int.Parse(ddlMauza.SelectedValue);
            DataTable tblBlock = objBlock.GetBlockByMauzaId(mauzaId);
            if (tblBlock.Rows.Count > 0)
            {
                ddlBlock.DataSource = tblBlock;
                ddlBlock.DataValueField = tblBlock.Columns["block_Id"].ToString();
                ddlBlock.DataTextField = tblBlock.Columns["block_Number"].ToString();
                ddlBlock.DataBind();
            }
        }

        protected void btn_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                int blockId = int.Parse(ddlBlock.SelectedValue);
                string city = txtCity.Text;
                string town = txtTown.Text;
                string address = txtAddress.Text;

                GoogleGeoCodeResponse test;
                test = GetGoogleMap(city, town, address);
                float longitude = 0;
                float latitude = 0;
                string status = test.status;
                if (status == "OK")
                {
                    foreach (var res in test.results)
                    {
                        longitude = float.Parse(res.geometry.location.lng.ToString());
                        latitude = float.Parse(res.geometry.location.lat.ToString());
                    }
                }

                bool success = objPollingStation.SavePollingStation(city, town, address, longitude, longitude, blockId);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "Polling Station added successfully!";
                    lblMsg.CssClass = "label label-success";
                    BindGridView();
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to add Polling Station.";
                    lblMsg.CssClass = "label label-warning";
                }
            }
        }

        protected void gvPollingStation_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = int.Parse(((HiddenField)gvPollingStation.Rows[e.RowIndex].FindControl("hfId")).Value);

            Boolean success = objPollingStation.DeletePollingStation(id);
            gvPollingStation.EditIndex = -1;
            if (success)
            {
                lblMsg.Text = "PollingStation deleted successfully!";
                lblMsg.CssClass = "label label-success";
                BindGridView();
            }
            else
            {
                lblMsg.Text = "Sorry! Failed to delete PollingStation.";
                lblMsg.CssClass = "label label-warning";
            }
        }

        protected void gvPollingStation_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvPollingStation.EditIndex = -1;
            gvPollingStation.DataSource = ViewState["tblPollingStation"];
            gvPollingStation.DataBind();
        }

        protected void gvPollingStation_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvPollingStation.EditIndex = e.NewEditIndex;
            BindGridView();
        }

        protected void gvPollingStation_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            if (Page.IsValid)
            {
                int id = int.Parse(((HiddenField)gvPollingStation.Rows[e.RowIndex].FindControl("hfId")).Value);
                string city = ((TextBox)gvPollingStation.Rows[e.RowIndex].FindControl("City")).Text;
                string town = ((TextBox)gvPollingStation.Rows[e.RowIndex].FindControl("Town")).Text;
                string address = ((TextBox)gvPollingStation.Rows[e.RowIndex].FindControl("Address")).Text;

                GoogleGeoCodeResponse test;

                test = GetGoogleMap(city, town, address);

                float longitude = 0;
                float latitude = 0;
                string status = test.status;
                if (status == "OK")
                {
                    foreach (var res in test.results)
                    {
                        longitude = float.Parse(res.geometry.location.lng.ToString());
                        latitude = float.Parse(res.geometry.location.lat.ToString());
                    }
                }

                Boolean success = objPollingStation.UpdatePollingStation(id, city, town, address, longitude, latitude);

                if (success)
                {
                    lblMsg.Text = "Polling Station updated successfully.";
                    lblMsg.CssClass = "label label-success";
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to update Polling Station.";
                    lblMsg.CssClass = "label label-warning";
                }
                gvPollingStation.EditIndex = -1;
                BindGridView();

            }
        }

        protected void ddlBlock_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void cv_ServerValidate(object source, ServerValidateEventArgs args)
        {
            int blockId = int.Parse(ddlBlock.SelectedValue);
            string city = txtCity.Text;
            string town = txtTown.Text;
            string address = txtAddress.Text;
            DataTable unitExist = objPollingStation.GetCVPollingStation(city, town, address, blockId);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void cv_ServerValidate1(object source, ServerValidateEventArgs args)
        {
            string address = args.Value;
            GridViewRow gvr = (GridViewRow)((CustomValidator)source).Parent.Parent;
            int index = gvr.RowIndex;
            string city = (((TextBox)gvPollingStation.Rows[index].FindControl("City")).Text);
            string town = (((TextBox)gvPollingStation.Rows[index].FindControl("Town")).Text);
            int blockId = int.Parse(ddlBlock.SelectedValue);
            int Id = int.Parse(((HiddenField)gvPollingStation.Rows[index].FindControl("hfId")).Value);
            DataTable unitExist = objPollingStation.GetCVPollingStationId(Id, city, town, address, blockId);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void btnView_Click(object sender, EventArgs e)
        {
            GoogleGeoCodeResponse test;
            string city = txtCity.Text;
            string town = txtTown.Text;
            string address = txtAddress.Text;
            test = GetGoogleMap(city, town, address);
            string status = test.status;
            if (status == "OK")
            {
                foreach (var res in test.results)
                {
                    string formattedAddress = res.formatted_address;
                    string longitude = res.geometry.location.lng.ToString();
                    string latitude = res.geometry.location.lat.ToString();
                    Response.Redirect("PollingStationMap.aspx?long=" + longitude + "&lat=" + latitude + "&add=" + address);
                }
            }
            else
            {
                lblMsg.Text = "Sorry! Google map for this polling station is not found!";
                lblMsg.CssClass = "label label-info";
            }
        }

        private void BindGridView()
        {
            int distId = int.Parse(ddlDistrict.SelectedValue);
            if (distId != 0)
            {
                DataTable tblPollingStation = objPollingStation.GetPollingStationByDistId(distId);
                ViewState["tblPollingStation"] = tblPollingStation;
                if (tblPollingStation.Rows.Count > 0)
                {
                    gvPollingStation.Visible = true;
                    gvPollingStation.DataSource = tblPollingStation;
                    gvPollingStation.DataBind();
                }
                else
                {
                    gvPollingStation.Visible = false;
                }
            }
        }

        private GoogleGeoCodeResponse GetGoogleMap(string City, string Town, string Add)
        {
            GoogleGeoCodeResponse test = null;

            string city = City;
            string town = Town;
            string address = Add;
            //string district = ddlDistrict.SelectedItem.Text;
            string country = "Pakistan";
            AddressData add = new AddressData
            {
                Address = address + " , " + town,
                City = city,
                Country = country
            };
            string APIKey = "AIzaSyA88Whn7TgKUCNk_jZM7XvyK_lCtFcEv_0";
            var gls = new GoogleLocationService();
            string url = string.Format("https://maps.googleapis.com/maps/api/geocode/json?key={0}&address={1}", APIKey, add);
            using (WebClient client = new WebClient())
            {
                string json = client.DownloadString(url);
                JavaScriptSerializer jss = new JavaScriptSerializer();
                test = jss.Deserialize<GoogleGeoCodeResponse>(json);
            }
            return test;
        }

        protected void cvGoogleMap_ServerValidate(object source, ServerValidateEventArgs args)
        {
            string city = txtCity.Text;
            string town = txtTown.Text;
            string address = txtAddress.Text;
            GoogleGeoCodeResponse test = GetGoogleMap(city, town, address);

            string status = test.status;
            if (status != "OK")
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void cvGoogleMap_ServerValidate1(object source, ServerValidateEventArgs args)
        {
            string address = args.Value;
            GridViewRow gvr = (GridViewRow)((CustomValidator)source).Parent.Parent;
            int index = gvr.RowIndex;
            string city = (((TextBox)gvPollingStation.Rows[index].FindControl("City")).Text);
            string town = (((TextBox)gvPollingStation.Rows[index].FindControl("Town")).Text);

            GoogleGeoCodeResponse test = GetGoogleMap(city, town, address);

            string status = test.status;
            if (status != "OK")
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void btnViewMap_Click(object sender, EventArgs e)
        {
            GoogleGeoCodeResponse test;
            GridViewRow gvr = (GridViewRow)((Button)sender).Parent.Parent;
            string city; string town; string address;
            int index = gvr.RowIndex;
            if (gvr.RowState == DataControlRowState.Edit)
            {
                city = (((TextBox)gvPollingStation.Rows[index].FindControl("City")).Text);
                town = (((TextBox)gvPollingStation.Rows[index].FindControl("Town")).Text);
                address = (((TextBox)gvPollingStation.Rows[index].FindControl("Address")).Text);
            }
            else
            {
                city = (((Label)gvPollingStation.Rows[index].FindControl("lblCity")).Text);
                town = (((Label)gvPollingStation.Rows[index].FindControl("lblTown")).Text);
                address = (((Label)gvPollingStation.Rows[index].FindControl("lblAddress")).Text);
            }
            test = GetGoogleMap(city, town, address);
            string status = test.status;
            if (status == "OK")
            {
                foreach (var res in test.results)
                {
                    string formattedAddress = res.formatted_address;
                    string longitude = res.geometry.location.lng.ToString();
                    string latitude = res.geometry.location.lat.ToString();
                    Response.Redirect("PollingStationMap.aspx?long=" + longitude + "&lat=" + latitude + "&add=" + address);
                }
            }
            else
            {
                lblMsg.Text = "Sorry! Google map for this polling station is not found!";
                lblMsg.CssClass = "label label-info";
            }
        }

        protected void gvPollingStation_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvPollingStation.PageIndex = e.NewPageIndex;
            BindGridView();
        }
    }

    public class GoogleGeoCodeResponse
    {
        public results[] results { get; set; }
        public string status { get; set; }
    }

    public class results
    {
        public string formatted_address { get; set; }
        public geometry geometry { get; set; }
    }

    public class geometry
    {
        public location location { get; set; }
    }

    public class location
    {
        public decimal lat { get; set; }
        public decimal lng { get; set; }
    }
}