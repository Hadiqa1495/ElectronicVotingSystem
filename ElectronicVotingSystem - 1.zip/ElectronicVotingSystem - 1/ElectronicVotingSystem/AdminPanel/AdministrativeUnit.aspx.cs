﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class AdministrativeUnit : System.Web.UI.Page
    {
        AdministrativeUnitModel objAdmin = new AdministrativeUnitModel();
        DataTable tblAdminUnit;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataTable tblAdminUnitType = objAdmin.GetAdminUnitType();
                if (tblAdminUnitType.Rows.Count > 0)
                {
                    ddlAdminUnit.DataSource = tblAdminUnitType;
                    ddlAdminUnit.DataValueField = tblAdminUnitType.Columns["administrativeUnitType_Id"].ToString();
                    ddlAdminUnit.DataTextField = tblAdminUnitType.Columns["administrativeUnitType_Name"].ToString();
                    ddlAdminUnit.DataBind();
                }
                tblAdminUnit = objAdmin.GetAdminUnit();
                ViewState["tblAdminUnit"] = tblAdminUnit;
                if (tblAdminUnit.Rows.Count > 0)
                {
                    gvAdminUnit.DataSource = tblAdminUnit;
                    gvAdminUnit.DataBind();
                }
                else
                {
                    gvAdminUnit.Visible = false;
                }
            }
        }

        protected void cvAdminUnit_ServerValidate(object source, ServerValidateEventArgs args)
        {
            string adminUnitName = txtAdminUnit.Text;
            AdministrativeUnitModel objyAdmin12 = new AdministrativeUnitModel();
            DataTable unitExist = objyAdmin12.GetAdminUnitByAdminUnitName(adminUnitName);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void btnAdminUnit_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                string adminUnit = txtAdminUnit.Text;
                // Execute the insert command
                AdministrativeUnitModel objAdmin = new AdministrativeUnitModel();
                int typeId = int.Parse(ddlAdminUnit.SelectedValue);
                bool success = objAdmin.SaveAdministrativeUnit(adminUnit, typeId);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "Unit added successfully.";
                    lblMsg.CssClass = "label label-success";

                    tblAdminUnit = objAdmin.GetAdminUnit();
                    ViewState["tblAdminUnit"] = tblAdminUnit;
                    gvAdminUnit.DataSource = tblAdminUnit;
                    gvAdminUnit.DataBind();
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to add unit.";
                    lblMsg.CssClass = "label label-warning";
                }
            }
        }

        protected void cvAdminUnit_ServerValidate1(object source, ServerValidateEventArgs args)
        {
            string adminUnitName = args.Value;
            GridViewRow gvr = (GridViewRow)((CustomValidator)source).Parent.Parent;
            int index = gvr.RowIndex;
            int Id = int.Parse(((HiddenField)gvAdminUnit.Rows[index].FindControl("hfAdminId")).Value);
            DataTable unitExist = objAdmin.GetAdminUnitByIdName(Id, adminUnitName);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void gvAdminUnit_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvAdminUnit.EditIndex = e.NewEditIndex;
            gvAdminUnit.DataSource = ViewState["tblAdminUnit"];
            gvAdminUnit.DataBind();
        }

        protected void gvAdminUnit_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvAdminUnit.EditIndex = -1;
            gvAdminUnit.DataSource = ViewState["tblAdminUnit"];
            gvAdminUnit.DataBind();
        }

        protected void gvAdminUnit_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            if (Page.IsValid)
            {
                int id = int.Parse(((HiddenField)gvAdminUnit.Rows[e.RowIndex].FindControl("hfAdminId")).Value);
                string name = ((TextBox)gvAdminUnit.Rows[e.RowIndex].FindControl("txtAdminUnit")).Text;
                objAdmin.UpdateAdministrativeUnit(id, name);
                gvAdminUnit.EditIndex = -1;
                tblAdminUnit = objAdmin.GetAdminUnit();
                ViewState["tblAdminUnit"] = tblAdminUnit;
                gvAdminUnit.DataSource = tblAdminUnit;
                gvAdminUnit.DataBind();
            }
        }

        protected void gvAdminUnit_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = int.Parse(((HiddenField)gvAdminUnit.Rows[e.RowIndex].FindControl("hfAdminId")).Value);
            objAdmin.DeleteAdministrativeUnit(id);
            gvAdminUnit.EditIndex = -1;
            tblAdminUnit = objAdmin.GetAdminUnit();
            ViewState["tblAdminUnit"] = tblAdminUnit;
            gvAdminUnit.DataSource = tblAdminUnit;
            gvAdminUnit.DataBind();
        }

        protected void gvAdminUnit_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvAdminUnit.PageIndex = e.NewPageIndex;
            gvAdminUnit.DataSource = ViewState["tblAdminUnit"];
            gvAdminUnit.DataBind();
        }

    }
}