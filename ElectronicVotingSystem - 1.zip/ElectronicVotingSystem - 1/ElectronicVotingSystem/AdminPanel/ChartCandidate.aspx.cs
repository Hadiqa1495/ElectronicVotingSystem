﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class ChartCandidate : System.Web.UI.Page
    {
        ElectionModel objElection = new ElectionModel();
        ChartsModel objChart = new ChartsModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataTable tblElectionType = objElection.GetElectionType();
                ddlElectionType.DataSource = tblElectionType;
                ddlElectionType.DataTextField = tblElectionType.Columns["electionType_Name"].ToString();
                ddlElectionType.DataValueField = tblElectionType.Columns["electionType_Id"].ToString();
                ddlElectionType.DataBind();

                BindChart();

                BindElectionType();
                BindElection();
                BindChartA();
            }
        }

        protected void ddlElectionType_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindChart();
            BindChartA();
        }

        protected void ddlElection_SelectedIndexChangedA(object sender, EventArgs e)
        {
            BindChart();
            BindChartA();
        }

        protected void ddlElectionType_SelectedIndexChangedA(object sender, EventArgs e)
        {
            BindElection();
            BindChartA();
            BindChart();
        }

        protected void BindElectionType()
        {
            DataTable tblElectionType = objElection.GetElectionType();
            ddlElectionTypeA.DataSource = tblElectionType;
            ddlElectionTypeA.DataTextField = tblElectionType.Columns["electionType_Name"].ToString();
            ddlElectionTypeA.DataValueField = tblElectionType.Columns["electionType_Id"].ToString();
            ddlElectionTypeA.DataBind();
        }

        protected void BindElection()
        {
            ddlElectionA.Items.Clear();
            int etId = int.Parse(ddlElectionTypeA.SelectedValue);
            DataTable tblElection = objElection.GetElectionFiltered(etId);
            if (tblElection.Rows.Count > 0)
            {
                tblElection.Columns.Add("Election", typeof(string), "election_StartingYear + ' ----- ' + election_EndingYear");
                ddlElectionA.DataSource = tblElection;
                ddlElectionA.DataTextField = "Election";
                ddlElectionA.DataValueField = "election_Id";
                ddlElectionA.DataBind();
            }
        }

        private void BindChart()
        {
            int id = int.Parse(ddlElectionType.SelectedValue);
            DataTable dt = objChart.ElectionVSCandidate(id);
            chartElection.DataSource = dt;
            chartElection.Series[0].XValueMember = "Election";
            chartElection.Series[0].YValueMembers = "totalCandidates";
            chartElection.DataBind();
        }

        private void BindChartA()
        {
            int id = int.Parse(ddlElectionA.SelectedValue);
            DataTable dt = objChart.candidateVsConstituency(id);
            chartCandidateA.DataSource = dt;
            chartCandidateA.Series[0].XValueMember = "highestLevelCons";
            chartCandidateA.Series[0].YValueMembers = "totalCandidates";
            chartCandidateA.DataBind();
        }
    }
}