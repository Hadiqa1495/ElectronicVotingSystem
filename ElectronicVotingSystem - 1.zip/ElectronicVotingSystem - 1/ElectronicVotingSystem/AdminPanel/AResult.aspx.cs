﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class AssemblyResult : System.Web.UI.Page
    {
        ResultModel objResult = new ResultModel();
        private int electionId;
        private int districtId;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["id"] != null)
                {
                    electionId = int.Parse(Request.QueryString["id"]);
                    linkParty.NavigateUrl = "PartyResultDetail.aspx?elecId=" + electionId;
                    ResultModel objResult = new ResultModel();
                    DataTable tblParty = objResult.GetPartyWinnersNA(electionId);
                    if (tblParty.Rows.Count > 0)
                    {
                        GvParty.DataSource = tblParty;
                        GvParty.DataBind();
                    }

                    DataTable tblParty2 = objResult.GetPartyWinnersPAProvincially(electionId);
                    if (tblParty.Rows.Count > 0)
                    {
                        gvPAParties.DataSource = tblParty2;
                        gvPAParties.DataBind();
                    }

                    string voteCount = objResult.GetVoteCount(electionId);
                    lblVoteCount.Text = voteCount;

                    DistrictModel objDist = new DistrictModel();
                    DataTable tblDistrict = objDist.GetDistrictByElectionId(electionId);
                    DataSet ds = new DataSet();
                    ds.Tables.Add(tblDistrict);
                    if (tblDistrict.Rows.Count > 0)
                    {
                        MyAccordion.DataSource = ds.Tables[0].DefaultView;
                        MyAccordion.DataBind();
                    }
                }
            }
        }

        protected void MyAccordion_ItemDataBound(object sender, AjaxControlToolkit.AccordionItemEventArgs e)
        {
            if (e.ItemType == AjaxControlToolkit.AccordionItemType.Content)
            {
                Repeater rpt = (Repeater)e.AccordionItem.FindControl("rptA");
                HiddenField hf = (HiddenField)e.AccordionItem.FindControl("hfDist");
                districtId = int.Parse(hf.Value);
                DataTable tblNAResult = objResult.GetAssemblyElectionWinners(electionId, districtId);
                if (tblNAResult.Rows.Count > 0)
                {
                    rpt.DataSource = tblNAResult;
                    rpt.DataBind();
                }
            }
        }

    }
}