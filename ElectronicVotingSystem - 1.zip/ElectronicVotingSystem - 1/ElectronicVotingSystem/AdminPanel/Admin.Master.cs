﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class Admin : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["userInfo"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
                else
                {
                    DataTable tblUser = (DataTable)Session["userInfo"];
                    lblName.Text = tblUser.Rows[0]["member_FirstName"].ToString();
                    lblRole.Text = tblUser.Rows[0]["role_Name"].ToString();
                    if ((tblUser.Rows[0]["member_LastOnlineDate"]).ToString() != "")
                    {
                        lblDate.Text = ((DateTime)tblUser.Rows[0]["member_LastOnlineDate"]).ToString("D");
                    }
                }
            }
        }

        protected void PA_Load(object sender, EventArgs e)
        {
            ElectionModel objElection = new ElectionModel();
            DataTable tblElections = objElection.GetPrevious10ElectionByElectionType(15);
            if (tblElections.Rows.Count > 0)
            {
                rptPAElec.DataSource = tblElections;
                rptPAElec.DataBind();
            }
            else
            {
                rptPAElec.Visible = false;
            }
        }

        protected void NA_Load(object sender, EventArgs e)
        {
            ElectionModel objElection = new ElectionModel();
            DataTable tblElections = objElection.GetPrevious10ElectionByElectionType(14);
            if (tblElections.Rows.Count > 0)
            {
                rptAssemblyElec.DataSource = tblElections;
                rptAssemblyElec.DataBind();
            }
            else
            {
                rptAssemblyElec.Visible = false;
            }
        }

    }
}