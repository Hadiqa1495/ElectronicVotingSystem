﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class PollingStationMap : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int i = 0;
            string longitude = "69.345115";
            string latitude = "30.375321";
            string desc = "Welcome to Pakistan!";
            int zoom = 7;
            string markers = @"var marker" + i.ToString() + @" = new google.maps.Marker({ position: new google.maps.LatLng(" + latitude + ", " + longitude + ")," + @"map: myMap, title:'" + desc + "'});";
            try
            {
                desc = Request.QueryString["add"].ToString();
                longitude = Request.QueryString["long"].ToString();
                latitude = Request.QueryString["lat"].ToString();
                zoom = 18;
                markers = @"var marker" + i.ToString() + @" = new google.maps.Marker({ position: new google.maps.LatLng(" + latitude + ", " + longitude + ")," + @"map: myMap, title:'" + desc + "'});";
            }
            catch
            {

            }
            Literal1.Text = @"<script type='text/javascript'>
             function initialize() {
 
             var mapOptions = {
             center: new google.maps.LatLng(" + latitude + "," + longitude + @"),
             zoom: " + zoom + @",
             mapTypeId: google.maps.MapTypeId.ROADMAP
             };
 
             var myMap = new google.maps.Map(document.getElementById('mapArea'),
             mapOptions);" + markers + @"}
             </script>";

        }
    }
}