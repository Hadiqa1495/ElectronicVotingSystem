﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class Charge : System.Web.UI.Page
    {
        AdministrativeUnitModel objAdminUnit = new AdministrativeUnitModel();
        DistrictModel objDistrict = new DistrictModel();
        TehsilModel objTehsil = new TehsilModel();
        ChargeModel objCharge = new ChargeModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (ddlAdminUnit.Items.Count > 0)
                {
                    DataTable tblAdminUnit = objAdminUnit.GetAdminUnit();
                    ddlAdminUnit.DataSource = tblAdminUnit;
                    ddlAdminUnit.DataValueField = tblAdminUnit.Columns["administrativeUnit_Id"].ToString();
                    ddlAdminUnit.DataTextField = tblAdminUnit.Columns["administrativeUnit_Name"].ToString();
                    ddlAdminUnit.DataBind();
                }
            }
        }

        protected void ddlAdminUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.Clear();
            ListItem first = new ListItem("Select District", "0");
            ddlDistrict.Items.Add(first);
            ddlDistrict.Items.FindByValue("0").Selected = true;
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlTehsil.Items.Clear();
            first = new ListItem("Select Tehsil", "0");
            ddlTehsil.Items.Add(first);
            ddlTehsil.Items.FindByValue("0").Selected = true;
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvCharge.Visible = false;
            pnlHeading.Visible = false;

            int adminUnit = int.Parse(ddlAdminUnit.SelectedValue);
            DataTable tblDistrict = objDistrict.GetDistrictByAdminUnit(adminUnit);
            if (tblDistrict.Rows.Count > 0)
            {
                ddlDistrict.DataSource = tblDistrict;
                ddlDistrict.DataValueField = tblDistrict.Columns["district_Id"].ToString();
                ddlDistrict.DataTextField = tblDistrict.Columns["district_Name"].ToString();
                ddlDistrict.DataBind();
            }
        }

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlTehsil.Items.Clear();
            ListItem first = new ListItem("Select Tehsil", "0");
            ddlTehsil.Items.Add(first);
            ddlTehsil.Items.FindByValue("0").Selected = true;
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvCharge.Visible = false;
            pnlHeading.Visible = false;

            int distId = int.Parse(ddlDistrict.SelectedValue);
            DataTable tblTehsil = objTehsil.GetTehsilByDistrictId(distId);
            if (tblTehsil.Rows.Count > 0)
            {
                ddlTehsil.DataSource = tblTehsil;
                ddlTehsil.DataValueField = tblTehsil.Columns["tehsil_Id"].ToString();
                ddlTehsil.DataTextField = tblTehsil.Columns["tehsil_Name"].ToString();
                ddlTehsil.DataBind();
            }
        }

        protected void ddlTehsil_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int tehsilId = int.Parse(ddlTehsil.SelectedValue);
            DataTable tblCharge = objCharge.GetChargeByTehsilId(tehsilId);
            ViewState["tblCharge"] = tblCharge;
            if (tblCharge.Rows.Count > 0)
            {
                pnlHeading.Visible = true;
                gvCharge.Visible = true;
                gvCharge.DataSource = tblCharge;
                gvCharge.DataBind();
            }
            else
            {
                pnlHeading.Visible = false;
                gvCharge.Visible = false;
            }
        }

        protected void cv_ServerValidate(object source, ServerValidateEventArgs args)
        {
            int tehsilId = int.Parse(ddlTehsil.SelectedValue);
            string name = txtName.Text;
            DataTable unitExist = objCharge.GetChargeByNameTehsilId(name, tehsilId);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void btnTehsil_Click(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            if (Page.IsValid)
            {
                int tehsilId = int.Parse(ddlTehsil.SelectedValue);
                string name = txtName.Text;
                bool success = objCharge.SaveCharge(name, tehsilId);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "Charge added successfully.";
                    lblMsg.CssClass = "label label-success";
                    txtName.Text = "";

                    gvCharge.Visible = true;
                    tehsilId = int.Parse(ddlTehsil.SelectedValue);
                    DataTable tblCharge = objCharge.GetChargeByTehsilId(tehsilId);
                    ViewState["tblCharge"] = tblCharge;
                    gvCharge.DataSource = ViewState["tblCharge"];
                    gvCharge.DataBind();
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to add charge.";
                    lblMsg.CssClass = "label label-warning";
                }
            }
        }

        protected void cvDistrict_ServerValidate1(object source, ServerValidateEventArgs args)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            string Name = args.Value;
            GridViewRow gvr = (GridViewRow)((CustomValidator)source).Parent.Parent;
            int index = gvr.RowIndex;
            int Id = int.Parse(((HiddenField)gvCharge.Rows[index].FindControl("hfId")).Value);
            int tehsilId = int.Parse(ddlTehsil.SelectedValue);
            DataTable unitExist = objCharge.GetChargeByIdNameTehsilId(Id, Name, tehsilId);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void gvCharge_RowEditing(object sender, GridViewEditEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvCharge.EditIndex = e.NewEditIndex;
            gvCharge.DataSource = ViewState["tblCharge"];
            gvCharge.DataBind();
        }

        protected void gvCharge_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvCharge.EditIndex = -1;
            gvCharge.DataSource = ViewState["tblCharge"];
            gvCharge.DataBind();
        }

        protected void gvCharge_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            if (Page.IsValid)
            {
                int id = int.Parse(((HiddenField)gvCharge.Rows[e.RowIndex].FindControl("hfId")).Value);
                string name = ((TextBox)gvCharge.Rows[e.RowIndex].FindControl("txtName")).Text;
                int tehsilId = int.Parse(ddlTehsil.SelectedValue);
                Boolean success = objCharge.UpdateCharge(id, name, tehsilId);
                if (success)
                {
                    lblMsg.Text = "Charge updated successfully.";
                    lblMsg.CssClass = "label label-success";
                    txtName.Text = "";
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to update charge.";
                    lblMsg.CssClass = "label label-warning";
                }

                gvCharge.EditIndex = -1;
                tehsilId = int.Parse(ddlTehsil.SelectedValue);
                DataTable tblCharge = objCharge.GetChargeByTehsilId(tehsilId);
                if (tblCharge.Rows.Count > 0)
                {
                    gvCharge.Visible = true;
                    ViewState["tblCharge"] = tblCharge;
                    gvCharge.DataSource = ViewState["tblCharge"];
                    gvCharge.DataBind();
                }
                else
                {
                    gvCharge.Visible = false;
                }
            }
        }

        protected void gvCharge_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int id = int.Parse(((HiddenField)gvCharge.Rows[e.RowIndex].FindControl("hfId")).Value);
            Boolean success = objCharge.DeleteCharge(id);
            if (success)
            {
                lblMsg.Text = "Charge deleted successfully.";
                lblMsg.CssClass = "label label-success";
                txtName.Text = "";
            }
            else
            {
                lblMsg.Text = "Sorry! Failed to delete charge.";
                lblMsg.CssClass = "label label-warning";
            }

            gvCharge.EditIndex = -1;
            int tehsilId = int.Parse(ddlTehsil.SelectedValue);
            DataTable tblCharge = objCharge.GetChargeByTehsilId(tehsilId);
            if (tblCharge.Rows.Count > 0)
            {
                gvCharge.Visible = true;
                ViewState["tblCharge"] = tblCharge;
                gvCharge.DataSource = ViewState["tblCharge"];
                gvCharge.DataBind();
            }
            else
            {
                gvCharge.Visible = false;
            }
        }

        protected void gvCharge_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvCharge.PageIndex = e.NewPageIndex;
            gvCharge.DataSource = ViewState["tblCharge"];
            gvCharge.DataBind();
        }
    }
}