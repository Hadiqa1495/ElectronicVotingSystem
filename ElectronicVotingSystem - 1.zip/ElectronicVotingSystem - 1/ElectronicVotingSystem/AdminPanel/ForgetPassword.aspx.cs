﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Data;
using System.Net;
using System.Net.Mail;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class ForgetPassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
            int roleId = int.Parse(((DropDownList)ucMemberList.FindControl("ddlMember")).SelectedValue);
            string email = txtEmail.Text;
            DataTable tblMember = MemberModel.GetMemberByEmail(roleId, email);
            if (tblMember.Rows.Count > 0)
            {
                using (MailMessage mm = new MailMessage("EVS.ECP@gmail.com", txtEmail.Text))
                {
                    mm.Subject = "Recover Password";
                    mm.Body = string.Format("Hi {0},<br /><br />Your password is {1}.<br /><br />Thank You.", tblMember.Rows[0]["member_Username"].ToString(), tblMember.Rows[0]["member_Password"].ToString());
                    mm.IsBodyHtml = false;
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = "smtp.gmail.com";
                    smtp.EnableSsl = true;
                    //Here is your email account email and password is given, You can change it to your personal email account
                    NetworkCredential NetworkCred = new NetworkCredential("EVS.ECP@gmail.com", "EVS123ECP");
                    smtp.UseDefaultCredentials = true;
                    smtp.Credentials = NetworkCred;
                    smtp.Port = 587;
                    smtp.Send(mm);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Your Password has been sent to your email account!.');", true);
                }
            }
            else
            {
                lblMsg.CssClass = "label label-warning";
                lblMsg.Text = "Email not found!";
            }
        }
    }
}