﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class News : System.Web.UI.Page
    {
        NewsModel objNews = new NewsModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataTable tbl = objNews.GetNews();
                if (tbl.Rows.Count > 0)
                {
                    gvNews.Visible = true;
                    ViewState["tbl"] = tbl;
                    gvNews.DataSource = tbl;
                    gvNews.DataBind();
                }
                else
                {
                    gvNews.Visible = false;
                }
            }

        }

        protected void gvNews_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvNews.EditIndex = -1;
            gvNews.DataSource = ViewState["tbl"];
            gvNews.DataBind();
        }

        protected void gvNews_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = int.Parse(((HiddenField)gvNews.Rows[e.RowIndex].FindControl("hfId")).Value);
            bool success = objNews.DeleteNews(id);
            gvNews.EditIndex = -1;
            if (success)
            {
                lblMsg.Text = "News deleted successfully.";
                lblMsg.CssClass = "label label-success";

                gvNews.Visible = true;
                DataTable tbl = objNews.GetNews();
                ViewState["tbl"] = tbl;
                gvNews.DataSource = tbl;
                gvNews.DataBind();
            }
            else
            {
                lblMsg.Text = "Sorry! Failed to delete news.";
                lblMsg.CssClass = "label label-warning";
            }
        }

        protected void gvNews_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvNews.EditIndex = e.NewEditIndex;
            gvNews.DataSource = ViewState["tbl"];
            gvNews.DataBind();
        }

        protected void gvNews_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            int id = int.Parse(((HiddenField)gvNews.Rows[e.RowIndex].FindControl("hfId")).Value);
            string title = ((TextBox)gvNews.Rows[e.RowIndex].FindControl("txtTitle")).Text;
            string news = ((TextBox)gvNews.Rows[e.RowIndex].FindControl("txtNews")).Text;
            string imgPath = (((Image)gvNews.Rows[e.RowIndex].FindControl("img")).ImageUrl).ToString();
            FileUpload fuImage = (FileUpload)gvNews.Rows[e.RowIndex].FindControl("fuImage");
            string image = null;
            if (fuImage.HasFile)
            {
                var filePath = Server.MapPath(imgPath);
                if (File.Exists(filePath))
                {
                    File.Delete(filePath);
                }
                System.IO.FileInfo file = new System.IO.FileInfo(fuImage.PostedFile.FileName);
                string imgName = file.Name.Remove((file.Name.Length - file.Extension.Length));
                imgName = imgName + System.DateTime.Now.ToString("_ddMMyyhhmmss") + file.Extension;
                fuImage.SaveAs(Server.MapPath("~/Uploads/" + imgName));
                image = imgName;
            }
            else
            {
                image = ((Label)gvNews.Rows[e.RowIndex].FindControl("lblImage")).Text;
            }
            bool success = objNews.UpdateNews(title, news, image, id);
            gvNews.EditIndex = -1;
            if (success)
            {
                lblMsg.Text = "News updated successfully.";
                lblMsg.CssClass = "label label-success";

                gvNews.Visible = true;
                DataTable tbl = objNews.GetNews();
                ViewState["tbl"] = tbl;
                gvNews.DataSource = tbl;
                gvNews.DataBind();
            }
            else
            {
                lblMsg.Text = "Sorry! Failed to update news.";
                lblMsg.CssClass = "label label-warning";
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            //Save News
            if (Page.IsValid)
            {
                string imgName = "";
                string title="";
                string news="";
                if (Image.HasFile)
                {
                    System.IO.FileInfo file = new System.IO.FileInfo(Image.PostedFile.FileName);
                    imgName = file.Name.Remove((file.Name.Length - file.Extension.Length));
                    imgName = imgName + System.DateTime.Now.ToString("_ddMMyyhhmmss") + file.Extension;
                    Image.SaveAs(Server.MapPath("~/Uploads/" + imgName));
                }
                title = textTitle.Text;
                news = textNews.Text;
                // Execute the insert command
                bool success = objNews.SaveNews(title, news, imgName);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "News added successfully.";
                    lblMsg.CssClass = "label label-success";

                    //get news and bind in grid view
                    gvNews.Visible = true;
                    DataTable tbl = objNews.GetNews();
                    ViewState["tbl"] = tbl;
                    gvNews.DataSource = tbl;
                    gvNews.DataBind();
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to add news.";
                    lblMsg.CssClass = "label label-warning";
                }
            }
        }

        protected void cvImage_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (Image.HasFile)
            {
                cvImage.Text = "";
                string fileExtension = System.IO.Path.GetExtension(Image.FileName);
                int fileSize = Image.PostedFile.ContentLength;
                if (fileExtension.ToLower() != ".jpg" && fileExtension.ToLower() != ".png" && fileExtension.ToLower() != ".jpeg")
                {
                    cvImage.Text = cvImage.Text + "Only .jpg, .png and .jpeg are allowed.";
                    args.IsValid = false;
                }
                else if (fileSize > 1024 * 1024)
                {
                    cvImage.Text = cvImage.Text + "Image size (10KB) exceeded.";
                    args.IsValid = false;
                }
                else
                {
                    args.IsValid = true;
                }
            }
        }
        
        protected void cvImage_ServerValidate1(object source, ServerValidateEventArgs args)
        {
            GridViewRow gvr = (GridViewRow)((CustomValidator)source).Parent.Parent;
            CustomValidator cvImage = (CustomValidator)source;
            FileUpload Image = gvr.FindControl("fuImage") as FileUpload;
            if (Image.HasFile)
            {
                cvImage.Text = "";
                string fileExtension = System.IO.Path.GetExtension(Image.FileName);
                int fileSize = Image.PostedFile.ContentLength;
                if (fileExtension.ToLower() != ".jpg" && fileExtension.ToLower() != ".png" && fileExtension.ToLower() != ".jpeg")
                {
                    cvImage.Text = cvImage.Text + "Only .jpg, .png and .jpeg are allowed.";
                    args.IsValid = false;
                }
                else if (fileSize > 1024 * 1024)
                {
                    cvImage.Text = cvImage.Text + "Image size (10KB) exceeded.";
                    args.IsValid = false;
                }
                else
                {
                    args.IsValid = true;
                }
            }
        }
    }
}