﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class Party : System.Web.UI.Page
    {
        PartyModel objParty = new PartyModel();
        SymbolModel objSymbol = new SymbolModel();
        DataTable tblParty;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (ddlSymbol.Items.Count > 0)
                {
                    DataTable tblSymbol = objSymbol.GetSymbolFiltered();
                    ddlSymbol.DataSource = tblSymbol;
                    ViewState["tblSymbol"] = tblSymbol;
                    ddlSymbol.DataValueField = tblSymbol.Columns["symbol_Id"].ToString();
                    ddlSymbol.DataTextField = tblSymbol.Columns["symbol_Name"].ToString();
                    ddlSymbol.DataBind();
                }
                BindGridView();
            }
        }

        protected void cvAddParty_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (hfPartyId.Value == "")
            {
                string partyName = txtPartyName.Text;
                int symbol = int.Parse(ddlSymbol.SelectedValue);
                DataTable unitExist = objParty.GetPartyByName(partyName, symbol);
                if (unitExist.Rows.Count > 0)
                {
                    args.IsValid = false;
                }
                else
                {
                    args.IsValid = true;
                }
            }
            else
            {
                string partyName = txtPartyName.Text;
                int symbolId = int.Parse(ddlSymbol.SelectedValue);
                int partyId = int.Parse(hfPartyId.Value);
                DataTable unitExist = objParty.GetPartyByIdName(partyId, partyName, symbolId);
                if (unitExist.Rows.Count > 0)
                {
                    args.IsValid = false;
                }
                else
                {
                    args.IsValid = true;
                }
            }
        }

        protected void btnAddParty_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                int SymbolId = int.Parse(ddlSymbol.SelectedValue);
                string addPartyName = txtPartyName.Text;
                string abb = txtAbb.Text;
                string year = txtYear.Text;
                string leader = txtLeader.Text;
                string chairman = txtChairman.Text;
                string WiseChairman = txtWiseChairman.Text;
                string office = txtOffice.Text;
                // Execute the insert command
                bool success = objParty.SaveParty(addPartyName, abb, year, leader, SymbolId, chairman, WiseChairman, office);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "Party added successfully.";
                    lblMsg.CssClass = "label label-success";
                    BindGridView();
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to add Party.";
                    lblMsg.CssClass = "label label-warning";
                }
            }
        }

        protected void gvParty_RowEditing(object sender, GridViewEditEventArgs e)
        {
            int index = e.NewEditIndex;

            DataTable tblParty = (DataTable)ViewState["tblParty"];
            hfPartyId.Value = tblParty.Rows[index]["party_Id"].ToString();
            txtPartyName.Text = tblParty.Rows[index]["party_Name"].ToString();
            txtAbb.Text = tblParty.Rows[index]["party_Abbreviation"].ToString();
            txtYear.Text = tblParty.Rows[index]["party_FoundationYear"].ToString();
            txtLeader.Text = tblParty.Rows[index]["party_CurrentLeader"].ToString();
            txtChairman.Text = tblParty.Rows[index]["party_Chairman"].ToString();
            txtWiseChairman.Text = tblParty.Rows[index]["party_WiseChairman"].ToString();
            txtOffice.Text = tblParty.Rows[index]["party_HeadOfficeAddress"].ToString();
            string symbol = tblParty.Rows[index]["symbol_Name"].ToString();

            SymbolModel objSymbol = new SymbolModel();
            DataTable tblSymbol = objSymbol.GetSymbol();
            if (tblSymbol.Rows.Count > 0)
            {
                ddlSymbol.Items.Clear();
                ddlSymbol.DataSource = tblSymbol;
                ddlSymbol.DataValueField = tblSymbol.Columns["symbol_Id"].ToString();
                ddlSymbol.DataTextField = tblSymbol.Columns["symbol_Name"].ToString();
                ddlSymbol.DataBind();
                ddlSymbol.Items.FindByText(symbol).Selected = true;
            }

            int index2 = int.Parse(ddlSymbol.SelectedIndex.ToString());
            img.ImageUrl = "DisplayImg.ashx?imgId=" + tblSymbol.Rows[index2]["symbol_Id"].ToString();

            btnAddParty.Visible = false;
            btnUpdate.Visible = true;
            btnCancel.Visible = true;

        }

        protected void gvParty_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = int.Parse(((HiddenField)gvParty.Rows[e.RowIndex].FindControl("hfPartyId")).Value);
            bool success = objParty.DeleteParty(id);

            // Display status message
            if (success)
            {
                lblMsg.Text = "Party deleted successfully.";
                lblMsg.CssClass = "label label-success";
            }
            else
            {
                lblMsg.Text = "Sorry! Failed to delete Party.";
                lblMsg.CssClass = "label label-warning";
            }
            gvParty.EditIndex = -1;
            BindGridView();
        }

        protected void ddlSymbol_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable tblSymbol = (DataTable)ViewState["tblSymbol"];
            int index = int.Parse(ddlSymbol.SelectedIndex.ToString());
            img.ImageUrl = "DisplayImg.ashx?imgId=" + tblSymbol.Rows[--index]["symbol_Id"].ToString();

        }

        public void BindGridView()
        {
            tblParty = objParty.GetParty();
            ViewState["tblParty"] = tblParty;
            gvParty.DataSource = tblParty;
            gvParty.DataBind();
        }

        protected void gvParty_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvParty.PageIndex = e.NewPageIndex;
            gvParty.DataSource = ViewState["tblParty"];
            gvParty.DataBind();
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                int symbol = int.Parse(ddlSymbol.SelectedValue);
                string name = txtPartyName.Text;
                string abb = txtAbb.Text;
                string year = txtYear.Text;
                string leader = txtLeader.Text;
                string chairman = txtChairman.Text;
                string wiseChairman = txtWiseChairman.Text;
                string office = txtOffice.Text;
                int id = int.Parse(hfPartyId.Value);
                // Execute the insert command
                bool success = objParty.UpdatePartyInfo(id, name, abb, year, leader, symbol, chairman, wiseChairman, office);

                // Display status message
                if (success)
                {
                    lblMsg.Text = "Party updated successfully.";
                    lblMsg.CssClass = "label label-success";
                    BindGridView();
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to update Party.";
                    lblMsg.CssClass = "label label-warning";
                    BindGridView();
                }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("Party.aspx");
        }

    }
}