﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Data;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class PartyResultDetail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ResultModel objResult = new ResultModel();
            if (!IsPostBack)
            {
                if (Request.QueryString["elecId"] != null)
                {
                    int elec = int.Parse(Request.QueryString["elecId"].ToString());
                    DataTable tblResult = objResult.GetPartiesResult(elec);
                    if (tblResult.Rows.Count > 0)
                    {
                        GvParty.DataSource = tblResult;
                        GvParty.DataBind();
                    }
                }
            }
        }
    }
}