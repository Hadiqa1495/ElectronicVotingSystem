﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class UnionCouncil : System.Web.UI.Page
    {
        AdministrativeUnitModel objAdminUnit = new AdministrativeUnitModel();
        DistrictModel objDistrict = new DistrictModel();
        ConstituencyModel objConstituency = new ConstituencyModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (ddlAdminUnit.Items.Count > 0)
                {
                    DataTable tblAdminUnit = objAdminUnit.GetAdminUnit();
                    ddlAdminUnit.DataSource = tblAdminUnit;
                    ddlAdminUnit.DataValueField = tblAdminUnit.Columns["administrativeUnit_Id"].ToString();
                    ddlAdminUnit.DataTextField = tblAdminUnit.Columns["administrativeUnit_Name"].ToString();
                    ddlAdminUnit.DataBind();
                }
            }
            else
            {
                ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                ddlLGCons.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            }
        }

        protected void ddlAdminUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.Clear();
            ListItem first = new ListItem("Select District", "0");
            ddlDistrict.Items.Add(first);
            ddlDistrict.Items.FindByValue("0").Selected = true;
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            gvConstituency.Visible = false;
            pnlHeading.Visible = false;
            int adminId = int.Parse(ddlAdminUnit.SelectedValue);
            if (ddlDistrict.Items.Count > 0)
            {
                DataTable tblDistrict = objDistrict.GetDistrictByAdminUnit(adminId);
                ddlDistrict.DataSource = tblDistrict;
                ddlDistrict.DataTextField = tblDistrict.Columns["district_Name"].ToString();
                ddlDistrict.DataValueField = tblDistrict.Columns["district_Id"].ToString();
                ddlDistrict.DataBind();
            }
        }

        protected void btnAddConstituency_Click(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            if (Page.IsValid)
            {
                int parentId = int.Parse(ddlLGCons.SelectedValue);
                string number = "";
                string name = txtUCName.Text;
                int LGindex = ddlLGCons.SelectedIndex;
                DataTable tblLG = (DataTable)ViewState["tblLG"];
                int LGtype = int.Parse(tblLG.Rows[--LGindex]["constituency_ConstituencyTypeId"].ToString());
                int consType;
                if (LGtype == 3)
                {
                    consType = int.Parse("6");
                }
                else
                {
                    consType = int.Parse("8");
                }
                bool success = objConstituency.SaveConstituency(number, name, parentId, consType);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "Constituency added successfully.";
                    lblMsg.CssClass = "label label-success";

                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to add Constituency.";
                    lblMsg.CssClass = "label label-warning";
                }
                BindGridView();
            }
        }

        protected void gvConstituency_RowEditing(object sender, GridViewEditEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvConstituency.EditIndex = e.NewEditIndex;
            gvConstituency.DataSource = ViewState["tblUCConstituency"];
            gvConstituency.DataBind();
        }

        protected void gvConstituency_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvConstituency.EditIndex = -1;
            gvConstituency.DataSource = ViewState["tblUCConstituency"];
            gvConstituency.DataBind();
        }

        protected void gvConstituency_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            if (Page.IsValid)
            {
                int id = int.Parse(((HiddenField)gvConstituency.Rows[e.RowIndex].FindControl("hfConstituency")).Value);
                string number = "";
                string name = ((TextBox)gvConstituency.Rows[e.RowIndex].FindControl("txtName")).Text;
                int parentId = int.Parse(ddlLGCons.SelectedValue);
                Boolean success = objConstituency.UpdateConstituency(id, number, name, parentId);

                if (success)
                {
                    lblMsg.Text = "Constituency updated successfully.";
                    lblMsg.CssClass = "label label-success";
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to update Constituency.";
                    lblMsg.CssClass = "label label-warning";
                }
                gvConstituency.EditIndex = -1;
                BindGridView();
            }
        }

        protected void gvConstituency_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int distId = int.Parse(ddlDistrict.SelectedValue);
            int id = int.Parse(((HiddenField)gvConstituency.Rows[e.RowIndex].FindControl("hfConstituency")).Value);
            Boolean success = objConstituency.DeleteConstituency(id);
            if (success)
            {
                lblMsg.Text = "Constituency deleted successfully.";
                lblMsg.CssClass = "label label-success";
            }
            else
            {
                lblMsg.Text = "Sorry! Failed to delete Constituency.";
                lblMsg.CssClass = "label label-warning";
            }
            int parentId = int.Parse(ddlDistrict.SelectedValue);
            gvConstituency.EditIndex = -1;
            BindGridView();
        }
        
        private void BindGridView()
        {
            int LGindex = ddlLGCons.SelectedIndex;
            DataTable tblLG = (DataTable)ViewState["tblLG"];
            int LGtype = int.Parse(tblLG.Rows[--LGindex]["constituency_ConstituencyTypeId"].ToString());
            int consType;
            if (LGtype == 3)
            {
                consType = int.Parse("6");
            }
            else
            {
                consType = int.Parse("8");
            }
            int parentId = int.Parse(ddlLGCons.SelectedValue);
            DataTable tblUCConstituency = objConstituency.GetConstituencyByParentId(parentId, consType);
            if (tblUCConstituency.Rows.Count > 0)
            {
                pnlHeading.Visible = true;
                gvConstituency.Visible = true;
                gvConstituency.DataSource = tblUCConstituency;
                ViewState["tblUCConstituency"] = tblUCConstituency;
                gvConstituency.DataBind();
            }
            else
            {
                pnlHeading.Visible = false;
                gvConstituency.Visible = false;
            }
        }

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindLGCons();
        }

        private void BindLGCons()
        {
            pnlHeading.Visible = false;
            gvConstituency.Visible = false;
            ddlLGCons.Items.Clear();
            ListItem first = new ListItem("Select Local Government Constituency", "0");
            ddlLGCons.Items.Add(first);
            ddlLGCons.Items.FindByValue("0").Selected = true;
            ddlLGCons.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int distId = int.Parse(ddlDistrict.SelectedValue);
            if (ddlLGCons.Items.Count > 0)
            {
                DataTable tblLG = objConstituency.GetConstituencyForUC(distId);
                ddlLGCons.DataSource = tblLG;
                ViewState["tblLG"] = tblLG;
                ddlLGCons.DataTextField = tblLG.Columns["constituency_Name"].ToString();
                ddlLGCons.DataValueField = tblLG.Columns["constituency_Id"].ToString();
                ddlLGCons.DataBind();
            }
        }

        protected void ddlLGCons_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGridView();
        }

        protected void cv_ServerValidate(object source, ServerValidateEventArgs args)
        {
            int parentId = int.Parse(ddlLGCons.SelectedValue);
            string number = "";
            string name = txtUCName.Text;
            int LGindex = ddlLGCons.SelectedIndex;
            DataTable tblLG = (DataTable)ViewState["tblLG"];
            int LGtype = int.Parse(tblLG.Rows[--LGindex]["constituency_ConstituencyTypeId"].ToString());
            int consType;
            if (LGtype == 3)
            {
                consType = int.Parse("6");
            }
            else
            {
                consType = int.Parse("8");
            }
            DataTable unitExist = objConstituency.GetConstituencyByNumberName(number, name, parentId, consType);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void cv_ServerValidate1(object source, ServerValidateEventArgs args)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            string Name = args.Value;
            GridViewRow gvr = (GridViewRow)((CustomValidator)source).Parent.Parent;
            int index = gvr.RowIndex;
            string number = "";
            int parentId = int.Parse(ddlLGCons.SelectedValue);
            int Id = int.Parse(((HiddenField)gvConstituency.Rows[index].FindControl("hfConstituency")).Value);
            int LGindex = ddlLGCons.SelectedIndex;
            DataTable tblLG = (DataTable)ViewState["tblLG"];
            int LGtype = int.Parse(tblLG.Rows[--LGindex]["constituency_ConstituencyTypeId"].ToString());
            int consType;
            if (LGtype == 3)
            {
                consType = int.Parse("6");
            }
            else
            {
                consType = int.Parse("8");
            }
            DataTable unitExist = objConstituency.GetConstituencyByIdNumberName(Id, number, Name, parentId, consType);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void gvConstituency_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvConstituency.PageIndex = e.NewPageIndex;
            gvConstituency.DataSource = ViewState["tblUCConstituency"];
            gvConstituency.DataBind();
        }
    }
}