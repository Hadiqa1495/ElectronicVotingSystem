﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class SearchArea : System.Web.UI.Page
    {
        BlockModel objArea = new BlockModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataTable tblArea = objArea.GetArea();
                if (tblArea.Rows.Count > 0)
                {
                    gvArea.Visible = true;
                    gvArea.DataSource = tblArea;
                    ViewState["tblArea"] = tblArea;
                    gvArea.DataBind();
                    lblMsg.Text = "";
                }
                else
                {
                    lblMsg.Text = "Sorry ! No Record Exists";
                    lblMsg.CssClass = "label label-warning";
                    gvArea.Visible = false;
                }
            }
        }

        protected void gvArea_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvArea.PageIndex = e.NewPageIndex;
            gvArea.DataSource = ViewState["tblArea"];
            gvArea.DataBind();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string search = txtSearch.Text;
            if (search != null)
            {
                DataTable tblArea = objArea.GetAreaReport(search);
                if (tblArea.Rows.Count > 0)
                {
                    gvArea.Visible = true;
                    gvArea.DataSource = tblArea;
                    ViewState["tblArea"] = tblArea;
                    gvArea.DataBind();
                    lblMsg.Text = "";
                }
                else
                {
                    lblMsg.Text = "Sorry ! No Record Found";
                    lblMsg.CssClass = "label label-warning";
                    gvArea.Visible = false;
                }
            }
        }
    }
}