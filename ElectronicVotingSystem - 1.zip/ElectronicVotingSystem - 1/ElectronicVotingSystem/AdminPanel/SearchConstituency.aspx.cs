﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class SearchConstituency : System.Web.UI.Page
    {
        ConstituencyModel objCons = new ConstituencyModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataTable tblCons = objCons.GetConstitency();
                if (tblCons.Rows.Count > 0)
                {
                    gvConstituency.Visible = true;
                    gvConstituency.DataSource = tblCons;
                    ViewState["tblCons"] = tblCons;
                    gvConstituency.DataBind();
                    lblMsg.Text = "";
                }
                else
                {
                    lblMsg.Text = "Sorry ! No Record Exists";
                    lblMsg.CssClass = "label label-warning";
                    gvConstituency.Visible = false;
                }
            }
        }

        protected void gvConstituency_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvConstituency.PageIndex = e.NewPageIndex;
            gvConstituency.DataSource = ViewState["tblCons"];
            gvConstituency.DataBind();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string search = txtSearch.Text;
            if (search != null)
            {
                DataTable tblCons = objCons.GetConstitencyReport(search);
                if (tblCons.Rows.Count > 0)
                {
                    gvConstituency.Visible = true;
                    gvConstituency.DataSource = tblCons;
                    ViewState["tblCons"] = tblCons;
                    gvConstituency.DataBind();
                    lblMsg.Text = "";
                }
                else
                {
                    lblMsg.Text = "Sorry ! No Record Found";
                    lblMsg.CssClass = "label label-warning";
                    gvConstituency.Visible = false;
                }
            }
        }
    }
}