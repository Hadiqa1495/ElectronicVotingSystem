﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ElectronicVotingSystem.DataAccess;
using System.IO;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class EditVoter : System.Web.UI.Page
    {
        AdministrativeUnitModel objAdminUnit = new AdministrativeUnitModel();
        DistrictModel objDistrict = new DistrictModel();
        TehsilModel objTehsil = new TehsilModel();
        MauzaModel objMauza = new MauzaModel();
        BlockModel objBlock = new BlockModel();
        VoterModel objVoter = new VoterModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindAdminUnit();
                panelVoter.Visible = false;
                panelButtons.Visible = false;
            }
            else
            {
                //ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                //ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                //ddlMauza.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                //ddlBlock.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            }
        }

        protected void ddlAdminUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            clearDistrictList(); clearTehsilList(); clearMauzaList(); clearBlockList();

            BindDistrict();
        }

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            clearTehsilList(); clearMauzaList(); clearBlockList();

            BindTehsil();
        }

        protected void ddlTehsil_SelectedIndexChanged(object sender, EventArgs e)
        {
            clearMauzaList(); clearBlockList();

            BindMauza();
        }

        protected void ddlMauza_SelectedIndexChanged(object sender, EventArgs e)
        {
            clearBlockList();

            BindBlock();
        }

        protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
        {
            cvImage.Text = "";
            string fileExtension = System.IO.Path.GetExtension(fuImage.FileName);
            int fileSize = fuImage.PostedFile.ContentLength;
            if (fileExtension.ToLower() != ".jpg" && fileExtension.ToLower() != ".png" && fileExtension.ToLower() != ".jpeg")
            {
                cvImage.Text = cvImage.Text + "Only .jpg, .png and .jpeg are allowed.";
                args.IsValid = false;
            }
            else if (fileSize > 1024 * 1024)
            {
                cvImage.Text = cvImage.Text + "Image size (10KB) exceeded.";
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string cnic = txtSearch.Text;
            DataTable tblVoter = objVoter.GetVoterByCnic(cnic);
            if (tblVoter.Rows.Count > 0)
            {
                panelVoter.Visible = true;
                panelButtons.Visible = true;

                imgVoter.ImageUrl = "DisplayVoterImage.ashx?imgId=" + tblVoter.Rows[0]["voter_CNIC"];
                ViewState["imgName"] = tblVoter.Rows[0]["voter_ImageName"].ToString();
                ViewState["imgType"] = tblVoter.Rows[0]["voter_ImageType"].ToString();
                ViewState["imgContent"] = tblVoter.Rows[0]["voter_ImageContent"];
                lblName.Text = tblVoter.Rows[0]["voter_FirstName"].ToString() + " " + tblVoter.Rows[0]["voter_LastName"].ToString();
                lblCnic.Text = tblVoter.Rows[0]["voter_CNIC"].ToString();

                ddlAdminUnit.SelectedValue = tblVoter.Rows[0]["administrativeUnit_Id"].ToString();
                BindDistrict();
                ddlDistrict.SelectedValue = tblVoter.Rows[0]["district_Id"].ToString();
                BindTehsil();
                ddlTehsil.SelectedValue = tblVoter.Rows[0]["tehsil_Id"].ToString();
                BindMauza();
                ddlMauza.SelectedValue = tblVoter.Rows[0]["mauza_Id"].ToString();
                BindBlock();
                ddlBlock.SelectedValue = tblVoter.Rows[0]["voter_BlockId"].ToString();

                hfVoter.Value = tblVoter.Rows[0]["voter_Id"].ToString();
                txtFirstName.Text = tblVoter.Rows[0]["voter_FirstName"].ToString();
                txtLastName.Text = tblVoter.Rows[0]["voter_LastName"].ToString();
                txtDob.Text = ((DateTime)tblVoter.Rows[0]["voter_DateOfBirth"]).ToShortDateString();
                rbGender.SelectedValue = tblVoter.Rows[0]["voter_Gender"].ToString();
                rblReligion.SelectedValue = tblVoter.Rows[0]["voter_Religion"].ToString();
                txtHouse.Text = tblVoter.Rows[0]["voter_HouseNo"].ToString();
                txtStreet.Text = tblVoter.Rows[0]["voter_Street"].ToString();
                txtMobile.Text = tblVoter.Rows[0]["voter_Mobile"].ToString();
            }
            else
            {
                panelVoter.Visible = false;
                panelButtons.Visible = false;
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                string imgName;
                string imageType;
                byte[] n_Image_Size;
                if (fuImage.HasFile)
                {
                    n_Image_Size = new byte[fuImage.PostedFile.ContentLength];
                    HttpPostedFile Posted_Image = fuImage.PostedFile;
                    Posted_Image.InputStream.Read(n_Image_Size, 0, (int)fuImage.PostedFile.ContentLength);
                    imgName = fuImage.PostedFile.FileName;

                    imageType = fuImage.PostedFile.ContentType;
                }

                else
                {
                    imgName = ViewState["imgName"].ToString();
                    imageType = ViewState["imgType"].ToString();
                    n_Image_Size = (byte[])ViewState["imgContent"];
                }
                int id = int.Parse(hfVoter.Value);
                string fName = txtFirstName.Text;
                string lNAme = txtLastName.Text;
                DateTime dob = DateTime.Parse(txtDob.Text);
                string cnic = lblCnic.Text;
                string gender = rbGender.SelectedItem.Value;
                string religion = rblReligion.SelectedItem.Value;
                int house = int.Parse(txtHouse.Text);
                string street = txtStreet.Text;
                string mobile = txtMobile.Text;
                int blockId = int.Parse(ddlBlock.SelectedValue);
                bool success = objVoter.UpdateVoter(id, fName, lNAme, dob, gender, religion, house, street, mobile, imgName, imageType, n_Image_Size, blockId);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "Voter updated successfully!";
                    lblMsg.CssClass = "label label-success";
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to update voter.";
                    lblMsg.CssClass = "label label-warning";
                }
            }
        }

        protected void btnDel_Click(object sender, EventArgs e)
        {
            int id = int.Parse(hfVoter.Value);
            string imgPath = imgVoter.ImageUrl.ToString();
            var filePath = Server.MapPath(imgPath);
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
            }
            bool success = objVoter.DeleteVoter(id);
            // Display status message
            if (success)
            {
                panelVoter.Visible = false;
                fuImage.Visible = false;
                btnUpdate.Visible = false;
                btnDel.Visible = false;
                lblMsg.Text = "Voter deleted successfully!";
                lblMsg.CssClass = "label label-success";
            }
            else
            {
                lblMsg.Text = "Sorry! Failed to delete voter.";
                lblMsg.CssClass = "label label-warning";
            }
        }

        private void clearDistrictList()
        {
            ddlDistrict.Items.Clear();
            ListItem first = new ListItem("Select District", "0");
            ddlDistrict.Items.Add(first);
            ddlDistrict.Items.FindByValue("0").Selected = true;
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
        }

        private void clearTehsilList()
        {
            ddlTehsil.Items.Clear();
            ListItem first = new ListItem("Select Tehsil", "0");
            ddlTehsil.Items.Add(first);
            ddlTehsil.Items.FindByValue("0").Selected = true;
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
        }

        private void clearMauzaList()
        {
            ddlMauza.Items.Clear();
            ListItem first = new ListItem("Select Electoral Area", "0");
            ddlMauza.Items.Add(first);
            ddlMauza.Items.FindByValue("0").Selected = true;
            ddlMauza.Items.FindByValue("0").Attributes.Add("style", "display:none;");
        }

        private void clearBlockList()
        {
            ddlBlock.Items.Clear();
            ListItem first = new ListItem("Select Block", "0");
            ddlBlock.Items.Add(first);
            ddlBlock.Items.FindByValue("0").Selected = true;
            ddlBlock.Items.FindByValue("0").Attributes.Add("style", "display:none;");
        }

        private void BindAdminUnit()
        {
            DataTable tblAdminUnit = objAdminUnit.GetAdminUnit();
            if (tblAdminUnit.Rows.Count > 0)
            {
                ddlAdminUnit.DataSource = tblAdminUnit;
                ddlAdminUnit.DataValueField = "administrativeUnit_Id";
                ddlAdminUnit.DataTextField = "administrativeUnit_Name";
                ddlAdminUnit.DataBind();
            }
        }

        private void BindDistrict()
        {
            int adminUnit = int.Parse(ddlAdminUnit.SelectedValue);
            DataTable tblDistrict = objDistrict.GetDistrictByAdminUnit(adminUnit);
            if (tblDistrict.Rows.Count > 0)
            {
                ddlDistrict.DataSource = tblDistrict;
                ddlDistrict.DataValueField = tblDistrict.Columns["district_Id"].ToString();
                ddlDistrict.DataTextField = tblDistrict.Columns["district_Name"].ToString();
                ddlDistrict.DataBind();
            }
        }

        private void BindTehsil()
        {
            int distId = int.Parse(ddlDistrict.SelectedValue);
            DataTable tblTehsil = objTehsil.GetTehsilByDistrictId(distId);
            if (tblTehsil.Rows.Count > 0)
            {
                ddlTehsil.DataSource = tblTehsil;
                ddlTehsil.DataValueField = tblTehsil.Columns["tehsil_Id"].ToString();
                ddlTehsil.DataTextField = tblTehsil.Columns["tehsil_Name"].ToString();
                ddlTehsil.DataBind();
            }
        }

        private void BindMauza()
        {
            int tehsilId = int.Parse(ddlTehsil.SelectedValue);
            DataTable tblMauza = objMauza.GetMauzaByTehsilId(tehsilId);

            if (tblMauza.Rows.Count > 0)
            {
                ddlMauza.DataSource = tblMauza;
                ddlMauza.DataValueField = tblMauza.Columns["mauza_Id"].ToString();
                ddlMauza.DataTextField = tblMauza.Columns["mauza_Name"].ToString();
                ddlMauza.DataBind();
            }
        }

        private void BindBlock()
        {
            int mauzaId = int.Parse(ddlMauza.SelectedValue);
            DataTable tblBlock = objBlock.GetBlockByMauzaId(mauzaId);
            if (tblBlock.Rows.Count > 0)
            {
                ddlBlock.DataSource = tblBlock;
                ddlBlock.DataTextField = "block_Number";
                ddlBlock.DataValueField = "block_Id";
                ddlBlock.DataBind();
            }
        }
    }
}