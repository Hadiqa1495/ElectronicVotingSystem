﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace ElectronicVotingSystem.AdminPanel.UserControls
{
    public partial class ucAddMember : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void cvEmail_ServerValidate(object source, ServerValidateEventArgs args)
        {
            int roleId = int.Parse(((DropDownList)ucMemberList1.FindControl("ddlMember")).SelectedValue);
            string email = txtEmail.Text;
            DataTable emailExist = MemberModel.GetMemberByEmail(roleId,email);
            if(emailExist.Rows.Count>0){
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }
    }
}