﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ElectronicVotingSystem.DataAccess;

namespace ElectronicVotingSystem.AdminPanel.UserControls
{
    public partial class ucMemberList : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (ddlMember.Items.Count == 1)
            {
                DataTable tblMember = MemberModel.GetRole();
                ddlMember.DataSource = tblMember;
                ddlMember.DataValueField = tblMember.Columns["role_Id"].ToString();
                ddlMember.DataTextField = tblMember.Columns["role_Name"].ToString();
                ddlMember.DataBind();
            }
        }
    }
}