﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class ConstituencyBlock : System.Web.UI.Page
    {
        AdministrativeUnitModel objAdminUnit = new AdministrativeUnitModel();
        DistrictModel objDistrict = new DistrictModel();
        TehsilModel objTehsil = new TehsilModel();
        MauzaModel objMauza = new MauzaModel();
        BlockModel objBlock = new BlockModel();
        ElectionModel objElection = new ElectionModel();
        ConstituencyModel objConstituency = new ConstituencyModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (ddlAdminUnit.Items.Count > 0)
                {
                    DataTable tblAdminUnit = objAdminUnit.GetAdminUnit();
                    ddlAdminUnit.DataSource = tblAdminUnit;
                    ddlAdminUnit.DataValueField = tblAdminUnit.Columns["administrativeUnit_Id"].ToString();
                    ddlAdminUnit.DataTextField = tblAdminUnit.Columns["administrativeUnit_Name"].ToString();
                    ddlAdminUnit.DataBind();
                }
                if (ddlElectionType.Items.Count > 0)
                {
                    DataTable tblElectionType = objElection.GetElectionType();
                    ddlElectionType.DataSource = tblElectionType;
                    ViewState["tblElectionType"] = tblElectionType;
                    ddlElectionType.DataValueField = tblElectionType.Columns["electionType_Id"].ToString();
                    ddlElectionType.DataTextField = tblElectionType.Columns["electionType_Name"].ToString();
                    ddlElectionType.DataBind();
                }
                ddlUC.Visible = false;
                ddlWard.Visible = false;
                ddlNA.Visible = false;
                ddlPA.Visible = false;
                lblNA.Visible = false;
                lblPA.Visible = false;
                lblUC.Visible = false;
                lblWard.Visible = false;
                ddlLGCons.Visible = false;
                lblLG.Visible = false;
            }
            else
            {
                ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                ddlMauza.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                ddlBlock.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                ddlElectionType.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                ddlUC.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                ddlWard.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                ddlNA.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                if (ddlLGCons.Items.Count != 0)
                {
                    ddlLGCons.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                }
                ddlPA.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            }
        }

        protected void ddlAdminUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlUC.Visible = false;
            ddlWard.Visible = false;
            ddlNA.Visible = false;
            ddlPA.Visible = false;
            lblNA.Visible = false;
            lblPA.Visible = false;
            lblUC.Visible = false;
            lblWard.Visible = false;
            ddlLGCons.Visible = false;
            lblLG.Visible = false;

            ddlDistrict.Items.Clear();
            ListItem first = new ListItem("Select District", "0");
            ddlDistrict.Items.Add(first);
            ddlDistrict.Items.FindByValue("0").Selected = true;
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlTehsil.Items.Clear();
            first = new ListItem("Select Tehsil", "0");
            ddlTehsil.Items.Add(first);
            ddlTehsil.Items.FindByValue("0").Selected = true;
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlMauza.Items.Clear();
            first = new ListItem("Select Electoral Area", "0");
            ddlMauza.Items.Add(first);
            ddlMauza.Items.FindByValue("0").Selected = true;
            ddlMauza.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlBlock.Items.Clear();
            first = new ListItem("Select Block Code", "0");
            ddlBlock.Items.Add(first);
            ddlBlock.Items.FindByValue("0").Selected = true;
            ddlBlock.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlNA.Items.Clear();
            first = new ListItem("Select National Assembly Constituency", "0");
            ddlNA.Items.Add(first);
            ddlNA.Items.FindByValue("0").Selected = true;
            ddlNA.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlPA.Items.Clear();
            first = new ListItem("Select Provincial Assembly Constituency", "0");
            ddlPA.Items.Add(first);
            ddlPA.Items.FindByValue("0").Selected = true;
            ddlPA.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlUC.Items.Clear();
            first = new ListItem("Select Union Council", "0");
            ddlUC.Items.Add(first);
            ddlUC.Items.FindByValue("0").Selected = true;
            ddlUC.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlWard.Items.Clear();
            first = new ListItem("Select Ward", "0");
            ddlWard.Items.Add(first);
            ddlWard.Items.FindByValue("0").Selected = true;
            ddlWard.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlLGCons.Items.Clear();
            first = new ListItem("Select Local Government Constituency", "0");
            ddlLGCons.Items.Add(first);
            ddlLGCons.Items.FindByValue("0").Selected = true;
            ddlLGCons.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvBlock.Visible = false;
            pnlHeading.Visible = false;

            int id = int.Parse(ddlAdminUnit.SelectedValue);
            DataTable adminId = objAdminUnit.GetAdminUnitTypeByAdminUnit(id);
            DataTable tblDistrict = objDistrict.GetDistrictByAdminUnit(id);
            if (tblDistrict.Rows.Count > 0)
            {
                ddlDistrict.DataSource = tblDistrict;
                ddlDistrict.DataValueField = tblDistrict.Columns["district_Id"].ToString();
                ddlDistrict.DataTextField = tblDistrict.Columns["district_Name"].ToString();
                ddlDistrict.DataBind();
            }
        }

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlTehsil.Items.Clear();
            ListItem first = new ListItem("Select Tehsil", "0");
            ddlTehsil.Items.Add(first);
            ddlTehsil.Items.FindByValue("0").Selected = true;
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlMauza.Items.Clear();
            first = new ListItem("Select Electoral Area", "0");
            ddlMauza.Items.Add(first);
            ddlMauza.Items.FindByValue("0").Selected = true;
            ddlMauza.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlBlock.Items.Clear();
            first = new ListItem("Select Block Code", "0");
            ddlBlock.Items.Add(first);
            ddlBlock.Items.FindByValue("0").Selected = true;
            ddlBlock.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlNA.Items.Clear();
            first = new ListItem("Select National Assembly Constiuency", "0");
            ddlNA.Items.Add(first);
            ddlNA.Items.FindByValue("0").Selected = true;
            ddlNA.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlLGCons.Items.Clear();
            first = new ListItem("Select Local Government Constituency", "0");
            ddlLGCons.Items.Add(first);
            ddlLGCons.Items.FindByValue("0").Selected = true;
            ddlLGCons.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            gvBlock.Visible = false;
            pnlHeading.Visible = false;

            int distId = int.Parse(ddlDistrict.SelectedValue);
            DataTable tblTehsil = objTehsil.GetTehsilByDistrictId(distId);
            if (tblTehsil.Rows.Count > 0)
            {
                ddlTehsil.DataSource = tblTehsil;
                ddlTehsil.DataValueField = tblTehsil.Columns["tehsil_Id"].ToString();
                ddlTehsil.DataTextField = tblTehsil.Columns["tehsil_Name"].ToString();
                ddlTehsil.DataBind();
            }
            if (int.Parse(ddlElectionType.SelectedValue) != 0)
            {
                if (int.Parse(ddlElectionType.SelectedValue) == 14)
                {
                    if (int.Parse(ddlAdminUnit.SelectedValue) != 9)
                    {
                        BindNAList();
                        BindPAList();
                    }
                    else
                    {
                        BindNAList();
                    }
                }
                else
                {
                    BindLGCons();
                }
            }

        }

        protected void ddlTehsil_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlMauza.Items.Clear();
            ListItem first = new ListItem("Select Electoral Area", "0");
            ddlMauza.Items.Add(first);
            ddlMauza.Items.FindByValue("0").Selected = true;
            ddlMauza.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlBlock.Items.Clear();
            first = new ListItem("Select Block Code", "0");
            ddlBlock.Items.Add(first);
            ddlBlock.Items.FindByValue("0").Selected = true;
            ddlBlock.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            
            int tehsilId = int.Parse(ddlTehsil.SelectedValue);
            DataTable tblMauza = objMauza.GetMauzaByTehsilId(tehsilId);
            if (tblMauza.Rows.Count > 0)
            {
                ddlMauza.DataSource = tblMauza;
                ddlMauza.DataValueField = tblMauza.Columns["mauza_Id"].ToString();
                ddlMauza.DataTextField = tblMauza.Columns["mauza_Name"].ToString();
                ddlMauza.DataBind();
            }
            BindGridView();
        }

        protected void ddlMauza_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlBlock.Items.Clear();
            ListItem first = new ListItem("Select Block Code", "0");
            ddlBlock.Items.Add(first);
            ddlBlock.Items.FindByValue("0").Selected = true;
            ddlBlock.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            
            int mauzaId = int.Parse(ddlMauza.SelectedValue);
            DataTable tblBlock = objBlock.GetBlockByMauzaId(mauzaId);
            if (tblBlock.Rows.Count > 0)
            {
                ddlBlock.DataSource = tblBlock;
                ddlBlock.DataValueField = tblBlock.Columns["block_Id"].ToString();
                ddlBlock.DataTextField = tblBlock.Columns["block_Number"].ToString();
                ddlBlock.DataBind();
            }
        }

        protected void ddlElectionType_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlUC.Visible = false;
            ddlWard.Visible = false;
            ddlPA.Visible = false;
            ddlNA.Visible = false;
            lblNA.Visible = false;
            lblPA.Visible = false;
            lblUC.Visible = false;
            lblWard.Visible = false;
            ddlNA.Visible = false;
            lblLG.Visible = false;
            ddlLGCons.Visible = false;

            int adminId = int.Parse(ddlAdminUnit.SelectedValue);
            ddlLGCons.Items.Clear();
            ListItem first = new ListItem("Select Local Government Constituency", "0");
            ddlLGCons.Items.Add(first);
            ddlLGCons.Items.FindByValue("0").Selected = true;
            ddlLGCons.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvBlock.Visible = false;
            pnlHeading.Visible = false;

            int etId = int.Parse(ddlElectionType.SelectedValue);
            int distId = int.Parse(ddlDistrict.SelectedValue);
            if (etId == 14)
            {
                if (adminId == 14 || adminId == 9)
                {
                    if (distId != 0)
                    {
                        BindNAList();
                    }
                }
                else
                {
                    if (distId != 0)
                    {
                        BindNAList();
                        BindPAList();
                    }
                }
            }

            else
            {
                BindLGCons();
            }
        }

        protected void ddlUC_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindWardList();
            BindGridView();
        }

        protected void ddlWard_SelectedIndexChanged(object sender, EventArgs e)
        {
            gvBlock.Visible = true;
            BindGridView();
        }

        protected void ddlPA_SelectedIndexChanged(object sender, EventArgs e)
        {
            gvBlock.Visible = true;
            BindGridView();
        }

        protected void ddlNA_SelectedIndexChanged(object sender, EventArgs e)
        {
            int consTypeId = int.Parse(ddlNA.SelectedValue);
            int adminId = int.Parse(ddlAdminUnit.SelectedValue);
            if (adminId == (int.Parse("14")) || adminId == (int.Parse("9")))
            {
                gvBlock.Visible = true;
                BindGridView();
            }
            else
            {
                BindPAList();
            }
        }

        protected void btn_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                int etId = int.Parse(ddlElectionType.SelectedValue);
                int blockId = int.Parse(ddlBlock.SelectedValue);
                int constituency;
                if (ddlWard.Visible == true)
                {
                    constituency = int.Parse(ddlWard.SelectedValue);
                }
                else if (ddlUC.Visible == true)
                {
                    constituency = int.Parse(ddlUC.SelectedValue);
                }
                else if (ddlPA.Visible == true)
                {
                    constituency = int.Parse(ddlPA.SelectedValue);
                }
                else
                {
                    constituency = int.Parse(ddlNA.SelectedValue);
                }
                bool success = objConstituency.SaveConstituencyBlock(blockId, constituency);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "Block added successfully!";
                    lblMsg.CssClass = "label label-success";
                    BindGridView();
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to add block.";
                    lblMsg.CssClass = "label label-warning";
                }
            }
        }

        protected void gvBlock_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = int.Parse(((HiddenField)gvBlock.Rows[e.RowIndex].FindControl("hfId")).Value);

            Boolean success = objConstituency.DeleteConstituencyBlock(id);
            gvBlock.EditIndex = -1;
            if (success)
            {
                lblMsg.Text = "Block deleted successfully!";
                lblMsg.CssClass = "label label-success";
                BindGridView();
            }
            else
            {
                lblMsg.Text = "Sorry! Failed to delete block.";
                lblMsg.CssClass = "label label-warning";
            }
        }

        private void BindNAList()
        {
            int parentId = int.Parse(ddlDistrict.SelectedValue);
            int consTypeId = int.Parse("1");
            if (parentId != 0 && consTypeId != 0)
            {
                lblNA.Visible = true;
                ddlNA.Visible = true;
                rfvNA.Visible = true;
                ddlNA.Items.Clear();
                ListItem first = new ListItem("Select National Assembly Constituency", "0");
                ddlNA.Items.Add(first);
                ddlNA.Items.FindByValue("0").Selected = true;
                ddlNA.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                gvBlock.Visible = false;

                DataTable tblNA = objConstituency.GetConstituencyByParentId(parentId, consTypeId);
                if (tblNA.Rows.Count > 0)
                {
                    tblNA.Columns.Add("NAconstituency", typeof(string), "constituency_Number + ' ' + constituency_Name");
                    ddlNA.DataSource = tblNA;
                    ddlNA.DataTextField = "NAconstituency";
                    ddlNA.DataValueField = "constituency_Id";
                    ddlNA.DataBind();
                }
            }
            else
            {
                lblNA.Visible = false;
                ddlNA.Visible = false;
            }
        }

        private void BindPAList()
        {
            lblPA.Visible = true;
            ddlPA.Visible = true;
            rfvPA.Visible = true;
            ddlPA.Items.Clear();
            ListItem first = new ListItem("Select Provincial Assembly Constituency", "0");
            ddlPA.Items.Add(first);
            ddlPA.Items.FindByValue("0").Selected = true;
            ddlPA.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvBlock.Visible = false;
            int NAId = int.Parse(ddlNA.SelectedValue);
            int consTypeId = int.Parse("2");
            DataTable tblPA = objConstituency.GetConstituencyByParentId(NAId, consTypeId);
            if (tblPA.Rows.Count > 0)
            {
                tblPA.Columns.Add("PAconstituency", typeof(string), "constituency_Number + ' ' + constituency_Name");
                ddlPA.DataSource = tblPA;
                ViewState["tblPA"] = tblPA;
                ddlPA.DataTextField = "PAconstituency";
                ddlPA.DataValueField = "constituency_Id";
                ddlPA.DataBind();
            }
        }

        private void BindUCList()
        {
            lblUC.Visible = true;
            ddlUC.Visible = true;
            rfvUC.Visible = true;
            ddlUC.Items.Clear();
            ListItem first = new ListItem("Select Union Council", "0");
            ddlUC.Items.Add(first);
            ddlUC.Items.FindByValue("0").Selected = true;
            ddlUC.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            int parentId = int.Parse(ddlLGCons.SelectedValue);


            gvBlock.Visible = false;

            DataTable tblUC = objConstituency.GetUCByLGCons(parentId);
            if (tblUC.Rows.Count > 0)
            {
                ddlUC.DataSource = tblUC;
                ViewState["tblUC"] = tblUC;
                ddlUC.DataValueField = tblUC.Columns["constituency_Id"].ToString();
                ddlUC.DataTextField = tblUC.Columns["constituency_Name"].ToString();
                ddlUC.DataBind();
            }
        }

        private void BindWardList()
        {
            rfvNA.Visible = false;
            rfvPA.Visible = false;
           
            lblWard.Visible = true;
            ddlWard.Visible = true;
            ddlWard.Items.Clear();
            ListItem first = new ListItem("Select Ward", "0");
            ddlWard.Items.Add(first);
            ddlWard.Items.FindByValue("0").Selected = true;
            ddlWard.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvBlock.Visible = false;
            pnlHeading.Visible = false;

            int LGCons;
            if (ddlUC.Visible == true)
            {
                LGCons = int.Parse(ddlUC.SelectedValue);
                rfvUC.Visible = true;
            }
            else
            {
                LGCons = int.Parse(ddlLGCons.SelectedValue);
                rfvUC.Visible = false;
            }
            DataTable tblWard = objConstituency.GetUCByLGCons(LGCons);
            if (tblWard.Rows.Count > 0)
            {
                ddlWard.DataSource = tblWard;
                ViewState["tblWard"] = tblWard;
                ddlWard.DataValueField = tblWard.Columns["constituency_Id"].ToString();
                ddlWard.DataTextField = tblWard.Columns["constituency_Name"].ToString();
                ddlWard.DataBind();
            }
        }

        private void BindLGCons()
        {
            lblLG.Visible = true;
            ddlLGCons.Visible = true;
            rfvLG.Visible = true;
            ddlLGCons.Items.Clear();
            ListItem first = new ListItem("Select Local Government Constituency", "0");
            ddlLGCons.Items.Add(first);
            ddlLGCons.Items.FindByValue("0").Selected = true;
            ddlLGCons.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int distId = int.Parse(ddlDistrict.SelectedValue);
            if (ddlLGCons.Items.Count > 0)
            {
                DataTable tblLG = objConstituency.GetConstituency(distId);
                ddlLGCons.DataSource = tblLG;
                ViewState["tblLG"] = tblLG;
                ddlLGCons.DataTextField = tblLG.Columns["constituency_Name"].ToString();
                ddlLGCons.DataValueField = tblLG.Columns["constituency_Id"].ToString();
                ddlLGCons.DataBind();
            }

        }

        private void BindGridView()
        {
            int constituency;
            if (ddlWard.Visible == true)
            {
                constituency = int.Parse(ddlWard.SelectedValue);
            }
            else if (ddlUC.Visible == true)
            {
                constituency = int.Parse(ddlUC.SelectedValue);
            }
            else if (ddlPA.Visible == true)
            {
                constituency = int.Parse(ddlPA.SelectedValue);
            }
            else
            {
                constituency = int.Parse(ddlNA.SelectedValue);
            }
            if (constituency != 0)
            {
                DataTable tblBlock = objConstituency.GetConstituencyBlock(constituency);
                ViewState["tblBlock"] = tblBlock;
                if (tblBlock.Rows.Count > 0)
                {
                    gvBlock.Visible = true;
                    gvBlock.DataSource = tblBlock;
                    gvBlock.DataBind();
                    pnlHeading.Visible = true;
                }
                else
                {
                    pnlHeading.Visible = false;
                    gvBlock.Visible = false;
                }
            }
        }

        protected void ddlLGCons_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblUC.Visible = false;
            lblWard.Visible = false;
            ddlWard.Visible = false;
            ddlUC.Visible = false;
            int index = ddlLGCons.SelectedIndex;
            DataTable tblLG = (DataTable)ViewState["tblLG"];
            int type = int.Parse(tblLG.Rows[--index]["constituency_ConstituencyTypeId"].ToString());
            if (type == 5)
            {
                BindWardList();
            }
            else
            {
                BindUCList();
            }

        }

        protected void cv_ServerValidate(object source, ServerValidateEventArgs args)
        {
            int blockId = int.Parse(ddlBlock.SelectedValue);

            int eType = int.Parse(ddlElectionType.SelectedValue);
            DataTable unitExist = objConstituency.GetCVConstituencyBlock(blockId, eType);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void gvBlock_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvBlock.PageIndex = e.NewPageIndex;
            gvBlock.DataSource = ViewState["tblBlock"];
            gvBlock.DataBind();
        }
    }
}