﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.AdminPanel
{
    /// <summary>
    /// Summary description for DisplayVoterImage
    /// </summary>
    public class DisplayVoterImage : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            VoterModel objVoter = new VoterModel();
            HttpRequest request = context.Request;
            HttpResponse response = context.Response;
            try
            {
                string id = (request.QueryString["imgId"]).ToString();
                DataTable dt = objVoter.GetVoterByCnic(id);
                if (dt != null)
                {
                    Byte[] bytes = (Byte[])dt.Rows[0]["voter_ImageContent"];
                    response.Buffer = true;
                    response.Charset = "";
                    response.Cache.SetCacheability(HttpCacheability.NoCache);
                    response.ContentType = dt.Rows[0]["voter_ImageType"].ToString();
                    response.BinaryWrite(bytes);
                    response.Flush();
                    response.End();
                }
            }
            catch
            {

            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

    }
}