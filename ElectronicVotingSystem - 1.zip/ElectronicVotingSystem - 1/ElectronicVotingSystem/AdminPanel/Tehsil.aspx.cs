﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class Tehsil : System.Web.UI.Page
    {
        AdministrativeUnitModel objAdminUnit = new AdministrativeUnitModel();
        DistrictModel objDistrict = new DistrictModel();
        TehsilModel objTehsil = new TehsilModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (ddlAdminUnit.Items.Count > 0)
                {
                    DataTable tblAdminUnit = objAdminUnit.GetAdminUnit();
                    ddlAdminUnit.DataSource = tblAdminUnit;
                    ddlAdminUnit.DataValueField = tblAdminUnit.Columns["administrativeUnit_Id"].ToString();
                    ddlAdminUnit.DataTextField = tblAdminUnit.Columns["administrativeUnit_Name"].ToString();
                    ddlAdminUnit.DataBind();
                }
            }
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
        }

        protected void cvDistrict_ServerValidate(object source, ServerValidateEventArgs args)
        {
            int distId = int.Parse(ddlDistrict.SelectedValue);
            string name = txtTehsil.Text;
            DataTable unitExist = objTehsil.GetTehsilByNameDistrictId(name, distId);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void btnTehsil_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                int distId = int.Parse(ddlDistrict.SelectedValue);
                string name = txtTehsil.Text;
                bool success = objTehsil.SaveTehsil(name, distId);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "Tehsil added successfully.";
                    lblMsg.CssClass = "label label-success";
                    txtTehsil.Text = "";
                    BindGridview();
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to add tehsil.";
                    lblMsg.CssClass = "label label-warning";
                }
            }
        }

        protected void ddlAdminUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            pnlHeading.Visible = false;
            gvTehsil.Visible = false;
            int adminUnit = int.Parse(ddlAdminUnit.SelectedValue);
            DataTable tblDistrict = objDistrict.GetDistrictByAdminUnit(adminUnit);
            if (tblDistrict.Rows.Count > 0)
            {
                ddlDistrict.Items.Clear();
                ListItem first = new ListItem("Select District", "0");
                ddlDistrict.Items.Add(first);
                ddlDistrict.DataSource = tblDistrict;
                ddlDistrict.DataValueField = tblDistrict.Columns["district_Id"].ToString();
                ddlDistrict.DataTextField = tblDistrict.Columns["district_Name"].ToString();
                ddlDistrict.DataBind();
                ddlDistrict.Items.FindByValue("0").Selected = true;
                ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            }
        }

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGridview();
        }

        protected void cvDistrict_ServerValidate1(object source, ServerValidateEventArgs args)
        {
            string Name = args.Value;
            GridViewRow gvr = (GridViewRow)((CustomValidator)source).Parent.Parent;
            int index = gvr.RowIndex;
            int Id = int.Parse(((HiddenField)gvTehsil.Rows[index].FindControl("hfTehsil")).Value);
            int distId = int.Parse(ddlDistrict.SelectedValue);
            DataTable unitExist = objTehsil.GetTehsilByIdNameDistrictId(Id, Name, distId);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void gvTehsil_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvTehsil.EditIndex = e.NewEditIndex;
            gvTehsil.DataSource = ViewState["tblTehsil"];
            gvTehsil.DataBind();
        }

        protected void gvTehsil_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvTehsil.EditIndex = -1;
            gvTehsil.DataSource = ViewState["tblTehsil"];
            gvTehsil.DataBind();
        }

        protected void gvTehsil_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            if (Page.IsValid)
            {
                int id = int.Parse(((HiddenField)gvTehsil.Rows[e.RowIndex].FindControl("hfTehsil")).Value);
                string name = ((TextBox)gvTehsil.Rows[e.RowIndex].FindControl("txtName")).Text;
                int distId = int.Parse(ddlDistrict.SelectedValue);
                Boolean success = objTehsil.UpdateTehsil(id, name, distId);
                gvTehsil.EditIndex = -1;
                BindGridview();
            }
        }

        protected void gvTehsil_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = int.Parse(((HiddenField)gvTehsil.Rows[e.RowIndex].FindControl("hfTehsil")).Value);
            objTehsil.DeleteTehsil(id);
            gvTehsil.EditIndex = -1;
            BindGridview();
        }

        protected void gvTehsil_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvTehsil.PageIndex = e.NewPageIndex;
            BindGridview();
        }

        private void BindGridview()
        {

            int distId = int.Parse(ddlDistrict.SelectedValue);
            DataTable tblTehsil = objTehsil.GetTehsilByDistrictId(distId);
            ViewState["tblTehsil"] = tblTehsil;
            if (tblTehsil.Rows.Count > 0)
            {
                gvTehsil.Visible = true;
                gvTehsil.DataSource = tblTehsil;
                gvTehsil.DataBind();
                pnlHeading.Visible = true;
            }
            else
            {
                pnlHeading.Visible = false;
                gvTehsil.Visible = false;
            }
        }
    }
}