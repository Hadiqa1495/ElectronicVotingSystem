﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class Block : System.Web.UI.Page
    {
        AdministrativeUnitModel objAdminUnit = new AdministrativeUnitModel();
        DistrictModel objDistrict = new DistrictModel();
        TehsilModel objTehsil = new TehsilModel();
        ChargeModel objCharge = new ChargeModel();
        CircleModel objCircle = new CircleModel();
        MauzaModel objMauza = new MauzaModel();
        BlockModel objBlock = new BlockModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (ddlAdminUnit.Items.Count > 0)
                {
                    DataTable tblAdminUnit = objAdminUnit.GetAdminUnit();
                    ddlAdminUnit.DataSource = tblAdminUnit;
                    ddlAdminUnit.DataValueField = tblAdminUnit.Columns["administrativeUnit_Id"].ToString();
                    ddlAdminUnit.DataTextField = tblAdminUnit.Columns["administrativeUnit_Name"].ToString();
                    ddlAdminUnit.DataBind();
                }
            }
        }

        protected void ddlAdminUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.Clear();
            ListItem first = new ListItem("Select District", "0");
            ddlDistrict.Items.Add(first);
            ddlDistrict.Items.FindByValue("0").Selected = true;
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlTehsil.Items.Clear();
            first = new ListItem("Select Tehsil", "0");
            ddlTehsil.Items.Add(first);
            ddlTehsil.Items.FindByValue("0").Selected = true;
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlCharge.Items.Clear();
            first = new ListItem("Select Charge", "0");
            ddlCharge.Items.Add(first);
            ddlCharge.Items.FindByValue("0").Selected = true;
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlCircle.Items.Clear();
            first = new ListItem("Select Circle", "0");
            ddlCircle.Items.Add(first);
            ddlCircle.Items.FindByValue("0").Selected = true;
            ddlCircle.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlMauza.Items.Clear();
            first = new ListItem("Select Electoral Area", "0");
            ddlMauza.Items.Add(first);
            ddlMauza.Items.FindByValue("0").Selected = true;
            ddlMauza.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvBlock.Visible = false;
            pnlHeading.Visible = false;

            int adminUnit = int.Parse(ddlAdminUnit.SelectedValue);
            DataTable tblDistrict = objDistrict.GetDistrictByAdminUnit(adminUnit);
            if (tblDistrict.Rows.Count > 0)
            {
                ddlDistrict.DataSource = tblDistrict;
                ddlDistrict.DataValueField = tblDistrict.Columns["district_Id"].ToString();
                ddlDistrict.DataTextField = tblDistrict.Columns["district_Name"].ToString();
                ddlDistrict.DataBind();
            }
        }

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlTehsil.Items.Clear();
            ListItem first = new ListItem("Select Tehsil", "0");
            ddlTehsil.Items.Add(first);
            ddlTehsil.Items.FindByValue("0").Selected = true;
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlCharge.Items.Clear();
            first = new ListItem("Select Charge", "0");
            ddlCharge.Items.Add(first);
            ddlCharge.Items.FindByValue("0").Selected = true;
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlCircle.Items.Clear();
            first = new ListItem("Select Circle", "0");
            ddlCircle.Items.Add(first);
            ddlCircle.Items.FindByValue("0").Selected = true;
            ddlCircle.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlMauza.Items.Clear();
            first = new ListItem("Select Electoral Area", "0");
            ddlMauza.Items.Add(first);
            ddlMauza.Items.FindByValue("0").Selected = true;
            ddlMauza.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvBlock.Visible = false;
            pnlHeading.Visible = false;

            int distId = int.Parse(ddlDistrict.SelectedValue);
            DataTable tblTehsil = objTehsil.GetTehsilByDistrictId(distId);
            if (tblTehsil.Rows.Count > 0)
            {
                ddlTehsil.DataSource = tblTehsil;
                ddlTehsil.DataValueField = tblTehsil.Columns["tehsil_Id"].ToString();
                ddlTehsil.DataTextField = tblTehsil.Columns["tehsil_Name"].ToString();
                ddlTehsil.DataBind();
            }
        }

        protected void ddlTehsil_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlCharge.Items.Clear();
            ListItem first = new ListItem("Select Charge", "0");
            ddlCharge.Items.Add(first);
            ddlCharge.Items.FindByValue("0").Selected = true;
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlCircle.Items.Clear();
            first = new ListItem("Select Circle", "0");
            ddlCircle.Items.Add(first);
            ddlCircle.Items.FindByValue("0").Selected = true;
            ddlCircle.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            ddlMauza.Items.Clear();
            first = new ListItem("Select Electoral Area", "0");
            ddlMauza.Items.Add(first);
            ddlMauza.Items.FindByValue("0").Selected = true;
            ddlMauza.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvBlock.Visible = false;
            pnlHeading.Visible = false;

            int tehsilId = int.Parse(ddlTehsil.SelectedValue);
            DataTable tblCharge = objCharge.GetChargeByTehsilId(tehsilId);
            if (tblCharge.Rows.Count > 0)
            {
                ddlCharge.DataSource = tblCharge;
                ddlCharge.DataValueField = tblCharge.Columns["charge_Id"].ToString();
                ddlCharge.DataTextField = tblCharge.Columns["charge_Name"].ToString();
                ddlCharge.DataBind();
            }
            DataTable tblMauza = objMauza.GetMauzaByTehsilId(tehsilId);
            if (tblMauza.Rows.Count > 0)
            {
                ddlMauza.DataSource = tblMauza;
                ddlMauza.DataValueField = tblMauza.Columns["mauza_Id"].ToString();
                ddlMauza.DataTextField = tblMauza.Columns["mauza_Name"].ToString();
                ddlMauza.DataBind();
            }
        }

        protected void ddlCharge_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCircle.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlMauza.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvBlock.Visible = false;
            pnlHeading.Visible = false;
            int chargeId = int.Parse(ddlCharge.SelectedValue);
            DataTable tblCircle = objCircle.GetCircleByChargeId(chargeId);
            if (tblCircle.Rows.Count > 0)
            {
                ddlCircle.DataSource = tblCircle;
                ddlCircle.DataValueField = tblCircle.Columns["circle_Id"].ToString();
                ddlCircle.DataTextField = tblCircle.Columns["circle_Name"].ToString();
                ddlCircle.DataBind();
            }
        }

        protected void ddlMauza_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCircle.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlMauza.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int circleId = int.Parse(ddlCircle.SelectedValue);
            int mauzaId = int.Parse(ddlMauza.SelectedValue);
            if (circleId != 0 && mauzaId != 0)
            {
                DataTable tblBlock = objBlock.GetBlockByMauzaIdCircleId(mauzaId, circleId);
                ViewState["tblBlock"] = tblBlock;
                if (tblBlock.Rows.Count > 0)
                {
                    pnlHeading.Visible = true;
                    gvBlock.Visible = true;
                    gvBlock.DataSource = tblBlock;
                    gvBlock.DataBind();
                }
                else
                {
                    pnlHeading.Visible = false;
                    gvBlock.Visible = false;
                }
            }
        }

        protected void ddlCircle_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCircle.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlMauza.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int circleId = int.Parse(ddlCircle.SelectedValue);
            int mauzaId = int.Parse(ddlMauza.SelectedValue);
            if (circleId != 0 && mauzaId != 0)
            {
                DataTable tblBlock = objBlock.GetBlockByMauzaIdCircleId(mauzaId, circleId);
                ViewState["tblBlock"] = tblBlock;
                if (tblBlock.Rows.Count > 0)
                {
                    pnlHeading.Visible = true;
                    gvBlock.Visible = true;
                    gvBlock.DataSource = tblBlock;
                    gvBlock.DataBind();
                }
                else
                {
                    pnlHeading.Visible = false;
                    gvBlock.Visible = false;
                }
            }
        }

        protected void cv_ServerValidate(object source, ServerValidateEventArgs args)
        {
            int circleId = int.Parse(ddlCircle.SelectedValue);
            int mauzaId = int.Parse(ddlMauza.SelectedValue);
            int number = int.Parse(txtName.Text);
            DataTable unitExist = objBlock.GetBlockByNumberMauzaIdCircleId(number, mauzaId, circleId);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void btn_Click(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCircle.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlMauza.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            if (Page.IsValid)
            {
                int circleId = int.Parse(ddlCircle.SelectedValue);
                int mauzaId = int.Parse(ddlMauza.SelectedValue);
                int number = int.Parse(txtName.Text);
                bool success = objBlock.SaveBlock(number, mauzaId, circleId);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "Block added successfully!";
                    lblMsg.CssClass = "label label-success";

                    if (circleId != 0 && mauzaId != 0)
                    {
                        DataTable tblBlock = objBlock.GetBlockByMauzaIdCircleId(mauzaId, circleId);
                        ViewState["tblBlock"] = tblBlock;
                        if (tblBlock.Rows.Count > 0)
                        {
                            gvBlock.Visible = true;
                            gvBlock.DataSource = tblBlock;
                            gvBlock.DataBind();
                        }
                        else
                        {
                            gvBlock.Visible = false;
                        }
                    }
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to add block.";
                    lblMsg.CssClass = "label label-warning";
                }
            }
        }

        protected void cv_ServerValidate1(object source, ServerValidateEventArgs args)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCircle.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int Number = int.Parse(args.Value);
            GridViewRow gvr = (GridViewRow)((CustomValidator)source).Parent.Parent;
            int index = gvr.RowIndex;
            int Id = int.Parse(((HiddenField)gvBlock.Rows[index].FindControl("hfId")).Value);

            int circleId = int.Parse(ddlCircle.SelectedValue);
            int mauzaId = int.Parse(ddlMauza.SelectedValue);

            DataTable unitExist = objBlock.GetBlockByIdNumberMauzaIdCircleId(Id, Number, mauzaId, circleId);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void gvBlock_RowEditing(object sender, GridViewEditEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCircle.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvBlock.EditIndex = e.NewEditIndex;
            gvBlock.DataSource = ViewState["tblBlock"];
            gvBlock.DataBind();
        }

        protected void gvBlock_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCircle.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvBlock.EditIndex = -1;
            gvBlock.DataSource = ViewState["tblBlock"];
            gvBlock.DataBind();
        }

        protected void gvBlock_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCircle.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            if (Page.IsValid)
            {
                int id = int.Parse(((HiddenField)gvBlock.Rows[e.RowIndex].FindControl("hfId")).Value);
                int number = int.Parse(((TextBox)gvBlock.Rows[e.RowIndex].FindControl("txtName")).Text);
                int circleId = int.Parse(ddlCircle.SelectedValue);
                int mauzaId = int.Parse(ddlMauza.SelectedValue);

                Boolean success = objBlock.UpdateBlock(id, number, mauzaId, circleId);
                gvBlock.EditIndex = -1;
                if (success)
                {
                    lblMsg.Text = "Block updated successfully!";
                    lblMsg.CssClass = "label label-success";

                    if (circleId != 0 && mauzaId != 0)
                    {
                        DataTable tblBlock = objBlock.GetBlockByMauzaIdCircleId(mauzaId, circleId);
                        ViewState["tblBlock"] = tblBlock;
                        if (tblBlock.Rows.Count > 0)
                        {
                            gvBlock.Visible = true;
                            gvBlock.DataSource = tblBlock;
                            gvBlock.DataBind();
                        }
                        else
                        {
                            gvBlock.Visible = false;
                        }
                    }
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to update block.";
                    lblMsg.CssClass = "label label-warning";
                }
            }
        }

        protected void gvBlock_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlTehsil.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCharge.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            ddlCircle.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int id = int.Parse(((HiddenField)gvBlock.Rows[e.RowIndex].FindControl("hfId")).Value);
            int circleId = int.Parse(ddlCircle.SelectedValue);
            int mauzaId = int.Parse(ddlMauza.SelectedValue);

            Boolean success = objBlock.DeleteBlock(id);
            gvBlock.EditIndex = -1;
            if (success)
            {
                lblMsg.Text = "Block deleted successfully!";
                lblMsg.CssClass = "label label-success";

                if (circleId != 0 && mauzaId != 0)
                {
                    DataTable tblBlock = objBlock.GetBlockByMauzaIdCircleId(mauzaId, circleId);
                    ViewState["tblBlock"] = tblBlock;
                    if (tblBlock.Rows.Count > 0)
                    {
                        gvBlock.Visible = true;
                        gvBlock.DataSource = tblBlock;
                        gvBlock.DataBind();
                    }
                    else
                    {
                        gvBlock.Visible = false;
                    }
                }
            }
            else
            {
                lblMsg.Text = "Sorry! Failed to delete block.";
                lblMsg.CssClass = "label label-warning";
            }
        }

        protected void gvBlock_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvBlock.PageIndex = e.NewPageIndex;
            gvBlock.DataSource = ViewState["tblBlock"];
            gvBlock.DataBind();
        }

    }
}