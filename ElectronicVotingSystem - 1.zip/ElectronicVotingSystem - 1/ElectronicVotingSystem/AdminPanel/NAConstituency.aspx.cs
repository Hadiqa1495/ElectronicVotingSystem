﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class NAConstituency : System.Web.UI.Page
    {
        AdministrativeUnitModel objAdminUnit = new AdministrativeUnitModel();
        DistrictModel objDistrict = new DistrictModel();
        ConstituencyModel objConstituency = new ConstituencyModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (ddlAdminUnit.Items.Count > 0)
                {
                    DataTable tblAdminUnit = objAdminUnit.GetAdminUnit();
                    ddlAdminUnit.DataSource = tblAdminUnit;
                    ddlAdminUnit.DataValueField = tblAdminUnit.Columns["administrativeUnit_Id"].ToString();
                    ddlAdminUnit.DataTextField = tblAdminUnit.Columns["administrativeUnit_Name"].ToString();
                    ddlAdminUnit.DataBind();
                }
            }
            else
            {
                ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            }
        }

        protected void ddlAdminUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.Clear();
            ListItem first = new ListItem("Select District", "0");
            ddlDistrict.Items.Add(first);
            ddlDistrict.Items.FindByValue("0").Selected = true;
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvConstituency.Visible = false;
            pnlHeading.Visible = false;

            int adminId = int.Parse(ddlAdminUnit.SelectedValue);
            if (ddlDistrict.Items.Count > 0)
            {
                DataTable tblDistrict = objDistrict.GetDistrictByAdminUnit(adminId);
                ddlDistrict.DataSource = tblDistrict;
                ddlDistrict.DataTextField = tblDistrict.Columns["district_Name"].ToString();
                ddlDistrict.DataValueField = tblDistrict.Columns["district_Id"].ToString();
                ddlDistrict.DataBind();
            }
        }

        protected void btnAddConstituency_Click(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            if (Page.IsValid)
            {
                int distId = int.Parse(ddlDistrict.SelectedValue);
                string number = txtConstituencyNumber.Text;
                string name = txtConstituencyName.Text;
                int consType = int.Parse("1");
                bool success = objConstituency.SaveConstituency(number, name, distId, consType);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "Constituency added successfully.";
                    lblMsg.CssClass = "label label-success";

                    BindGridView();
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to add Constituency.";
                    lblMsg.CssClass = "label label-warning";
                }
            }
        }

        protected void gvConstituency_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvConstituency.EditIndex = e.NewEditIndex;
            BindGridView();
        }

        protected void gvConstituency_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvConstituency.EditIndex = -1;
            BindGridView();
        }

        protected void gvConstituency_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            if (Page.IsValid)
            {
                int id = int.Parse(((HiddenField)gvConstituency.Rows[e.RowIndex].FindControl("hfConstituency")).Value);
                string number = ((TextBox)gvConstituency.Rows[e.RowIndex].FindControl("txtConstituencyNumber")).Text;
                string name = ((TextBox)gvConstituency.Rows[e.RowIndex].FindControl("txtName")).Text;
                int districtId = int.Parse(ddlDistrict.SelectedValue);
                Boolean success = objConstituency.UpdateConstituency(id, number, name, districtId);

                if (success)
                {
                    lblMsg.Text = "Constituency updated successfully.";
                    lblMsg.CssClass = "label label-success";
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to update Constituency.";
                    lblMsg.CssClass = "label label-warning";
                }
                gvConstituency.EditIndex = -1;
                BindGridView();
            }
        }

        protected void gvConstituency_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int distId = int.Parse(ddlDistrict.SelectedValue);
            int id = int.Parse(((HiddenField)gvConstituency.Rows[e.RowIndex].FindControl("hfConstituency")).Value);
            Boolean success = objConstituency.DeleteConstituency(id);
            if (success)
            {
                lblMsg.Text = "Constituency deleted successfully.";
                lblMsg.CssClass = "label label-success";
            }
            else
            {
                lblMsg.Text = "Sorry! Failed to delete Constituency.";
                lblMsg.CssClass = "label label-warning";
            }
            gvConstituency.EditIndex = -1;
            BindGridView();
        }

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGridView();
        }
        private void BindGridView()
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int distId = int.Parse(ddlDistrict.SelectedValue);
            int consTypeId = int.Parse("1");
            DataTable tblNAConstituency = objConstituency.GetConstituencyByParentId(distId, consTypeId);
            if (tblNAConstituency.Rows.Count > 0)
            {
                pnlHeading.Visible = true;
                gvConstituency.Visible = true;
                gvConstituency.DataSource = tblNAConstituency;
                ViewState["tblLGConstituency"] = tblNAConstituency;
                gvConstituency.DataBind();
            }
            else
            {
                pnlHeading.Visible = false;
                gvConstituency.Visible = false;
            }
        }

        protected void cv_ServerValidate(object source, ServerValidateEventArgs args)
        {
            int parentId = int.Parse(ddlDistrict.SelectedValue);
            string number = txtConstituencyNumber.Text;
            string name = txtConstituencyName.Text;
            int consType = 1;
            DataTable unitExist = objConstituency.GetConstituencyByNumberName(number, name, parentId, consType);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void cv_ServerValidate1(object source, ServerValidateEventArgs args)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            string Name = args.Value;
            GridViewRow gvr = (GridViewRow)((CustomValidator)source).Parent.Parent;
            int index = gvr.RowIndex;
            string number = (((TextBox)gvConstituency.Rows[index].FindControl("txtConstituencyNumber")).Text);
            int parentId = int.Parse(ddlDistrict.SelectedValue);
            int Id = int.Parse(((HiddenField)gvConstituency.Rows[index].FindControl("hfConstituency")).Value);
            int consType = 1;
            DataTable unitExist = objConstituency.GetConstituencyByIdNumberName(Id, number, Name, parentId, consType);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void gvConstituency_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvConstituency.PageIndex = e.NewPageIndex;
            gvConstituency.DataSource = ViewState["tblLGConstituency"];
            gvConstituency.DataBind();
        }

    }
}