﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class Ward : System.Web.UI.Page
    {
        AdministrativeUnitModel objAdminUnit = new AdministrativeUnitModel();
        DistrictModel objDistrict = new DistrictModel();
        ConstituencyModel objConstituency = new ConstituencyModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (ddlAdminUnit.Items.Count > 0)
                {
                    DataTable tblAdminUnit = objAdminUnit.GetAdminUnit();
                    ddlAdminUnit.DataSource = tblAdminUnit;
                    ddlAdminUnit.DataValueField = tblAdminUnit.Columns["administrativeUnit_Id"].ToString();
                    ddlAdminUnit.DataTextField = tblAdminUnit.Columns["administrativeUnit_Name"].ToString();
                    ddlAdminUnit.DataBind();
                }
                ddlUC.Visible = false;
                lblUC.Visible = false;
            }
            else
            {
                ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                ddlLGCons.Items.FindByValue("0").Attributes.Add("style", "display:none;");
                ddlUC.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            }
        }

        protected void ddlAdminUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.Clear();
            ListItem first = new ListItem("Select District", "0");
            ddlDistrict.Items.Add(first);
            ddlDistrict.Items.FindByValue("0").Selected = true;
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            gvConstituency.Visible = false;
            pnlHeading.Visible = false;
            int adminId = int.Parse(ddlAdminUnit.SelectedValue);
            if (ddlDistrict.Items.Count > 0)
            {
                DataTable tblDistrict = objDistrict.GetDistrictByAdminUnit(adminId);
                ddlDistrict.DataSource = tblDistrict;
                ddlDistrict.DataTextField = tblDistrict.Columns["district_Name"].ToString();
                ddlDistrict.DataValueField = tblDistrict.Columns["district_Id"].ToString();
                ddlDistrict.DataBind();
            }
        }

        protected void btnAddConstituency_Click(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            if (Page.IsValid)
            {
                int LGindex = ddlLGCons.SelectedIndex;
                DataTable tblLG = (DataTable)ViewState["tblLG"];
                int LGtype = int.Parse(tblLG.Rows[--LGindex]["constituency_ConstituencyTypeId"].ToString());
                int consType;
                if (LGtype == 3)
                {
                    consType = int.Parse("7");
                }
                else if (LGtype == 4)
                {
                    consType = int.Parse("9");
                }
                else
                {
                    consType = int.Parse("10");
                }
                int distId = int.Parse(ddlDistrict.SelectedValue);
                string number = "";
                string name = txtWardName.Text;
                int LGCons;
                if (ddlUC.Visible == true)
                {
                    LGCons = int.Parse(ddlUC.SelectedValue);
                }
                else
                {
                    LGCons = int.Parse(ddlLGCons.SelectedValue);
                }

                bool success = objConstituency.SaveConstituency(number, name, LGCons, consType);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "Constituency added successfully.";
                    lblMsg.CssClass = "label label-success";

                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to add Constituency.";
                    lblMsg.CssClass = "label label-warning";
                }
                BindGridView();
            }
        }

        protected void gvConstituency_RowEditing(object sender, GridViewEditEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvConstituency.EditIndex = e.NewEditIndex;
            BindGridView();
        }

        protected void gvConstituency_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            gvConstituency.EditIndex = -1;
            BindGridView();
        }

        protected void gvConstituency_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            if (Page.IsValid)
            {
                int id = int.Parse(((HiddenField)gvConstituency.Rows[e.RowIndex].FindControl("hfConstituency")).Value);
                string number = "";
                string name = ((TextBox)gvConstituency.Rows[e.RowIndex].FindControl("txtName")).Text;
                int LGindex = ddlLGCons.SelectedIndex;
                DataTable tblLG = (DataTable)ViewState["tblLG"];
                int LGtype = int.Parse(tblLG.Rows[--LGindex]["constituency_ConstituencyTypeId"].ToString());
                int parentId;
                if (LGtype == 3 || LGtype == 4)
                {
                    parentId = int.Parse(ddlUC.SelectedValue);
                }
                else
                {
                    parentId = int.Parse(ddlLGCons.SelectedValue);
                }
                Boolean success = objConstituency.UpdateConstituency(id, number, name, parentId);

                if (success)
                {
                    lblMsg.Text = "Constituency updated successfully.";
                    lblMsg.CssClass = "label label-success";
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to update Constituency.";
                    lblMsg.CssClass = "label label-warning";
                }
                gvConstituency.EditIndex = -1;
                BindGridView();
            }
        }

        protected void gvConstituency_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int distId = int.Parse(ddlDistrict.SelectedValue);
            int id = int.Parse(((HiddenField)gvConstituency.Rows[e.RowIndex].FindControl("hfConstituency")).Value);
            Boolean success = objConstituency.DeleteConstituency(id);
            if (success)
            {
                lblMsg.Text = "Constituency deleted successfully.";
                lblMsg.CssClass = "label label-success";
            }
            else
            {
                lblMsg.Text = "Sorry! Failed to delete Constituency.";
                lblMsg.CssClass = "label label-warning";
            }
            gvConstituency.EditIndex = -1;
            BindGridView();
        }
        
        private void BindGridView()
        {
            int LGcons;
            if (ddlUC.Visible == true && int.Parse(ddlUC.SelectedValue) != 0)
            {
                LGcons = int.Parse(ddlUC.SelectedValue);
            }
            else
            {
                LGcons = int.Parse(ddlLGCons.SelectedValue);
            }

            int consType = 0;

            int LGindex = ddlLGCons.SelectedIndex;
            DataTable tblLG = (DataTable)ViewState["tblLG"];
            int LGtype = int.Parse(tblLG.Rows[--LGindex]["constituency_ConstituencyTypeId"].ToString());
            if (LGtype == 3)//Municipal Corp.
            {
                consType = 7;
            }
            else if (LGtype == 4)//District Council
            {
                consType = 9;
            }
            else//Municipal Commitee
            {
                consType = 10;
            }
            DataTable tblWard = objConstituency.GetConstituencyByParentId(LGcons, consType);
            if (tblWard.Rows.Count > 0)
            {
                pnlHeading.Visible = true;
                gvConstituency.Visible = true;
                gvConstituency.DataSource = tblWard;
                ViewState["tblWard"] = tblWard;
                gvConstituency.DataBind();
            }
            else
            {
                pnlHeading.Visible = false;
                gvConstituency.Visible = false;
            }
        }

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");
            BindLGCons();
        }
                
        private void BindLGCons()
        {
            gvConstituency.Visible = false;
            pnlHeading.Visible = false;

            ddlLGCons.Items.Clear();
            ListItem first = new ListItem("Select Local Government Constituency", "0");
            ddlLGCons.Items.Add(first);
            ddlLGCons.Items.FindByValue("0").Selected = true;
            ddlLGCons.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            int distId = int.Parse(ddlDistrict.SelectedValue);
            if (ddlLGCons.Items.Count > 0)
            {
                DataTable tblLG = objConstituency.GetConstituency(distId);
                ddlLGCons.DataSource = tblLG;
                ViewState["tblLG"] = tblLG;
                ddlLGCons.DataTextField = tblLG.Columns["constituency_Name"].ToString();
                ddlLGCons.DataValueField = tblLG.Columns["constituency_Id"].ToString();
                ddlLGCons.DataBind();
            }

        }

        protected void ddlUC_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGridView();
        }

        protected void ddlLGCons_SelectedIndexChanged(object sender, EventArgs e)
        {
            pnlHeading.Visible = false;
            gvConstituency.Visible = false;
            int LGcons = int.Parse(ddlLGCons.SelectedValue);
            int consType = 0;

            int LGindex = ddlLGCons.SelectedIndex;
            DataTable tblLG = (DataTable)ViewState["tblLG"];
            int LGtype = int.Parse(tblLG.Rows[--LGindex]["constituency_ConstituencyTypeId"].ToString());

            if (LGtype == 3)//Municipal Corp.
            {
                consType = 6;
            }
            else if (LGtype == 4)//District Council
            {
                consType = 8;
            }
            else//Municipal Commitee
            {
                consType = 10;
            }

            if (consType == 6 || consType == 8)
            {
                lblUC.Visible = true;
                ddlUC.Visible = true;
                rfvUC.Enabled = true;
                if (ddlUC.Items.Count > 0)
                {
                    ddlUC.Items.Clear();
                    ListItem first = new ListItem("Select Union Council", "0");
                    ddlUC.Items.Add(first);
                    ddlUC.Items.FindByValue("0").Selected = true;
                    ddlUC.Items.FindByValue("0").Attributes.Add("style", "display:none;");

                    DataTable tblUC = objConstituency.GetConstituencyByParentId(LGcons, consType);
                    ddlUC.DataSource = tblUC;
                    ddlUC.DataTextField = tblUC.Columns["constituency_Name"].ToString();
                    ddlUC.DataValueField = tblUC.Columns["constituency_Id"].ToString();
                    ddlUC.DataBind();
                    gvConstituency.Visible = false;
                }
            }
            else
            {
                lblUC.Visible = false;
                ddlUC.Visible = false;
                rfvUC.Enabled = false;
                BindGridView();
            }
        }

        protected void cv_ServerValidate(object source, ServerValidateEventArgs args)
        {
            int LGindex = ddlLGCons.SelectedIndex;
            DataTable tblLG = (DataTable)ViewState["tblLG"];
            int LGtype = int.Parse(tblLG.Rows[--LGindex]["constituency_ConstituencyTypeId"].ToString());

            int consType;
            if (LGtype == 3)
            {
                consType = int.Parse("7");
            }
            else if (LGtype == 4)
            {
                consType = int.Parse("9");
            }
            else
            {
                consType = int.Parse("10");
            }
            string number = "";
            string name = txtWardName.Text;
            int LGCons;
            if (ddlUC.Visible == true)
            {
                LGCons = int.Parse(ddlUC.SelectedValue);
            }
            else
            {
                LGCons = int.Parse(ddlLGCons.SelectedValue);
            }
            DataTable unitExist = objConstituency.GetConstituencyByNumberName(number, name, LGCons, consType);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void cv_ServerValidate1(object source, ServerValidateEventArgs args)
        {
            ddlDistrict.Items.FindByValue("0").Attributes.Add("style", "display:none;");

            string Name = args.Value;
            GridViewRow gvr = (GridViewRow)((CustomValidator)source).Parent.Parent;
            int index = gvr.RowIndex;
            string number = "";
            int Id = int.Parse(((HiddenField)gvConstituency.Rows[index].FindControl("hfConstituency")).Value);
            int consType;
            int LGindex = ddlLGCons.SelectedIndex;
            DataTable tblLG = (DataTable)ViewState["tblLG"];
            int LGtype = int.Parse(tblLG.Rows[--LGindex]["constituency_ConstituencyTypeId"].ToString());
            if (LGtype == 3)
            {
                consType = int.Parse("7");
            }
            else if (LGtype == 4)
            {
                consType = int.Parse("9");
            }
            else
            {
                consType = int.Parse("10");
            }
            int LGCons;
            if (ddlUC.Visible == true)
            {
                LGCons = int.Parse(ddlUC.SelectedValue);
            }
            else
            {
                LGCons = int.Parse(ddlLGCons.SelectedValue);
            }
            DataTable unitExist = objConstituency.GetConstituencyByIdNumberName(Id, number, Name, LGCons, consType);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void gvConstituency_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvConstituency.PageIndex = e.NewPageIndex;
            gvConstituency.DataSource = ViewState["tblWard"];
            gvConstituency.DataBind();
        }
    }
}