﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ElectronicVotingSystem.DataAccess;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.Cookies["UserName"] != null && Request.Cookies["Password"] != null)
                {
                    txtEmail.Text = Request.Cookies["UserName"].Value;
                    txtPassword.Attributes["value"] = Request.Cookies["Password"].Value;
                    ((DropDownList)ucMemberList.FindControl("ddlMember")).SelectedValue = Request.Cookies["Role"].Value;
                    cboxRemember.Checked = true;
                }
            }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            int roleId = int.Parse(((DropDownList)ucMemberList.FindControl("ddlMember")).SelectedValue);
            string email = txtEmail.Text;
            string password = Utilities.GetMd5Hash(txtPassword.Text);
            DataTable LoginInfo = MemberModel.GetMemberByLoginInfo(roleId, email, password);
            if (LoginInfo.Rows.Count > 0)
            {
                Session["userInfo"] = LoginInfo;
                Session["password"] = txtPassword.Text;
                if (cboxRemember.Checked)
                {
                    Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(30);
                    Response.Cookies["Password"].Expires = DateTime.Now.AddDays(30);
                    Response.Cookies["Role"].Expires = DateTime.Now.AddDays(30);
                }
                else
                {
                    Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(-1);
                    Response.Cookies["Password"].Expires = DateTime.Now.AddDays(-1);
                    Response.Cookies["Role"].Expires = DateTime.Now.AddDays(-1);
                }

                Response.Cookies["UserName"].Value = txtEmail.Text.Trim();
                Response.Cookies["Password"].Value = txtPassword.Text.Trim();
                Response.Cookies["Role"].Value = roleId.ToString();

                Response.Redirect("Index.aspx");
            }
            else
            {
                lblMsg.CssClass = "label label-warning";
                lblMsg.Text = "Invalid Username or Password.";
            }

        }
    }
}