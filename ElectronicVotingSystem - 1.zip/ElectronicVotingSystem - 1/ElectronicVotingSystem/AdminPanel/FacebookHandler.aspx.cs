﻿using Facebook;
using System;
using System.Dynamic;
using System.IO;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class FacebookHandler : System.Web.UI.Page
    {
        private string clientId = "400802703639103";
        private string secretId = "090152752a4d2e02465d011539ebd33e";
        private string redirectUri = "http://localhost/evs/AdminPanel/FacebookHandler.aspx";

        protected void Page_Load(object sender, EventArgs e)
        {
            panelPost.Visible = false;

            // Check if already Signed In
            if (Session["AccessToken"] != null)
            {
                // Retrieve user information from database if stored or else create a new FacebookClient with this accesstoken and extract data again.
                var fb = new FacebookClient(Session["AccessToken"].ToString());
                try
                {
                    dynamic me = fb.Get("me?fields=name,email");
                    string email = me.email;

                    lblName.Text = "Welcome " + me.name + "!";

                    panelLogoutDisplay();
                }
                catch (FacebookOAuthException ex)
                {

                }

                try
                {
                    // Calling Graph API for page likes
                    dynamic page = fb.Get("1943551252597378?fields=fan_count");
                    long likes = page.fan_count;
                    lblLikes.Text = likes.ToString() + " Likes";
                }
                catch (FacebookOAuthException ex)
                {
                    // Access Token expired, Ask the user to Login again
                    lblMsg.CssClass = "alert alert-danger";
                    lblMsg.Text = "Sorry there is some error while connecting with facebook!";
                }

            }

            // Check if redirected from facebook
            else if (Request.QueryString["code"] != null)
            {
                string accessCode = Request.QueryString["code"].ToString();

                var fb = new FacebookClient();

                //for user info
                dynamic result = fb.Post("oauth/access_token", new
                {
                    client_id = clientId,
                    client_secret = secretId,
                    redirect_uri = redirectUri,
                    code = accessCode
                });

                var accessToken = result.access_token;
                var expires = result.expires;

                // update the facebook client with the access token 
                fb.AccessToken = result.access_token;

                //for user info
                dynamic pageResult = fb.Get("me/accounts", new
                {
                    access_token = accessToken
                });
                var data = pageResult.data[0];
                var pageName = data.name;
                string pageAccessToken = data.access_token;
                string pageCategory = data.category;
                string pageId = data.id;

                // Store the access token in the session
                Session["AccessToken"] = accessToken;
                Session["PageAccessToken"] = pageAccessToken;

                try
                {
                    // Calling Graph API for user info
                    dynamic me = fb.Get("me?fields=name,email");

                    string id = me.id; // You can store it in the database
                    string email = me.email;
                    lblName.Text = "Welcome " + me.name + "!";

                    panelLogoutDisplay();

                    FormsAuthentication.SetAuthCookie(email, false);

                }
                catch (FacebookOAuthException ex)
                {
                    // Access Token expired, Ask the user to Login again
                    logout();
                    panelLoginDisplay();
                }

                try
                {
                    // Calling Graph API for page likes
                    dynamic page = fb.Get("1943551252597378?fields=fan_count");
                    long likes = page.fan_count;
                    lblLikes.Text = " " + likes.ToString() + " Likes";
                }
                catch (FacebookOAuthException ex)
                {
                    // Access Token expired, Ask the user to Login again
                    lblMsg.CssClass = "alert alert-danger";
                    lblMsg.Text = "Sorry there is some error while connecting with facebook!";
                }
            }

            else if (Request.QueryString["error"] != null)
            {
                string error = Request.QueryString["error"];
                string errorReason = Request.QueryString["error_reason"];
                string errorDescription = Request.QueryString["error_description"];
            }

            else
            {
                // User not connected
                panelLoginDisplay();
            }
        }

        protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (fuImage.HasFile)
            {
                cvImage.Text = "";
                string fileExtension = System.IO.Path.GetExtension(fuImage.FileName);
                int fileSize = fuImage.PostedFile.ContentLength;
                if (fileExtension.ToLower() != ".jpg" && fileExtension.ToLower() != ".png" && fileExtension.ToLower() != ".jpeg")
                {
                    cvImage.Text = cvImage.Text + "Only .jpg, .png and .jpeg are allowed.";
                    args.IsValid = false;
                }
                else if (fileSize > 1024 * 1024)
                {
                    cvImage.Text = cvImage.Text + "Image size (10KB) exceeded.";
                    args.IsValid = false;
                }
                else
                {
                    args.IsValid = true;
                }
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void postImage_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                string access_token = Session["PageAccessToken"].ToString();

                if ((txtContent.Text.ToString() == "") && (fuImage.HasFile == false))
                {
                    lblMsg.CssClass = "alert alert-danger";
                    lblMsg.Text = "Please select an image or enter some text for your post!";
                }
                else
                {
                    dynamic post = new ExpandoObject();
                    post.message = txtContent.Text;

                    if (fuImage.HasFile)
                    {
                        string fullPath = Server.MapPath("~/Uploads/Facebook/" + fuImage.PostedFile.FileName);
                        fuImage.SaveAs(fullPath);

                        var mediaObject = new FacebookMediaObject
                        {
                            ContentType = fuImage.PostedFile.ContentType,
                            FileName = Path.GetFileName(fullPath)
                        }.SetValue(File.ReadAllBytes(fullPath));

                        post.source = mediaObject;

                        var fb = new FacebookClient(access_token);
                        try
                        {
                            var postId = fb.Post("1943551252597378" + "/photos", post);
                            if (postId != null)
                            {
                                lblMsg.CssClass = "alert alert-success";
                                lblMsg.Text = "Posted successfully!";
                            }
                        }
                        catch (FacebookOAuthException ex)
                        {
                            lblMsg.CssClass = "alert alert-danger";
                            lblMsg.Text = "Sorry there is some error while connecting with facebook!";
                        }
                        catch (FacebookApiException ex)
                        {
                            lblMsg.CssClass = "alert alert-danger";
                            lblMsg.Text = "Sorry there is some error while connecting with facebook!";
                        }
                    }
                    else
                    {
                        FacebookClient app = new FacebookClient(access_token);
                        try
                        {
                            var postId = app.Post("1943551252597378" + "/feed", post);
                            if (postId != null)
                            {
                                lblMsg.CssClass = "alert alert-success";
                                lblMsg.Text = "Message posted successfully!";
                            }
                        }
                        catch (FacebookOAuthException ex)
                        {
                            lblMsg.CssClass = "alert alert-danger";
                            lblMsg.Text = "Sorry there is some error while connecting with facebook!";
                        }
                        catch (FacebookApiException ex)
                        {
                            lblMsg.CssClass = "alert alert-danger";
                            lblMsg.Text = "Sorry there is some error while connecting with facebook!";
                        }
                    }
                }
            }
        }

        protected void btnLogin_Click(object sender, ImageClickEventArgs e)
        {
            if (pnlLogin.Visible == true)
            {
                panelLogoutDisplay();

                var fb = new FacebookClient();
                var loginUrl = fb.GetLoginUrl(new
                {
                    client_id = clientId,
                    redirect_uri = redirectUri,
                    response_type = "code",
                    scope = "publish_pages, manage_pages, publish_actions" // Add other permissions as needed
                });
                Response.Redirect(loginUrl.AbsoluteUri);
            }
        }

        protected void btnLogout_Click(object sender, ImageClickEventArgs e)
        {
            if (pnlLogout.Visible == true)
            {
                logout();
                panelLoginDisplay();
            }
        }

        private void logout()
        {
            var fb = new FacebookClient();

            var logoutUrl = fb.GetLogoutUrl(new
            {
                access_token = Session["AccessToken"],
                next = redirectUri,

            });

            // User Logged out, remove access token from session
            Session.Remove("AccessToken");
            Response.Redirect(logoutUrl.AbsoluteUri);
        }

        private void panelLoginDisplay()
        {
            pnlLogin.Visible = true;
            pnlFbImg.Visible = true;
            pnlLogout.Visible = false;
            pnlLikes.Visible = false;
            panelPost.Visible = false;
        }

        private void panelLogoutDisplay()
        {
            pnlLogin.Visible = false;
            pnlFbImg.Visible = false;
            pnlLogout.Visible = true;
            pnlLikes.Visible = true;
            panelPost.Visible = true;
        }
    }
}