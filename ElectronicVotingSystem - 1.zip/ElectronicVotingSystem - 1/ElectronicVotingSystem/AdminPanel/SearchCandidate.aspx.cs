﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class SearchCandidate : System.Web.UI.Page
    {
        CandidateModel objCandidate = new CandidateModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataTable tblCandidate = objCandidate.GetCandidate();
                if (tblCandidate.Rows.Count > 0)
                {
                    gvCandidate.Visible = true;
                    gvCandidate.DataSource = tblCandidate;
                    ViewState["tblCandidate"] = tblCandidate;
                    gvCandidate.DataBind();
                    lblMsg.Text = "";
                }
                else
                {
                    lblMsg.Text = "Sorry ! No Record Exists";
                    lblMsg.CssClass = "label label-warning";
                    gvCandidate.Visible = false;
                }
            }
        }

        protected void gvCandidate_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvCandidate.PageIndex = e.NewPageIndex;
            gvCandidate.DataSource = ViewState["tblCandidate"];
            gvCandidate.DataBind();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string search = txtSearch.Text;
            if (search != null)
            {
                DataTable tblCandidate = objCandidate.GetCandidateReport(search);
                if (tblCandidate.Rows.Count > 0)
                {
                    gvCandidate.Visible = true;
                    gvCandidate.DataSource = tblCandidate;
                    ViewState["tblCandidate"] = tblCandidate;
                    gvCandidate.DataBind();
                    lblMsg.Text = "";
                }
                else
                {
                    lblMsg.Text = "Sorry ! No Record Found";
                    lblMsg.CssClass = "label label-warning";
                    gvCandidate.Visible = false;
                }
            }
        }
    }
}