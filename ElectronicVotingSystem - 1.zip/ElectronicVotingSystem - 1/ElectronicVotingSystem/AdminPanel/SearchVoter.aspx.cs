﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class SearchVoter : System.Web.UI.Page
    {
        VoterModel objVoter = new VoterModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataTable tblVoter = objVoter.GetVoter();
                if (tblVoter.Rows.Count > 0)
                {
                    gvVoter.Visible = true;
                    gvVoter.DataSource = tblVoter;
                    ViewState["tblVoter"] = tblVoter;
                    gvVoter.DataBind();
                    lblMsg.Text = "";
                }
                else
                {
                    lblMsg.Text = "Sorry ! No Record Exists";
                    lblMsg.CssClass = "label label-warning";
                    gvVoter.Visible = false;
                }
            }
        }

        protected void gvVoter_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvVoter.PageIndex = e.NewPageIndex;
            gvVoter.DataSource = ViewState["tblVoter"];
            gvVoter.DataBind();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string search = txtSearch.Text;
            if (search != null)
            {
                DataTable tblVoter = objVoter.GetVoterReport(search);
                if (tblVoter.Rows.Count > 0)
                {
                    gvVoter.Visible = true;
                    gvVoter.DataSource = tblVoter;
                    ViewState["tblVoter"] = tblVoter;
                    gvVoter.DataBind();
                    lblMsg.Text = "";
                }
                else
                {
                    lblMsg.Text = "Sorry ! No Record Found";
                    lblMsg.CssClass = "label label-warning";
                    gvVoter.Visible = false;
                }
            }
        }
    }
}