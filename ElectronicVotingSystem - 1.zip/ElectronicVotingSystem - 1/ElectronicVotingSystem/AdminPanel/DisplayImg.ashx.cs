﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace ElectronicVotingSystem.AdminPanel
{
    /// <summary>
    /// Summary description for DisplayImg
    /// </summary>
    public class DisplayImg : IHttpHandler
    {
        SymbolModel objSymbol = new SymbolModel();
        public void ProcessRequest(HttpContext context)
        {
            HttpRequest request = context.Request;
            HttpResponse response = context.Response;
            try
            {
                int id = Convert.ToInt32(request.QueryString["imgId"]);
                DataTable dt = objSymbol.GetImage(id);
                if (dt != null)
                {
                    Byte[] bytes = (Byte[])dt.Rows[0]["symbol_ImageContent"];
                    response.Buffer = true;
                    response.Charset = "";
                    response.Cache.SetCacheability(HttpCacheability.NoCache);
                    response.ContentType = dt.Rows[0]["symbol_ImageType"].ToString();
                    response.BinaryWrite(bytes);
                    response.Flush();
                    response.End();
                }
            }
            catch
            {

            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

    }
}