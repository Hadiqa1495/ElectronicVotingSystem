﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class Symbol : System.Web.UI.Page
    {
        SymbolModel objSymbol = new SymbolModel();
        DataTable tblSymbol;

        protected void Page_Load(object sender, EventArgs e)
        {
            tblSymbol = objSymbol.GetSymbol();
            if (!IsPostBack)
            {
                if (tblSymbol.Rows.Count > 0)
                {
                    gvSymbol.DataSource = tblSymbol;
                    ViewState["tblSymbol"] = tblSymbol;
                    gvSymbol.DataBind();
                }
                else
                {
                    gvSymbol.Visible = false;
                }
            }
        }

        protected void cvSymbol_ServerValidate(object source, ServerValidateEventArgs args)
        {
            string symbolName = txtAddSymbol.Text;
            DataTable unitExist = objSymbol.GetSymbolByName(symbolName);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
        {
            cvImage.Text = "";
            string fileExtension = System.IO.Path.GetExtension(fuImage.FileName);
            int fileSize = fuImage.PostedFile.ContentLength;
            if (fileExtension.ToLower() != ".jpg" && fileExtension.ToLower() != ".png" && fileExtension.ToLower() != ".jpeg")
            {
                cvImage.Text = cvImage.Text + "Only .jpg, .png and .jpeg are allowed.";
                args.IsValid = false;
            }
            else if (fileSize > 1024 * 1024)
            {
                cvImage.Text = cvImage.Text + "Image size (10KB) exceeded.";
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void btnAddSymbol_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                byte[] n_Image_Size = new byte[fuImage.PostedFile.ContentLength];
                HttpPostedFile Posted_Image = fuImage.PostedFile;
                Posted_Image.InputStream.Read(n_Image_Size, 0, (int)fuImage.PostedFile.ContentLength);
                string imgName = fuImage.PostedFile.FileName;

                string imageType = fuImage.PostedFile.ContentType;

                string addSymbol = txtAddSymbol.Text;
                // Execute the insert command
                bool success = objSymbol.SaveSymbol(addSymbol, imgName, imageType, n_Image_Size);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "Symbol added successfully.";
                    lblMsg.CssClass = "label label-success";
                    txtAddSymbol.Text = "";
                    gvSymbol.Visible = true;
                    tblSymbol = objSymbol.GetSymbol();
                    ViewState["tblSymbol"] = tblSymbol;
                    gvSymbol.DataSource = tblSymbol;
                    gvSymbol.DataBind();
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to add Symbol.";
                    lblMsg.CssClass = "label label-warning";
                }
            }
        }

        protected void cvSymbol_ServerValidate1(object source, ServerValidateEventArgs args)
        {
            string symbolName = args.Value;
            GridViewRow gvr = (GridViewRow)((CustomValidator)source).Parent.Parent;
            int index = gvr.RowIndex;
            int symbolId = int.Parse(((HiddenField)gvSymbol.Rows[index].FindControl("hfSymbolId")).Value);
            DataTable unitExist = objSymbol.GetSymbolByNameSymbolId(symbolId, symbolName);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void cvImage_ServerValidate(object source, ServerValidateEventArgs args)
        {
            GridViewRow gvr = (GridViewRow)((CustomValidator)source).Parent.Parent;
            int index = gvr.RowIndex;
            FileUpload fuImage = new FileUpload();
            fuImage = ((FileUpload)gvSymbol.Rows[index].FindControl("fuImage"));
            CustomValidator cvImage = ((CustomValidator)gvSymbol.Rows[index].FindControl("cvImage"));
            if (fuImage.HasFile)
            {
                cvImage.Text = "";
                string fileExtension = System.IO.Path.GetExtension(fuImage.FileName);
                int fileSize = fuImage.PostedFile.ContentLength;
                if (fileExtension.ToLower() != ".jpg" && fileExtension.ToLower() != ".png" && fileExtension.ToLower() != ".jpeg")
                {
                    cvImage.Text = cvImage.Text + "Only .jpg, .png and .jpeg are allowed.";
                    args.IsValid = false;
                }
                else if (fileSize > 1024 * 1024)
                {
                    cvImage.Text = cvImage.Text + "Image size (10KB) exceeded.";
                    args.IsValid = false;
                }
                else
                {
                    args.IsValid = true;
                }
            }
        }

        protected void gvSymbol_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvSymbol.EditIndex = e.NewEditIndex;
            gvSymbol.DataSource = tblSymbol;
            ViewState["tblSymbol"] = tblSymbol;
            gvSymbol.DataBind();
        }

        protected void gvSymbol_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvSymbol.EditIndex = -1;
            gvSymbol.DataSource = tblSymbol;
            ViewState["tblSymbol"] = tblSymbol;
            gvSymbol.DataBind();
        }

        protected void gvSymbol_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            if (Page.IsValid)
            {
                int id = int.Parse(((HiddenField)gvSymbol.Rows[e.RowIndex].FindControl("hfSymbolId")).Value);
                string name = ((TextBox)gvSymbol.Rows[e.RowIndex].FindControl("txtSymbolName")).Text;

                FileUpload fuImage = (FileUpload)gvSymbol.Rows[e.RowIndex].FindControl("fuImage");
                byte[] n_Image_Size = new byte[fuImage.PostedFile.ContentLength];
                HttpPostedFile Posted_Image = fuImage.PostedFile;
                Posted_Image.InputStream.Read(n_Image_Size, 0, (int)fuImage.PostedFile.ContentLength);
                string imgName = fuImage.PostedFile.FileName;

                string imageType = fuImage.PostedFile.ContentType;

                Boolean success = objSymbol.UpdateSymbolInfo(id, name, imgName, imageType, n_Image_Size);
                if (success)
                {
                    lblMsg.Text = "Symbol updated successfully.";
                    lblMsg.CssClass = "label label-success";
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to update Symbol.";
                    lblMsg.CssClass = "label label-warning";
                }
                gvSymbol.EditIndex = -1;
                tblSymbol = objSymbol.GetSymbol();
                gvSymbol.DataSource = tblSymbol;
                ViewState["tblSymbol"] = tblSymbol;
                gvSymbol.DataBind();
            }
        }

        protected void gvSymbol_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = int.Parse(((HiddenField)gvSymbol.Rows[e.RowIndex].FindControl("hfSymbolId")).Value);

            Boolean success = objSymbol.DeleteSymbol(id);
            if (success)
            {
                lblMsg.Text = "Symbol deleted successfully.";
                lblMsg.CssClass = "label label-success";
            }
            else
            {
                lblMsg.Text = "Sorry! Failed to delete Symbol.";
                lblMsg.CssClass = "label label-warning";
            }
            gvSymbol.EditIndex = -1;
            tblSymbol = objSymbol.GetSymbol();
            gvSymbol.DataSource = tblSymbol;
            ViewState["tblSymbol"] = tblSymbol;
            gvSymbol.DataBind();
        }

        protected void gvSymbol_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvSymbol.PageIndex = e.NewPageIndex;
            gvSymbol.DataSource = ViewState["tblSymbol"];
            gvSymbol.DataBind();
        }

    }
}