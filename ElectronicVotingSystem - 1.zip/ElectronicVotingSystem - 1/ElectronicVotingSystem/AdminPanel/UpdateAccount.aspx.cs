﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class UpdateAccount : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            DataTable userInfo = (DataTable)Session["userInfo"];
        }

        protected void cvCurrentPassword_ServerValidate(object source, ServerValidateEventArgs args)
        {
            string password = (Session["Password"]).ToString();
            if (txtCurrentPassword.Text == password)
            {
                args.IsValid = true;
            }
            else
            {
                args.IsValid = false;
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                string password = txtPassword.Text;
                string hashPassword = Utilities.GetMd5Hash(password);
                int memberId = int.Parse(((DataTable)Session["userInfo"]).Rows[0]["member_Id"].ToString());
                bool success = MemberModel.UpdateMemberInfo(hashPassword, memberId);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "Password updated successfully.";
                    lblMsg.CssClass = "label label-success";
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to update password.";
                    lblMsg.CssClass = "label label-warning";
                }
            }
        }
    }
}