﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Data;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetVoterCount();
                GetLatestElections();
            }
        }

        private void GetVoterCount()
        {
            VoterModel obj = new VoterModel();
            string voterCount = obj.GetVotersCount();
            if (voterCount != null)
            {
                lblVoterCount.Text = voterCount;
            }
            else
            {
                lblVoterCount.Text = "0";
            }
        }

        private void GetLatestElections()
        {
            ElectionModel objElec = new ElectionModel();
            DataTable tbl = objElec.GetLatestElection();
            if (tbl.Rows.Count > 0)
            {
                rptElections.DataSource = tbl;
                rptElections.DataBind();
            }
        }
    }
}