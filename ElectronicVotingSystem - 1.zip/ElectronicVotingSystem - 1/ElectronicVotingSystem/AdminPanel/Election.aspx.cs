﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class Election : System.Web.UI.Page
    {
        ElectionModel objElection = new ElectionModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (ddlElectionType.Items.Count > 0)
                {
                    DataTable tblElectionType = objElection.GetElectionType();
                    ddlElectionType.DataSource = tblElectionType;
                    ddlElectionType.DataValueField = tblElectionType.Columns["electionType_Id"].ToString();
                    ddlElectionType.DataTextField = tblElectionType.Columns["electionType_Name"].ToString();
                    ddlElectionType.DataBind();
                }
                for (int i = 0; i < 20; i++)
                {
                    int year = DateTime.Now.Year;
                    ddlStartingYear.Text = year.ToString();
                    ddlStartingYear.Items.Add(year + i + " ");
                }
                for (int i = 0; i < 20; i++)
                {
                    int year = DateTime.Now.Year;
                    ddlEndingYear.Text = year.ToString();
                    ddlEndingYear.Items.Add(year + i + " ");
                }
                CompareValidator2.ValueToCompare = DateTime.Now.ToShortDateString();
                int yearRange = DateTime.Now.Year + 20;
                CompareValidator3.ValueToCompare = Convert.ToDateTime("1/1/"+ yearRange.ToString()).ToShortDateString();
            }
        }

        protected void btnElection_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                int startingYear = int.Parse(ddlStartingYear.SelectedValue);
                int endingYear = int.Parse(ddlEndingYear.SelectedValue);
                int electionTypeId = int.Parse(ddlElectionType.SelectedValue);
                DateTime eDay = DateTime.Parse(txtDate.Text);
                bool success = objElection.SaveElection(electionTypeId, startingYear, endingYear, eDay);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "Election added successfully.";
                    lblMsg.CssClass = "label label-success";
                    GVDataBind();
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to add Election.";
                    lblMsg.CssClass = "label label-warning";
                }
            }
        }

        protected void gvElection_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && gvElection.EditIndex == e.Row.RowIndex)
            {
                DropDownList ddlStartYear = (e.Row.FindControl("ddlStarting") as DropDownList);
                DropDownList ddlEndYear = (e.Row.FindControl("ddlEnding") as DropDownList);
                CompareValidator cv = (e.Row.FindControl("CompareValidator1") as CompareValidator);
                cv.ValueToCompare = DateTime.Now.ToShortDateString();
                CompareValidator cv2 = (e.Row.FindControl("CompareValidator4") as CompareValidator);
                int yearRange = DateTime.Now.Year + 20;
                cv2.ValueToCompare = Convert.ToDateTime("1/1/" + yearRange.ToString()).ToShortDateString();

                ddlStartYear.Items.Clear();
                for (int i = 0; i < 20; i++)
                {
                    int year = DateTime.Now.Year;
                    ddlStartYear.Text = year.ToString();
                    ListItem j = new ListItem((year + i).ToString(), (year + i).ToString());
                    ddlStartYear.Items.Add(j);
                }
                string lbl1 = (e.Row.FindControl("lblStarting") as Label).Text;
                ddlStartYear.SelectedItem.Selected = false;

                ddlEndYear.Items.Clear();
                for (int i = 0; i < 20; i++)
                {
                    int year = DateTime.Now.Year;
                    ddlEndYear.Text = year.ToString();
                    ListItem j = new ListItem((year + i).ToString(), (year + i).ToString());
                    ddlEndYear.Items.Add(j);
                }
                string lbl2 = (e.Row.FindControl("lblEnding") as Label).Text;
                ddlStartYear.Items.FindByText(lbl1).Selected = true;
                ddlEndYear.SelectedItem.Selected = false;
                ddlEndYear.Items.FindByValue(lbl2).Selected = true;
            }
        }

        protected void gvElection_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvElection.EditIndex = e.NewEditIndex;
            gvElection.DataSource = ViewState["tblElection"];
            gvElection.DataBind();
        }

        protected void gvElection_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvElection.EditIndex = -1;
            gvElection.DataSource = ViewState["tblElection"];
            gvElection.DataBind();
        }

        protected void gvElection_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            if (Page.IsValid)
            {
                int id = int.Parse(((HiddenField)gvElection.Rows[e.RowIndex].FindControl("hfElection")).Value);
                string startingYear = (((DropDownList)gvElection.Rows[e.RowIndex].FindControl("ddlStarting")).SelectedValue).ToString();
                string endingYear = (((DropDownList)gvElection.Rows[e.RowIndex].FindControl("ddlEnding")).SelectedValue).ToString();
                DateTime eDay = DateTime.Parse(((TextBox)gvElection.Rows[e.RowIndex].FindControl("txtElecDate")).Text);
                int electionType = int.Parse(ddlElectionType.SelectedValue);
                Boolean success = objElection.UpdateElection(id, electionType, startingYear, endingYear, eDay);
                gvElection.EditIndex = -1;
                GVDataBind();
                if (success)
                {
                    lblMsg.Text = "Election updated successfully.";
                    lblMsg.CssClass = "label label-success";
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to update Election.";
                    lblMsg.CssClass = "label label-warning";
                }
            }
        }

        protected void gvElection_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = int.Parse(((HiddenField)gvElection.Rows[e.RowIndex].FindControl("hfElection")).Value);
            objElection.DeleteElection(id);
            gvElection.EditIndex = -1;
            GVDataBind();
        }

        private void GVDataBind()
        {
            int etId = int.Parse(ddlElectionType.SelectedValue);
            DataTable tblElection = objElection.GetElection(etId);
            ViewState["tblElection"] = tblElection;
            if (tblElection.Rows.Count > 0)
            {
                pnlHeading.Visible = true;
                gvElection.Visible = true;
                gvElection.DataSource = tblElection;
                gvElection.DataBind();
            }
            else
            {
                pnlHeading.Visible = false;
                gvElection.Visible = false;
            }
        }

        protected void ddlElectionType_SelectedIndexChanged(object sender, EventArgs e)
        {
            GVDataBind();
        }

        protected void cvElection_ServerValidate(object source, ServerValidateEventArgs args)
        {
            int ElectionTypeId = int.Parse(ddlElectionType.SelectedValue);
            int startingYear = int.Parse(ddlStartingYear.SelectedValue);
            int endingYear = int.Parse(ddlEndingYear.SelectedValue);
            DateTime eday = DateTime.Parse(txtDate.Text);
            DataTable unitExist = objElection.GetElectionByElectionDuration(ElectionTypeId, startingYear, endingYear, eday);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void cvElection_ServerValidate1(object source, ServerValidateEventArgs args)
        {
            DateTime eday = DateTime.Parse(args.Value);
            GridViewRow gvr = (GridViewRow)((CustomValidator)source).Parent.Parent;
            int index = gvr.RowIndex;
            int eId = int.Parse(((HiddenField)gvElection.Rows[index].FindControl("hfElection")).Value);
            int startingYear = int.Parse(((DropDownList)gvElection.Rows[index].FindControl("ddlStarting")).SelectedValue);
            int endingYear = int.Parse(((DropDownList)gvElection.Rows[index].FindControl("ddlEnding")).SelectedValue);
            DataTable unitExist = objElection.GetElectionByElectionId(eId, startingYear, endingYear, eday);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void gvElection_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvElection.PageIndex = e.NewPageIndex;
            GVDataBind();
        }
    }
}