﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Data;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class ChartVoter : System.Web.UI.Page
    {
        ChartsModel objChart = new ChartsModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataTable dt = objChart.VoterVSDistrict();
                chartVoter.DataSource = dt;
                chartVoter.Series[0].XValueMember = "district_Name";
                chartVoter.Series[0].YValueMembers = "totalVoters";

                chartVoter.DataBind();

                DataTable dtA = objChart.voterVsConstituency();

                chartVoterA.DataSource = dtA;
                chartVoterA.Series[0].XValueMember = "highestLevelCons";
                chartVoterA.Series[0].YValueMembers = "totalVoters";

                chartVoterA.DataBind();
            }
        }

    }
}