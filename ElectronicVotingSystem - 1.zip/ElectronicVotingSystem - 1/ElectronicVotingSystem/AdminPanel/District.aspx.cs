﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.AdminPanel
{
    public partial class District : System.Web.UI.Page
    {

        AdministrativeUnitModel objAdminUnit = new AdministrativeUnitModel();
        DistrictModel objDistrict = new DistrictModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (ddlAdminUnit.Items.Count == 1)
                {
                    DataTable tblAdminUnit = objAdminUnit.GetAdminUnit();
                    ddlAdminUnit.DataSource = tblAdminUnit;
                    ddlAdminUnit.DataValueField = tblAdminUnit.Columns["administrativeUnit_Id"].ToString();
                    ddlAdminUnit.DataTextField = tblAdminUnit.Columns["administrativeUnit_Name"].ToString();
                    ddlAdminUnit.DataBind();
                }
            }
        }

        protected void btnDistrict_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                int adminUnitId = int.Parse(ddlAdminUnit.SelectedValue);
                string districtName = txtDist.Text;
                bool success = objDistrict.SaveDistrict(districtName, adminUnitId);
                // Display status message
                if (success)
                {
                    lblMsg.Text = "District added successfully.";
                    lblMsg.CssClass = "label label-success";
                    int adminUnit = int.Parse(ddlAdminUnit.SelectedValue);
                    DataTable tblDistrict = objDistrict.GetDistrictByAdminUnit(adminUnit);
                    ViewState["tblDistrict"] = tblDistrict;
                    gvDistrict.DataSource = ViewState["tblDistrict"];
                    gvDistrict.DataBind();
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to add district.";
                    lblMsg.CssClass = "label label-warning";

                }
            }
        }

        protected void cvDistrict_ServerValidate(object source, ServerValidateEventArgs args)
        {
            string districtName = args.Value;
            GridViewRow gvr = (GridViewRow)((CustomValidator)source).Parent.Parent;
            int index = gvr.RowIndex;
            int districtId = int.Parse(((HiddenField)gvDistrict.Rows[index].FindControl("hfDistrict")).Value);
            DataTable unitExist = objDistrict.GetDistrictByNameDistrictId(districtId, districtName);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void cvDistrict_ServerValidate1(object source, ServerValidateEventArgs args)
        {
            string districtName = txtDist.Text;
            DataTable unitExist = objDistrict.GetDistrictByName(districtName);
            if (unitExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void gvDistrict_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvDistrict.EditIndex = e.NewEditIndex;
            gvDistrict.DataSource = ViewState["tblDistrict"];
            gvDistrict.DataBind();
        }

        protected void gvDistrict_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvDistrict.EditIndex = -1;
            gvDistrict.DataSource = ViewState["tblDistrict"];
            gvDistrict.DataBind();
        }

        protected void gvDistrict_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            if (Page.IsValid)
            {
                int id = int.Parse(((HiddenField)gvDistrict.Rows[e.RowIndex].FindControl("hfDistrict")).Value);
                string name = ((TextBox)gvDistrict.Rows[e.RowIndex].FindControl("txtDistrict")).Text;
                int adminId = int.Parse(ddlAdminUnit.SelectedValue);
                bool success = objDistrict.UpdateDistrict(id, name, adminId);
                if (success)
                {
                    lblMsg.Text = "District updated successfully.";
                    lblMsg.CssClass = "label label-success";
                }
                else
                {
                    lblMsg.Text = "Sorry! Failed to update district.";
                    lblMsg.CssClass = "label label-warning";
                }
                gvDistrict.EditIndex = -1;
                int adminUnit = int.Parse(ddlAdminUnit.SelectedValue);
                DataTable tblDistrict = objDistrict.GetDistrictByAdminUnit(adminUnit);
                ViewState["tblDistrict"] = tblDistrict;
                gvDistrict.DataSource = ViewState["tblDistrict"];
                gvDistrict.DataBind();
            }
        }

        protected void gvDistrict_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = int.Parse(((HiddenField)gvDistrict.Rows[e.RowIndex].FindControl("hfDistrict")).Value);
            bool success = objDistrict.DeleteDistrict(id);
            if (success)
            {
                lblMsg.Text = "District deleted successfully.";
                lblMsg.CssClass = "label label-success";
            }
            else
            {
                lblMsg.Text = "Sorry! Failed to delete district.";
                lblMsg.CssClass = "label label-warning";
            }
            gvDistrict.EditIndex = -1;
            int adminUnit = int.Parse(ddlAdminUnit.SelectedValue);
            DataTable tblDistrict = objDistrict.GetDistrictByAdminUnit(adminUnit);
            ViewState["tblDistrict"] = tblDistrict;
            gvDistrict.DataSource = ViewState["tblDistrict"];
            gvDistrict.DataBind();
        }

        protected void ddlAdminUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGridview();
        }

        protected void gvDistrict_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvDistrict.PageIndex = e.NewPageIndex;
            BindGridview();
        }

        private void BindGridview()
        {
            int adminUnit = int.Parse(ddlAdminUnit.SelectedValue);
            DataTable tblDistrict = objDistrict.GetDistrictByAdminUnit(adminUnit);
            ViewState["tblDistrict"] = tblDistrict;
            if (tblDistrict.Rows.Count > 0)
            {
                gvDistrict.DataSource = tblDistrict;
                gvDistrict.DataBind();
                pnlHeading.Visible = true;
            }
            else
            {
                pnlHeading.Visible = false;
                gvDistrict.Visible = false;
            }
        }

    }
}