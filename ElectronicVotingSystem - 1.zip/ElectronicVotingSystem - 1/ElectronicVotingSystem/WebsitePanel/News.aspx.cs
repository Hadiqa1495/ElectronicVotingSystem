﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.WebsitePanel
{
    public partial class News_Events : System.Web.UI.Page
    {
        NewsModel objNews = new NewsModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            DataTable tbl = objNews.GetNews();
            if (tbl.Rows.Count > 0)
            {
                rptNews.DataSource = tbl;
                ViewState["tbl"] = tbl;
                rptNews.DataBind();
            }
        }

        protected void rptNews_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
            {
                int index=e.Item.ItemIndex;
                DataTable tblNews = (DataTable)ViewState["tbl"];
               string newsDetails= tblNews.Rows[index]["news_Detail"].ToString();
                if(tblNews.Rows[index]["news_Image"].ToString()=="")
                {
                   e.Item.FindControl("img").Visible = false;
                }
               Label lbl = (Label)e.Item.FindControl("lblDetail");
                if (newsDetails.Length>150)
                {
                    newsDetails = newsDetails.Substring(0, 150) + "...";
                    lbl.Text = newsDetails;
                }
                else
                {
                    lbl.Text = newsDetails;
                }
            }
        }

    }
}