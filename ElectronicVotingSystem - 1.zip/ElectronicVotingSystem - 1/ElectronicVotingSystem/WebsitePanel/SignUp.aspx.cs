﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.WebsitePanel
{
    public partial class SignUp : System.Web.UI.Page
    {
        UserModel objUser = new UserModel();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string email = txtEmailLogin.Text;
            string password = txtPasswordLogin.Text;
            string hashPassword = Utilities.GetMd5Hash(password);
            DataTable LoginInfo = objUser.GetUserByLoginInfo(email, hashPassword);
            if (LoginInfo.Rows.Count > 0)
            {
                Session["user"] = LoginInfo;
                //Session["password"] = txtPasswordLogin.Text;

                Response.Redirect("Home.aspx");
            }
            else
            {
                lblLogin.CssClass = "label label-warning";
                lblLogin.Text = "Invalid Email or Password.";
            }
        }

        protected void btnSignUp_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                string userName = txtName.Text;
                string email = txtEmail.Text;
                string rePassword = txtRePassword.Text;
                string password = Utilities.GetMd5Hash(txtPassword.Text);
                //imgCaptcha.ImageUrl = "~/CreateCaptcha.aspx?New=0";
                if (Session["CaptchaCode"] != null && txtCaptcha.Text == Session["CaptchaCode"].ToString())
                {
                    // Execute the insert command
                    bool success = objUser.SaveUser(userName, email, password);
                    // Display status message
                    if (success)
                    {
                        lblMessage.Visible = false;
                        lblMsg.Text = "Account created successfully.";
                        lblMsg.CssClass = "label label-success";
                        using (MailMessage mm = new MailMessage("EVS.ECP@gmail.com", txtEmail.Text))
                        {
                            mm.Subject = "Account created successfully";
                            mm.Body = "Congratulations!! Your Acoount on Election Commission Website has been created successfully";
                            mm.IsBodyHtml = false;
                            SmtpClient smtp = new SmtpClient();
                            smtp.Host = "smtp.gmail.com";
                            smtp.EnableSsl = true;
                            //Here is your email account email and password is given, You can change it to your personal email account
                            NetworkCredential NetworkCred = new NetworkCredential("EVS.ECP@gmail.com", "EVS123ECP");
                            smtp.UseDefaultCredentials = true;
                            smtp.Credentials = NetworkCred;
                            smtp.Port = 587;
                            smtp.Send(mm);
                        }

                        //DataTable LoginInfo = objUser.GetUserByLoginInfo(email, password);
                        //Session["user"] = LoginInfo;

                        //Response.Redirect("Home.aspx");
                        lblMsg.Text = "Email for your successful account creation has been sent to your email account!";
                    }
                    else
                    {
                        lblMsg.Text = "Sorry! Failed to create account.";
                        lblMsg.CssClass = "label label-warning";
                    }
                }
                else
                {
                    lblMessage.CssClass = "label label-warning";
                    lblMessage.Text = "Captcha code is wrong!!";
                }
            }
        }

        protected void cvEmailSignUp_ServerValidate(object source, ServerValidateEventArgs args)
        {
            string email = txtEmail.Text;
            DataTable emailExist = objUser.GetUserByEmail(email);
            if (emailExist.Rows.Count > 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

    }
}