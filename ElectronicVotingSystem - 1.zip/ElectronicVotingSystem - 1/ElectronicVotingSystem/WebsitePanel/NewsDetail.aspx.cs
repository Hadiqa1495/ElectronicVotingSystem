﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.WebsitePanel
{
    public partial class NewsDetail : System.Web.UI.Page
    {
        NewsModel objNews = new NewsModel();
        protected void Page_Load(object sender, EventArgs e)
        {

            int id = int.Parse(Request.QueryString["id"]);
            DataTable tbl = objNews.GetNewsDetail(id);
            lblDate.Text = ((DateTime)tbl.Rows[0]["news_PublishedDate"]).ToString("MMMM d, yyyy");
            lblTitle.Text = (tbl.Rows[0]["news_Title"]).ToString();
            lblDetail.Text = (tbl.Rows[0]["news_Detail"]).ToString();
            if((tbl.Rows[0]["news_Image"].ToString())!="")
            {
                img.Visible = true;
                img.ImageUrl = "~/Uploads/"+(tbl.Rows[0]["news_Image"]).ToString();
            }
            else
            {
                img.Visible=false;
            }
            
        }
    }
}