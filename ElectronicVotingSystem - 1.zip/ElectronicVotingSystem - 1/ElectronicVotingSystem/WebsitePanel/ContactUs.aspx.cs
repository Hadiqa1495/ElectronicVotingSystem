﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.WebsitePanel
{
    public partial class ContactUs : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
            if (Session["CaptchaCode"] != null && txtCaptcha.Text == Session["CaptchaCode"].ToString())
            {
                using (MailMessage mm = new MailMessage(txtEmail.Text, "EVS.ECP@gmail.com"))
                {
                    mm.Subject = txtSubject.Text;
                    mm.Body = "Name: " + txtName.Text + "<br />Email: " + txtEmail.Text + "<br />" + txtMsg.Text;
                    mm.IsBodyHtml = false;
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = "smtp.gmail.com";
                    smtp.EnableSsl = true;
                    //Here is your email account email and password is given, You can change it to your personal email account
                    NetworkCredential NetworkCred = new NetworkCredential("EVS.ECP@gmail.com", "EVS123ECP");
                    smtp.UseDefaultCredentials = true;
                    smtp.Credentials = NetworkCred;
                    smtp.Port = 587;
                    smtp.Send(mm);
                }
                lblMessage.Text = "Email sent!";
            }
            else
            {
                lblMessage.CssClass = "label label-warning";
                lblMessage.Text = "Captcha code is wrong!!";
            }
        }
    }
}