﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ElectronicVotingSystem.DataAccess;
using System.Data;

namespace ElectronicVotingSystem.WebsitePanel
{
    public partial class PollingStationList : System.Web.UI.Page
    {
        private PollingStationModel objPS = new PollingStationModel();
        private DataTable tblPollingStations = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetDistrict_PSCount();
            }

            if (Request.QueryString["id"] != null)
            {
                int distId = int.Parse(Request.QueryString["id"].ToString());
                tblPollingStations = objPS.GetPollingStationByDistId(distId);
            }
            else if (Request.QueryString["search"] != null)
            {
                string search = Request.QueryString["search"].ToString();
                tblPollingStations = objPS.GetPollingStation(search);
            }
            else
            {

            }

            int i = 0;
            float longitude = float.Parse("69.345115");
            float latitude = float.Parse("30.375321");
            string desc = "Welcome to Pakistan!";
            int zoom = 7;
            string markers = @"var marker" + i.ToString() + @" = new google.maps.Marker({ position: new google.maps.LatLng(" + latitude + ", " + longitude + ")," + @"map: myMap, title:'" + desc + "'});";


            if (tblPollingStations != null)
            {
                if (tblPollingStations.Rows.Count > 0)
                {
                    panelPS.Visible = true;
                    tblPollingStations.Columns.Add("PollingStation", typeof(string), "pollingStation_Address + ', ' + pollingStation_Town + ', ' + pollingStation_City");
                    rptPollingStation.DataSource = tblPollingStations;
                    rptPollingStation.DataBind();

                    markers = "";
                    i = 0;
                    latitude = float.Parse("0");
                    longitude = float.Parse("0");
                    foreach (DataRow row in tblPollingStations.Rows)
                    {
                        string lati = row["pollingStation_Latitude"].ToString();
                        string longi = row["pollingStation_Longitude"].ToString();
                        if (lati != "0" && longi != "0")
                        {
                            latitude += float.Parse(lati);
                            longitude += float.Parse(longi);
                            markers += @"var marker" + i.ToString() + @" = new google.maps.Marker({ position: new google.maps.LatLng(" + row["pollingStation_Latitude"].ToString() + ", " + row["pollingStation_Longitude"].ToString() + ")," + @"map: myMap, title:'" + row["pollingStation_Address"].ToString() + " , " + row["pollingStation_Town"].ToString() + "'});";
                            i++;
                        }
                    }
                    latitude = latitude / (i);
                    longitude = longitude / (i);
                    zoom = 12;

                    lblMsg.Visible = false;
                }
                else
                {
                    panelPS.Visible = false;
                    lblMsg.Visible = true;
                    lblMsg.Text = "No results found!";
                }
            }

            Literal1.Text = @"<script type='text/javascript'>
             function initialize() {
 
             var mapOptions = {
             center: new google.maps.LatLng(" + latitude + "," + longitude + @"),
             zoom: " + zoom + @",
             mapTypeId: google.maps.MapTypeId.ROADMAP
             };
 
             var myMap = new google.maps.Map(document.getElementById('mapArea'),
             mapOptions);" + markers + @"}
             </script>";
        }

        private void GetDistrict_PSCount()
        {
            DataTable tblDistrict = objPS.GetPollingStationCountByDistrict();
            if (tblDistrict.Rows.Count > 0)
            {
                rptDistrict.DataSource = tblDistrict;
                rptDistrict.DataBind();
            }
        }

        protected void Unnamed_ServerClick(object sender, EventArgs e)
        {
            string search = TextBox1.Text;
            Response.Redirect("PollingStationList.aspx?search=" + search);
        }
    }
}