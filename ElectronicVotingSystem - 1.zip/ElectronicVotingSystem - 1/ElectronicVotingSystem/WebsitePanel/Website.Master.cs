﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.WebsitePanel
{
    public partial class Website : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["user"] == null)
                {
                    HyperLink1.Text = "Login";
                    HyperLink1.NavigateUrl = "SignUp.aspx";
                }
                else
                {
                    HyperLink1.Text = "Logout";
                    HyperLink1.NavigateUrl = "Logout.aspx";

                }
            }
        }
    }
}