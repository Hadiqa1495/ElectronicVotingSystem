﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ElectronicVotingSystem.DataAccess;
using System.Data;
using AjaxControlToolkit;

namespace ElectronicVotingSystem.WebsitePanel
{
    public partial class PartyList : System.Web.UI.Page
    {
        PartyModel objParty = new PartyModel();
        RatingModel objRating = new RatingModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataTable tblParty = objParty.GetPartyWithSymbol();
                if (tblParty.Rows.Count > 0)
                {
                    rptParty.DataSource = tblParty;
                    rptParty.DataBind();
                }
            }
        }

        protected void rptParty_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
            {
                Repeater rpt = (Repeater)e.Item.FindControl("rptParty");
                HiddenField hf = (HiddenField)e.Item.FindControl("hfParty");
                int id = int.Parse(hf.Value);
                BindAverageRating(id, e.Item);
            }
        }

        protected void Rating1_Changed(object sender, AjaxControlToolkit.RatingEventArgs e)
        {
            HiddenField party = (HiddenField)rptParty.FindControl("hfParty");
            int partyId = int.Parse(party.Value);

            Label lblRating = (Label)rptParty.FindControl("Rating2");
            int newRate = int.Parse(lblRating.Text);
            if (Session["user"] == null)
            {
                Response.Redirect("SignUp.aspx");
            }
            else
            {
                hfUser.Value = ((DataTable)Session["user"]).Rows[0]["user_Id"].ToString();
                int user = int.Parse(hfUser.Value);
                bool success = objRating.SaveRating(partyId, user, newRate);
                if (success)
                {
                    DataTable rating = objRating.GetPartyRating(partyId);
                    AjaxControlToolkit.Rating rate = (AjaxControlToolkit.Rating)rptParty.FindControl("Rating2");

                    rate.CurrentRating = Convert.ToInt32(rating.Rows[0]["AverageRating"]);
                    ((Label)rptParty.FindControl("lblRatingStatus")).Text = string.Format("{0} Users have rated. Average Rating {1}", rating.Rows[0]["RatingCount"], rating.Rows[0]["AverageRating"]);

                    Response.Redirect(Request.Url.AbsoluteUri);
                }

            }
        }

        protected void Rating2_Click(object sender, RatingEventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("SignUp.aspx");
            }
            else
            {
                int newRate = int.Parse(e.Value);
                RepeaterItem rptParty = (((AjaxControlToolkit.Rating)sender).Parent) as RepeaterItem;
                HiddenField party = ((rptParty).FindControl("hfParty")) as HiddenField;
                int partyId = int.Parse(party.Value);
                int user = int.Parse(((DataTable)Session["user"]).Rows[0]["user_Id"].ToString());
                bool success = objRating.SaveRating(partyId, user, newRate);
                if (success)
                {
                    BindAverageRating(partyId, rptParty);
                    Response.Redirect(Request.Url.AbsoluteUri);
                }
            }
        }

        private void BindAverageRating(int partyId, RepeaterItem item)
        {
            DataTable rating = objRating.GetPartyRating(partyId);
            if (rating.Rows.Count > 0)
            {
                AjaxControlToolkit.Rating rate = item.FindControl("Rating2") as AjaxControlToolkit.Rating;
                rate.CurrentRating = Convert.ToInt32(rating.Rows[0]["AverageRating"]);
                ((Label)item.FindControl("lblRatingStatus")).Text = string.Format("{0} Users have rated. Average Rating {1}", rating.Rows[0]["RatingCount"], rating.Rows[0]["AverageRating"]);

            }
        }

    }
}