﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.WebsitePanel
{
    public partial class AResult : System.Web.UI.Page
    {
        private int electionId;
        private int districtId;
        private ResultModel objResult = new ResultModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ElectionModel objElection = new ElectionModel();
                DataTable tblElections = objElection.GetPrevious10ElectionByElectionType(14);
                if (tblElections.Rows.Count > 0)
                {
                    rptAssemblyElec.DataSource = tblElections;
                    rptAssemblyElec.DataBind();


                    if (rptAssemblyElec.Items.Count > 0)
                    {
                        RepeaterItem item = rptAssemblyElec.Items[0];
                        electionId = int.Parse(((HiddenField)item.FindControl("hfId")).Value);

                        DataTable tblParty = objResult.GetPartyWinners(electionId);
                        if (tblParty.Rows.Count > 0)
                        {
                            GvParty.DataSource = tblParty;
                            GvParty.DataBind();
                        }

                        DataTable tblParty2 = objResult.GetPartyWinnersPAProvincially(electionId);
                        if (tblParty.Rows.Count > 0)
                        {
                            gvPAParties.DataSource = tblParty2;
                            gvPAParties.DataBind();
                        }

                        string voteCount = objResult.GetVoteCount(electionId);
                        lblVoteCount.Text = voteCount;

                        DistrictModel objDist = new DistrictModel();
                        DataTable tblDistrict = objDist.GetDistrictByElectionId(electionId);
                        DataSet ds = new DataSet();
                        ds.Tables.Add(tblDistrict);
                        if (tblDistrict.Rows.Count > 0)
                        {
                            MyAccordion.DataSource = ds.Tables[0].DefaultView;
                            MyAccordion.DataBind();
                        }
                    }
                }
            }
        }

        protected void MyAccordion_ItemDataBound(object sender, AjaxControlToolkit.AccordionItemEventArgs e)
        {
            if (e.ItemType == AjaxControlToolkit.AccordionItemType.Content)
            {
                Repeater rpt = (Repeater)e.AccordionItem.FindControl("rptA");
                HiddenField hf = (HiddenField)e.AccordionItem.FindControl("hfDist");
                districtId = int.Parse(hf.Value);
                DataTable tblNAResult = objResult.GetAssemblyElectionWinners(electionId, districtId);
                if (tblNAResult.Rows.Count > 0)
                {
                    rpt.DataSource = tblNAResult;
                    rpt.DataBind();
                }
            }
        }

        protected void rptAssemblyElec_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "ShowResult")
            {
                electionId = int.Parse(((HiddenField)e.Item.FindControl("hfId")).Value);

                DataTable tblParty = objResult.GetPartyWinnersNA(electionId);
                if (tblParty.Rows.Count > 0)
                {
                    GvParty.DataSource = tblParty;
                    GvParty.DataBind();
                }

                DataTable tblParty2 = objResult.GetPartyWinnersPAProvincially(electionId);
                if (tblParty.Rows.Count > 0)
                {
                    gvPAParties.DataSource = tblParty2;
                    gvPAParties.DataBind();
                }

                DistrictModel objDist = new DistrictModel();
                DataTable tblDistrict = objDist.GetDistrictByElectionId(electionId);
                DataSet ds = new DataSet();
                ds.Tables.Add(tblDistrict);
                if (tblDistrict.Rows.Count > 0)
                {
                    MyAccordion.DataSource = ds.Tables[0].DefaultView;
                    MyAccordion.DataBind();
                }
            }
        }
    }
}