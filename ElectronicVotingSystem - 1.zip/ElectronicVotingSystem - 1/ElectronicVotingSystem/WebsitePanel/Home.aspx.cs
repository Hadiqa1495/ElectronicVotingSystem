﻿using ElectronicVotingSystem.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectronicVotingSystem.WebsitePanel
{
    public partial class Home : System.Web.UI.Page
    {
        NewsModel objNews = new NewsModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            DataTable tbl = objNews.GetNews();
            rpt.DataSource = tbl;
            rpt.DataBind();
        }
    }
}