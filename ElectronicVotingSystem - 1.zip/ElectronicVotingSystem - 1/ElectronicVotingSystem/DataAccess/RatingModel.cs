﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public class RatingModel
    {
        public bool SaveRating(int party, int user, int rating)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_InsertInto_Rating";
            // execute the stored procedure and return the results

            DbParameter Party = comm.CreateParameter();
            Party.ParameterName = "@party";
            Party.Value = party;
            Party.DbType = DbType.Int32;
            comm.Parameters.Add(Party);

            DbParameter User = comm.CreateParameter();
            User.ParameterName = "@user";
            User.Value = user;
            User.DbType = DbType.Int32;
            User.Size = 50;
            comm.Parameters.Add(User);

            DbParameter Rating = comm.CreateParameter();
            Rating.ParameterName = "@rating";
            Rating.Value = rating;
            Rating.DbType = DbType.Int32;
            comm.Parameters.Add(Rating);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public DataTable GetPartyRating(int id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Get_Rating";
            // execute the stored procedure and return the results

            DbParameter partyId = comm.CreateParameter();
            partyId.ParameterName = "@party";
            partyId.Value = id;
            partyId.DbType = DbType.Int32;
            comm.Parameters.Add(partyId);

            return GenericDataAccess.ExecuteReader(comm);
        }
    }
}