﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public class SMSModel
    {
        public DataTable GetPollingStationVoter(int distId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SMS";

            DbParameter DistId = comm.CreateParameter();
            DistId.ParameterName = "@dist";
            DistId.Value = distId;
            DistId.DbType = DbType.Int32;
            comm.Parameters.Add(DistId);

            return GenericDataAccess.ExecuteReader(comm);
        }
    }
}