﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public class PollingStationModel
    {
        public bool SavePollingStation(string city, string town, string address, float longitude, float latitude, int blockId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_InsertInto_PollingStation";
            // execute the stored procedure and return the results

            DbParameter City = comm.CreateParameter();
            City.ParameterName = "@city";
            City.Value = city;
            City.DbType = DbType.String;
            City.Size = 50;
            comm.Parameters.Add(City);

            DbParameter Town = comm.CreateParameter();
            Town.ParameterName = "@town";
            Town.Value = town;
            Town.DbType = DbType.String;
            Town.Size = 50;
            comm.Parameters.Add(Town);

            DbParameter Address = comm.CreateParameter();
            Address.ParameterName = "@address";
            Address.Value = address;
            Address.DbType = DbType.String;
            Address.Size = 500;
            comm.Parameters.Add(Address);

            DbParameter Longitude = comm.CreateParameter();
            Longitude.ParameterName = "@long";
            Longitude.Value = longitude;
            Longitude.DbType = DbType.Double;
            comm.Parameters.Add(Longitude);

            DbParameter Latitude = comm.CreateParameter();
            Latitude.ParameterName = "@lat";
            Latitude.Value = latitude;
            Latitude.DbType = DbType.Double;
            comm.Parameters.Add(Latitude);

            DbParameter BlockId = comm.CreateParameter();
            BlockId.ParameterName = "@blockId";
            BlockId.Value = blockId;
            BlockId.DbType = DbType.Int32;
            comm.Parameters.Add(BlockId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public bool UpdatePollingStation(int Id, string city, string town, string address, float longitude, float latitude)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_UpdateSet_PollingStation";
            // execute the stored procedure and return the results

            DbParameter PollingStationId = comm.CreateParameter();
            PollingStationId.ParameterName = "@pollingStation_Id";
            PollingStationId.Value = Id;
            PollingStationId.DbType = DbType.Int32;
            comm.Parameters.Add(PollingStationId);

            DbParameter City = comm.CreateParameter();
            City.ParameterName = "@city";
            City.Value = city;
            City.DbType = DbType.String;
            City.Size = 50;
            comm.Parameters.Add(City);

            DbParameter Town = comm.CreateParameter();
            Town.ParameterName = "@town";
            Town.Value = town;
            Town.DbType = DbType.String;
            Town.Size = 50;
            comm.Parameters.Add(Town);

            DbParameter Address = comm.CreateParameter();
            Address.ParameterName = "@address";
            Address.Value = address;
            Address.DbType = DbType.String;
            Address.Size = 500;
            comm.Parameters.Add(Address);

            DbParameter Longitude = comm.CreateParameter();
            Longitude.ParameterName = "@long";
            Longitude.Value = longitude;
            Longitude.DbType = DbType.Double;
            comm.Parameters.Add(Longitude);

            DbParameter Latitude = comm.CreateParameter();
            Latitude.ParameterName = "@lat";
            Latitude.Value = latitude;
            Latitude.DbType = DbType.Double;
            comm.Parameters.Add(Latitude);
            
            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);

        }

        public bool DeletePollingStation(int Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_DeleteFrom_PollingStation";
            // execute the stored procedure and return the results

            DbParameter PollingStationId = comm.CreateParameter();
            PollingStationId.ParameterName = "@PollingStation_Id";
            PollingStationId.Value = Id;
            PollingStationId.DbType = DbType.Int32;
            comm.Parameters.Add(PollingStationId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public DataTable GetPollingStationByDistId(int distId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_PollingStation_ByDistrict";

            DbParameter DistId = comm.CreateParameter();
            DistId.ParameterName = "@distId";
            DistId.Value = distId;
            DistId.DbType = DbType.Int32;
            comm.Parameters.Add(DistId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetPollingStationCountByDistrict()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Get_PollingStationCount_ByDistrict";

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetCVPollingStation(string city, string town, string address, int blockId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_CustomValidator_PollingStation";

            DbParameter City = comm.CreateParameter();
            City.ParameterName = "@pollingStation_City";
            City.Value = city;
            City.DbType = DbType.String;
            City.Size = 50;
            comm.Parameters.Add(City);

            DbParameter Town = comm.CreateParameter();
            Town.ParameterName = "@pollingStation_Town";
            Town.Value = town;
            Town.DbType = DbType.String;
            Town.Size = 50;
            comm.Parameters.Add(Town);

            DbParameter Address = comm.CreateParameter();
            Address.ParameterName = "@pollingStation_Address";
            Address.Value = address;
            Address.DbType = DbType.String;
            Address.Size = 500;
            comm.Parameters.Add(Address);

            DbParameter BlockId = comm.CreateParameter();
            BlockId.ParameterName = "@pollingStation_BlockId";
            BlockId.Value = blockId;
            BlockId.DbType = DbType.Int32;
            comm.Parameters.Add(BlockId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetCVPollingStationId(int id,string city, string town, string address, int blockId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_CustomValidator_PollingStationId";

            DbParameter Id = comm.CreateParameter();
            Id.ParameterName = "@pollingStation_Id";
            Id.Value = id;
            Id.DbType = DbType.Int32;
            comm.Parameters.Add(Id);

            DbParameter City = comm.CreateParameter();
            City.ParameterName = "@pollingStation_City";
            City.Value = city;
            City.DbType = DbType.String;
            City.Size = 50;
            comm.Parameters.Add(City);

            DbParameter Town = comm.CreateParameter();
            Town.ParameterName = "@pollingStation_Town";
            Town.Value = town;
            Town.DbType = DbType.String;
            Town.Size = 50;
            comm.Parameters.Add(Town);

            DbParameter Address = comm.CreateParameter();
            Address.ParameterName = "@pollingStation_Address";
            Address.Value = address;
            Address.DbType = DbType.String;
            Address.Size = 500;
            comm.Parameters.Add(Address);

            DbParameter BlockId = comm.CreateParameter();
            BlockId.ParameterName = "@pollingStation_BlockId";
            BlockId.Value = blockId;
            BlockId.DbType = DbType.Int32;
            comm.Parameters.Add(BlockId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetPollingStationReport(string search)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Report_PollingStation";

            DbParameter Search = comm.CreateParameter();
            Search.ParameterName = "@search";
            Search.Value = search;
            Search.DbType = DbType.String;
            Search.Size = 50;
            comm.Parameters.Add(Search);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetPollingStation()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Report_PollingStationGeneral";
            
            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetPollingStation(string search)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Get_PollingStation";

            DbParameter Search = comm.CreateParameter();
            Search.ParameterName = "@search";
            Search.Value = search;
            Search.DbType = DbType.String;
            Search.Size = 50;
            comm.Parameters.Add(Search);

            return GenericDataAccess.ExecuteReader(comm);
        }      
    }
}