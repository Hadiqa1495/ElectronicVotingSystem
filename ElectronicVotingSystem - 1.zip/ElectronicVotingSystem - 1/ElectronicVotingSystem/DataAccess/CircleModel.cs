﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public class CircleModel
    {
        public bool SaveCircle(string name, int charge_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_InsertInto_Circle";
            // execute the stored procedure and return the results

            DbParameter Name = comm.CreateParameter();
            Name.ParameterName = "@circle_Name";
            Name.Value = name;
            Name.DbType = DbType.String;
            Name.Size = 50;
            comm.Parameters.Add(Name);

            DbParameter chargeId = comm.CreateParameter();
            chargeId.ParameterName = "@circle_ChargeId";
            chargeId.Value = charge_Id;
            chargeId.DbType = DbType.Int32;
            comm.Parameters.Add(chargeId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public bool UpdateCircle(int id, string name, int charge_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_UpdateSet_Circle";
            // execute the stored procedure and return the results

            DbParameter Id = comm.CreateParameter();
            Id.ParameterName = "@circle_Id";
            Id.Value = id;
            Id.DbType = DbType.Int32;
            comm.Parameters.Add(Id);

            DbParameter Name = comm.CreateParameter();
            Name.ParameterName = "@circle_Name";
            Name.Value = name;
            Name.DbType = DbType.String;
            Name.Size = 50;
            comm.Parameters.Add(Name);

            DbParameter chargeId = comm.CreateParameter();
            chargeId.ParameterName = "@circle_ChargeId";
            chargeId.Value = charge_Id;
            chargeId.DbType = DbType.Int32;
            comm.Parameters.Add(chargeId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);

        }

        public bool DeleteCircle(int id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_DeleteFrom_Circle";
            // execute the stored procedure and return the results

            DbParameter Id = comm.CreateParameter();
            Id.ParameterName = "@circle_Id";
            Id.Value = id;
            Id.DbType = DbType.Int32;
            comm.Parameters.Add(Id);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public DataTable GetCircleByChargeId(int charge_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Circle_ByChargeId";
            // execute the stored procedure and return the results

            DbParameter chargeId = comm.CreateParameter();
            chargeId.ParameterName = "@circle_ChargeId";
            chargeId.Value = charge_Id;
            chargeId.DbType = DbType.Int32;
            comm.Parameters.Add(chargeId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetCircleByNameChargeId(string name, int charge_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Circle_ByNameChargeId";
            // execute the stored procedure and return the results

            DbParameter districtName = comm.CreateParameter();
            districtName.ParameterName = "@circle_Name";
            districtName.Value = name;
            districtName.DbType = DbType.String;
            districtName.Size = 50;
            comm.Parameters.Add(districtName);

            DbParameter chargeId = comm.CreateParameter();
            chargeId.ParameterName = "@circle_ChargeId";
            chargeId.Value = charge_Id;
            chargeId.DbType = DbType.Int32;
            comm.Parameters.Add(chargeId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetCircleByIdNameChargeId(int id, string name, int charge_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Circle_ByIdNameChargeId";
            // execute the stored procedure and return the results

            DbParameter Id = comm.CreateParameter();
            Id.ParameterName = "@circle_Id";
            Id.Value = id;
            Id.DbType = DbType.Int32;
            comm.Parameters.Add(Id);

            DbParameter districtName = comm.CreateParameter();
            districtName.ParameterName = "@circle_Name";
            districtName.Value = name;
            districtName.DbType = DbType.String;
            districtName.Size = 50;
            comm.Parameters.Add(districtName);

            DbParameter chargeId = comm.CreateParameter();
            chargeId.ParameterName = "@circle_ChargeId";
            chargeId.Value = charge_Id;
            chargeId.DbType = DbType.Int32;
            comm.Parameters.Add(chargeId);

            return GenericDataAccess.ExecuteReader(comm);
        }

    }
}