﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public class NewsModel
    {

        public bool SaveNews(string title, string news, string img)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_InsertInto_News";
            // execute the stored procedure and return the results

            DbParameter Title = comm.CreateParameter();
            Title.ParameterName = "@title";
            Title.Value = title;
            Title.DbType = DbType.String;
            Title.Size = 50;
            comm.Parameters.Add(Title);

            DbParameter News = comm.CreateParameter();
            News.ParameterName = "@news";
            News.Value = news;
            News.DbType = DbType.String;
            News.Size = 4000;
            comm.Parameters.Add(News);

            DbParameter image = comm.CreateParameter();
            image.ParameterName = "@img";
            image.Value = img;
            image.DbType = DbType.String;
            image.Size = 500;
            comm.Parameters.Add(image);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);

        }

        public bool UpdateNews(string title, string news, string img, int id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_UpdateSet_News";
            // execute the stored procedure and return the results

            DbParameter Id = comm.CreateParameter();
            Id.ParameterName = "@id";
            Id.Value = id;
            Id.DbType = DbType.String;
            Id.Size = 50;
            comm.Parameters.Add(Id);

            DbParameter Title = comm.CreateParameter();
            Title.ParameterName = "@title";
            Title.Value = title;
            Title.DbType = DbType.String;
            Title.Size = 50;
            comm.Parameters.Add(Title);

            DbParameter News = comm.CreateParameter();
            News.ParameterName = "@news";
            News.Value = news;
            News.DbType = DbType.String;
            News.Size = 4000;
            comm.Parameters.Add(News);

            DbParameter image = comm.CreateParameter();
            image.ParameterName = "@img";
            image.Value = img;
            image.DbType = DbType.String;
            image.Size = 500;
            comm.Parameters.Add(image);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);

        }

        public bool DeleteNews(int id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_DeleteFrom_News";
            // execute the stored procedure and return the results

            DbParameter Id = comm.CreateParameter();
            Id.ParameterName = "@id";
            Id.Value = id;
            Id.DbType = DbType.Int32;
            comm.Parameters.Add(Id);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);

        }

        public DataTable GetNews()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_News";

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetNewsDetail(int id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_NewsDetail";

            DbParameter Id = comm.CreateParameter();
            Id.ParameterName = "@id";
            Id.Value = id;
            Id.DbType = DbType.Int32;
            comm.Parameters.Add(Id);
            return GenericDataAccess.ExecuteReader(comm);
        }
    }
}