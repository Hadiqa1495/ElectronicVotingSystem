﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public class ResultModel
    {

        public string GetVoteCount(int et)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Get_VoteCount";
            // execute the stored procedure and return the results

            DbParameter elecId = comm.CreateParameter();
            elecId.ParameterName = "@election";
            elecId.Value = et;
            elecId.DbType = DbType.Int32;
            comm.Parameters.Add(elecId);

            return GenericDataAccess.ExecuteScalar(comm);
        }

        public DataTable GetConstituencyResult(int cons, int elec)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Get_ResultCandidateByConstituency";
            // execute the stored procedure and return the results

            DbParameter constituency = comm.CreateParameter();
            constituency.ParameterName = "@constituency";
            constituency.Value = cons;
            constituency.DbType = DbType.Int32;
            comm.Parameters.Add(constituency);

            DbParameter elecId = comm.CreateParameter();
            elecId.ParameterName = "@election";
            elecId.Value = elec;
            elecId.DbType = DbType.Int32;
            comm.Parameters.Add(elecId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetPartiesResult(int elec)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Get_ResultParty";
            // execute the stored procedure and return the results

            DbParameter elecId = comm.CreateParameter();
            elecId.ParameterName = "@electionId";
            elecId.Value = elec;
            elecId.DbType = DbType.Int32;
            comm.Parameters.Add(elecId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetPartyWinnersNA(int et)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Get_ResultWinnerPartyNA";
            // execute the stored procedure and return the results

            DbParameter elecId = comm.CreateParameter();
            elecId.ParameterName = "@electionId";
            elecId.Value = et;
            elecId.DbType = DbType.Int32;
            comm.Parameters.Add(elecId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetPartyWinners(int et)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Get_ResultWinnerParty";
            // execute the stored procedure and return the results

            DbParameter elecId = comm.CreateParameter();
            elecId.ParameterName = "@electionId";
            elecId.Value = et;
            elecId.DbType = DbType.Int32;
            comm.Parameters.Add(elecId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetPartyWinnersProvincially(int et, string seat)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Get_ResultWinnerPartyProvincially";
            // execute the stored procedure and return the results

            DbParameter elecId = comm.CreateParameter();
            elecId.ParameterName = "@electionId";
            elecId.Value = et;
            elecId.DbType = DbType.Int32;
            comm.Parameters.Add(elecId);

            DbParameter seatType = comm.CreateParameter();
            seatType.ParameterName = "@seatType";
            seatType.Value = seat;
            seatType.DbType = DbType.String;
            seatType.Size = 50;
            comm.Parameters.Add(seatType);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetPartyWinnersLGProvincially(int et)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Get_ResultWinnerPartyLGProvincially";
            // execute the stored procedure and return the results

            DbParameter elecId = comm.CreateParameter();
            elecId.ParameterName = "@electionId";
            elecId.Value = et;
            elecId.DbType = DbType.Int32;
            comm.Parameters.Add(elecId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetPartyWinnersPAProvincially(int et)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Get_ResultWinnerPartyPAProvincially";
            // execute the stored procedure and return the results

            DbParameter elecId = comm.CreateParameter();
            elecId.ParameterName = "@electionId";
            elecId.Value = et;
            elecId.DbType = DbType.Int32;
            comm.Parameters.Add(elecId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetAssemblyElectionWinners(int et, int dist)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Get_ResultWinnerAssemblyElection";
            // execute the stored procedure and return the results

            DbParameter elecId = comm.CreateParameter();
            elecId.ParameterName = "@electionId";
            elecId.Value = et;
            elecId.DbType = DbType.Int32;
            comm.Parameters.Add(elecId);

            DbParameter district_Id = comm.CreateParameter();
            district_Id.ParameterName = "@district_Id";
            district_Id.Value = dist;
            district_Id.DbType = DbType.Int32;
            comm.Parameters.Add(district_Id);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetLocalGovernmentElectionWinners(int et, int dist, int cons)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Get_ResultWinnerLocalGovermentElection";
            // execute the stored procedure and return the results

            DbParameter elecId = comm.CreateParameter();
            elecId.ParameterName = "@electionId";
            elecId.Value = et;
            elecId.DbType = DbType.Int32;
            comm.Parameters.Add(elecId);

            DbParameter district_Id = comm.CreateParameter();
            district_Id.ParameterName = "@district_Id";
            district_Id.Value = dist;
            district_Id.DbType = DbType.Int32;
            comm.Parameters.Add(district_Id);

            DbParameter constituency_Id = comm.CreateParameter();
            constituency_Id.ParameterName = "@constituency_Id";
            constituency_Id.Value = cons;
            constituency_Id.DbType = DbType.Int32;
            comm.Parameters.Add(constituency_Id);

            return GenericDataAccess.ExecuteReader(comm);
        }
    }
}