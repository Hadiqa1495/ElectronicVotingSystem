﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public class UserModel
    {
        public bool SaveUser(string UserName, string Email, string Password)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_InsertInto_User";
            // execute the stored procedure and return the results
           
            DbParameter email = comm.CreateParameter();
            email.ParameterName = "@Email";
            email.Value = Email;
            email.DbType = DbType.String;
            email.Size = 50;
            comm.Parameters.Add(email);

            DbParameter userName = comm.CreateParameter();
            userName.ParameterName = "@Username";
            userName.Value = UserName;
            userName.DbType = DbType.String;
            userName.Size = 50;
            comm.Parameters.Add(userName);

            DbParameter password = comm.CreateParameter();
            password.ParameterName = "@Password";
            password.Value = Password;
            password.DbType = DbType.String;
            password.Size = 50;
            comm.Parameters.Add(password);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public DataTable GetUserByLoginInfo(string Email, string Password)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_User_ByLoginInfo";

            DbParameter email = comm.CreateParameter();
            email.ParameterName = "@member_Email";
            email.Value = Email;
            email.DbType = DbType.String;
            email.Size = 50;
            comm.Parameters.Add(email);

            DbParameter password = comm.CreateParameter();
            password.ParameterName = "@member_Password";
            password.Value = Password;
            password.DbType = DbType.String;
            password.Size = 50;
            comm.Parameters.Add(password);
            // execute the stored procedure and return the results

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetUserByEmail(string Email)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_User_ByEmail";

            DbParameter email = comm.CreateParameter();
            email.ParameterName = "@Email";
            email.Value = Email;
            email.DbType = DbType.String;
            email.Size = 50;
            comm.Parameters.Add(email);
            // execute the stored procedure and return the results
            return GenericDataAccess.ExecuteReader(comm);
        }


    }      
}