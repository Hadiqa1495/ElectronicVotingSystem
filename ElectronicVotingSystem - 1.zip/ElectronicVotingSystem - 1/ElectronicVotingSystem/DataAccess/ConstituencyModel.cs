﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public class ConstituencyModel
    {
        public bool SaveConstituency(string Number, string Name, int parentId, int consTypeId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_InsertInto_Constituency";
            // execute the stored procedure and return the results

            DbParameter constituencyNumber = comm.CreateParameter();
            constituencyNumber.ParameterName = "@constituency_Number";
            constituencyNumber.Value = Number;
            constituencyNumber.DbType = DbType.String;
            constituencyNumber.Size = 50;
            comm.Parameters.Add(constituencyNumber);

            DbParameter constituencyName = comm.CreateParameter();
            constituencyName.ParameterName = "@constituency_Name";
            constituencyName.Value = Name;
            constituencyName.DbType = DbType.String;
            constituencyName.Size = 50;
            comm.Parameters.Add(constituencyName);

            DbParameter parent_Id = comm.CreateParameter();
            parent_Id.ParameterName = "@constituency_ParentId";
            parent_Id.Value = parentId;
            parent_Id.DbType = DbType.Int32;
            comm.Parameters.Add(parent_Id);

            DbParameter constituency_ConstituencyTypeId = comm.CreateParameter();
            constituency_ConstituencyTypeId.ParameterName = "@constituency_ConstituencyTypeId";
            constituency_ConstituencyTypeId.Value = consTypeId;
            constituency_ConstituencyTypeId.DbType = DbType.Int32;
            comm.Parameters.Add(constituency_ConstituencyTypeId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public bool UpdateConstituency(int Id, string Number, string Name, int parentId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_UpdateSet_Constituency";
            // execute the stored procedure and return the results

            DbParameter constituencyId = comm.CreateParameter();
            constituencyId.ParameterName = "@constituency_Id";
            constituencyId.Value = Id;
            constituencyId.DbType = DbType.Int32;
            comm.Parameters.Add(constituencyId);

            DbParameter constituencyNumber = comm.CreateParameter();
            constituencyNumber.ParameterName = "@constituency_Number";
            constituencyNumber.Value = Number;
            constituencyNumber.DbType = DbType.String;
            constituencyNumber.Size = 50;
            comm.Parameters.Add(constituencyNumber);

            DbParameter constituencyName = comm.CreateParameter();
            constituencyName.ParameterName = "@constituency_Name";
            constituencyName.Value = Name;
            constituencyName.DbType = DbType.String;
            constituencyName.Size = 50;
            comm.Parameters.Add(constituencyName);

            DbParameter parent_Id = comm.CreateParameter();
            parent_Id.ParameterName = "@constituency_ParentId";
            parent_Id.Value = parentId;
            parent_Id.DbType = DbType.Int32;
            comm.Parameters.Add(parent_Id);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);

        }

        public bool DeleteConstituency(int Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_DeleteFrom_Constituency";
            // execute the stored procedure and return the results

            DbParameter constituencyId = comm.CreateParameter();
            constituencyId.ParameterName = "@constituency_Id";
            constituencyId.Value = Id;
            constituencyId.DbType = DbType.Int32;
            comm.Parameters.Add(constituencyId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public DataTable GetConstituencyByNumberName(string Number, string name, int parentId, int consType)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_CustomValidator_Constituency";

            DbParameter constituencyNumber = comm.CreateParameter();
            constituencyNumber.ParameterName = "@constituency_Number";
            constituencyNumber.Value = Number;
            constituencyNumber.DbType = DbType.String;
            constituencyNumber.Size = 50;
            comm.Parameters.Add(constituencyNumber);

            DbParameter constituencyName = comm.CreateParameter();
            constituencyName.ParameterName = "@constituency_Name";
            constituencyName.Value = name;
            constituencyName.DbType = DbType.String;
            constituencyName.Size = 50;
            comm.Parameters.Add(constituencyName);

            DbParameter parent_Id = comm.CreateParameter();
            parent_Id.ParameterName = "@constituency_ParentId";
            parent_Id.Value = parentId;
            parent_Id.DbType = DbType.Int32;
            comm.Parameters.Add(parent_Id);


            DbParameter ConsType = comm.CreateParameter();
            ConsType.ParameterName = "@constituency_ConstituencyTypeId";
            ConsType.Value = consType;
            ConsType.DbType = DbType.Int32;
            comm.Parameters.Add(ConsType);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetCVConstituencyBlock(int blockId, int eType)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_CustomValidator_ConstituencyBlock";

            DbParameter parent_Id = comm.CreateParameter();
            parent_Id.ParameterName = "@blockId";
            parent_Id.Value = blockId;
            parent_Id.DbType = DbType.Int32;
            comm.Parameters.Add(parent_Id);

            DbParameter electionType = comm.CreateParameter();
            electionType.ParameterName = "@electionType";
            electionType.Value = eType;
            electionType.DbType = DbType.Int32;
            comm.Parameters.Add(electionType);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetConstituencyByIdNumberName(int Id, string Number, string Name, int parentId, int consType)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_CustomValidator_ConstituencyId";
            // execute the stored procedure and return the results

            DbParameter constituencyId = comm.CreateParameter();
            constituencyId.ParameterName = "@constituency_Id";
            constituencyId.Value = Id;
            constituencyId.DbType = DbType.Int32;
            comm.Parameters.Add(constituencyId);

            DbParameter constituencyNumber = comm.CreateParameter();
            constituencyNumber.ParameterName = "@constituency_Number";
            constituencyNumber.Value = Number;
            constituencyNumber.DbType = DbType.String;
            constituencyNumber.Size = 50;
            comm.Parameters.Add(constituencyNumber);

            DbParameter constituencyName = comm.CreateParameter();
            constituencyName.ParameterName = "@constituency_Name";
            constituencyName.Value = Name;
            constituencyName.DbType = DbType.String;
            constituencyName.Size = 50;
            comm.Parameters.Add(constituencyName);

            DbParameter parent_Id = comm.CreateParameter();
            parent_Id.ParameterName = "@constituency_ParentId";
            parent_Id.Value = parentId;
            parent_Id.DbType = DbType.Int32;
            comm.Parameters.Add(parent_Id);

            DbParameter ConsType = comm.CreateParameter();
            ConsType.ParameterName = "@constituency_ConstituencyTypeId";
            ConsType.Value = consType;
            ConsType.DbType = DbType.Int32;
            comm.Parameters.Add(ConsType);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetConstituencyByParentId(int parentId, int consTypeId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Constituency_ByParentIdConsTypeId";

            DbParameter ParentId = comm.CreateParameter();
            ParentId.ParameterName = "@parentId";
            ParentId.Value = parentId;
            ParentId.DbType = DbType.Int32;
            comm.Parameters.Add(ParentId);

            DbParameter ConsTypeId = comm.CreateParameter();
            ConsTypeId.ParameterName = "@consTypeId";
            ConsTypeId.Value = consTypeId;
            ConsTypeId.DbType = DbType.Int32;
            comm.Parameters.Add(ConsTypeId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetConstituencyByDistrictId(int distId, int consTypeId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Constituency_ByDistrictIdConsTypeId";

            DbParameter DistId = comm.CreateParameter();
            DistId.ParameterName = "@distId";
            DistId.Value = distId;
            DistId.DbType = DbType.Int32;
            comm.Parameters.Add(DistId);

            DbParameter ConsTypeId = comm.CreateParameter();
            ConsTypeId.ParameterName = "@consTypeId";
            ConsTypeId.Value = consTypeId;
            ConsTypeId.DbType = DbType.Int32;
            comm.Parameters.Add(ConsTypeId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GETLGConstituencyByDistrictElection(int dist, int elec)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_LGConstituency_ByDistrictElection";

            DbParameter DistId = comm.CreateParameter();
            DistId.ParameterName = "@dist_Id";
            DistId.Value = dist;
            DistId.DbType = DbType.Int32;
            comm.Parameters.Add(DistId);

            DbParameter vote_ElectionId = comm.CreateParameter();
            vote_ElectionId.ParameterName = "@vote_ElectionId";
            vote_ElectionId.Value = elec;
            vote_ElectionId.DbType = DbType.Int32;
            comm.Parameters.Add(vote_ElectionId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetLGConstituencyByDistrictId(int districtId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_LGConstituency_ByDistrictId";

            DbParameter DistrictId = comm.CreateParameter();
            DistrictId.ParameterName = "@dist_Id";
            DistrictId.Value = districtId;
            DistrictId.DbType = DbType.Int32;
            comm.Parameters.Add(DistrictId);

            return GenericDataAccess.ExecuteReader(comm);
        }        

        public DataTable GetConstituencyTypeByElectionTypeId(int etId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_ConstituencyType_ByElectionId";

            DbParameter ETId = comm.CreateParameter();
            ETId.ParameterName = "@etId";
            ETId.Value = etId;
            ETId.DbType = DbType.Int32;
            comm.Parameters.Add(ETId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetUCByLGCons(int LGCons)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Constituency_ByLG";

            DbParameter LgCons = comm.CreateParameter();
            LgCons.ParameterName = "@LGCons_Id";
            LgCons.Value = LGCons;
            LgCons.DbType = DbType.Int32;
            comm.Parameters.Add(LgCons);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetConstituencyType(int id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_ConstituencyType";

            DbParameter Id = comm.CreateParameter();
            Id.ParameterName = "@id";
            Id.Value = id;
            Id.DbType = DbType.Int32;
            comm.Parameters.Add(Id);


            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetConstituency(int id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Constituency";

            DbParameter Id = comm.CreateParameter();
            Id.ParameterName = "@distId";
            Id.Value = id;
            Id.DbType = DbType.Int32;
            comm.Parameters.Add(Id);


            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetConstituencyForUC(int id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Constituency_ForUC";

            DbParameter Id = comm.CreateParameter();
            Id.ParameterName = "@distId";
            Id.Value = id;
            Id.DbType = DbType.Int32;
            comm.Parameters.Add(Id);


            return GenericDataAccess.ExecuteReader(comm);
        }

        public bool SaveConstituencyBlock(int blockId, int consId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_InsertInto_ConstituencyBlock";
            // execute the stored procedure and return the results

            DbParameter parent_Id = comm.CreateParameter();
            parent_Id.ParameterName = "@blockId";
            parent_Id.Value = blockId;
            parent_Id.DbType = DbType.Int32;
            comm.Parameters.Add(parent_Id);

            DbParameter ConstituencyId = comm.CreateParameter();
            ConstituencyId.ParameterName = "@constituency_Id";
            ConstituencyId.Value = consId;
            ConstituencyId.DbType = DbType.Int32;
            comm.Parameters.Add(ConstituencyId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public DataTable GetConstituencyBlock(int consId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_ConstituencyBlock";

            DbParameter constituencyId = comm.CreateParameter();
            constituencyId.ParameterName = "@constituency_Id";
            constituencyId.Value = consId;
            constituencyId.DbType = DbType.String;
            constituencyId.Size = 50;
            comm.Parameters.Add(constituencyId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public bool DeleteConstituencyBlock(int Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_DeleteFrom_ConstituencyBlock";
            // execute the stored procedure and return the results

            DbParameter constituencyId = comm.CreateParameter();
            constituencyId.ParameterName = "@constituencyBlock_Id";
            constituencyId.Value = Id;
            constituencyId.DbType = DbType.Int32;
            comm.Parameters.Add(constituencyId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public DataTable GetConstitencyReport(string search)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Report_Constituency";

            DbParameter Search = comm.CreateParameter();
            Search.ParameterName = "@search";
            Search.Value = search;
            Search.DbType = DbType.String;
            Search.Size = 50;
            comm.Parameters.Add(Search);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetConstitency()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Report_ConstituencyGeneral";
            
            return GenericDataAccess.ExecuteReader(comm);
        }

    }
}