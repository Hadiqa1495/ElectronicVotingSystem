﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public class ChargeModel
    {
        public bool SaveCharge(string name, int tehsil_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_InsertInto_Charge";
            // execute the stored procedure and return the results

            DbParameter Name = comm.CreateParameter();
            Name.ParameterName = "@charge_Name";
            Name.Value = name;
            Name.DbType = DbType.String;
            Name.Size = 50;
            comm.Parameters.Add(Name);

            DbParameter tehsilId = comm.CreateParameter();
            tehsilId.ParameterName = "@charge_TehsilId";
            tehsilId.Value = tehsil_Id;
            tehsilId.DbType = DbType.Int32;
            comm.Parameters.Add(tehsilId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public bool UpdateCharge(int id, string name, int tehsil_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_UpdateSet_Charge";
            // execute the stored procedure and return the results

            DbParameter Id = comm.CreateParameter();
            Id.ParameterName = "@charge_Id";
            Id.Value = id;
            Id.DbType = DbType.Int32;
            comm.Parameters.Add(Id);

            DbParameter Name = comm.CreateParameter();
            Name.ParameterName = "@charge_Name";
            Name.Value = name;
            Name.DbType = DbType.String;
            Name.Size = 50;
            comm.Parameters.Add(Name);

            DbParameter tehsilId = comm.CreateParameter();
            tehsilId.ParameterName = "@charge_TehsilId";
            tehsilId.Value = tehsil_Id;
            tehsilId.DbType = DbType.Int32;
            comm.Parameters.Add(tehsilId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);

        }

        public bool DeleteCharge(int id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_DeleteFrom_Charge";
            // execute the stored procedure and return the results

            DbParameter Id = comm.CreateParameter();
            Id.ParameterName = "@charge_Id";
            Id.Value = id;
            Id.DbType = DbType.Int32;
            comm.Parameters.Add(Id);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public DataTable GetChargeByTehsilId(int tehsil_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Charge_ByTehsilId";
            // execute the stored procedure and return the results

            DbParameter tehsilId = comm.CreateParameter();
            tehsilId.ParameterName = "@charge_TehsilId";
            tehsilId.Value = tehsil_Id;
            tehsilId.DbType = DbType.Int32;
            comm.Parameters.Add(tehsilId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetChargeByNameTehsilId(string name, int tehsil_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Charge_ByNameTehsilId";
            // execute the stored procedure and return the results

            DbParameter districtName = comm.CreateParameter();
            districtName.ParameterName = "@charge_Name";
            districtName.Value = name;
            districtName.DbType = DbType.String;
            districtName.Size = 50;
            comm.Parameters.Add(districtName);

            DbParameter tehsilId = comm.CreateParameter();
            tehsilId.ParameterName = "@charge_TehsilId";
            tehsilId.Value = tehsil_Id;
            tehsilId.DbType = DbType.Int32;
            comm.Parameters.Add(tehsilId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetChargeByIdNameTehsilId(int id, string name, int tehsil_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Charge_ByIdNameTehsilId";
            // execute the stored procedure and return the results

            DbParameter Id = comm.CreateParameter();
            Id.ParameterName = "@charge_Id";
            Id.Value = id;
            Id.DbType = DbType.Int32;
            comm.Parameters.Add(Id);

            DbParameter districtName = comm.CreateParameter();
            districtName.ParameterName = "@charge_Name";
            districtName.Value = name;
            districtName.DbType = DbType.String;
            districtName.Size = 50;
            comm.Parameters.Add(districtName);

            DbParameter tehsilId = comm.CreateParameter();
            tehsilId.ParameterName = "@charge_TehsilId";
            tehsilId.Value = tehsil_Id;
            tehsilId.DbType = DbType.Int32;
            comm.Parameters.Add(tehsilId);

            return GenericDataAccess.ExecuteReader(comm);
        }

    }
}