﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public class BlockModel
    {
        public bool SaveBlock(int number, int mauza_Id, int circle_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_InsertInto_Block";
            // execute the stored procedure and return the results

            DbParameter no = comm.CreateParameter();
            no.ParameterName = "@block_Number";
            no.Value = number;
            no.DbType = DbType.Int32;
            comm.Parameters.Add(no);

            DbParameter mauzaId = comm.CreateParameter();
            mauzaId.ParameterName = "@block_MauzaId";
            mauzaId.Value = mauza_Id;
            mauzaId.DbType = DbType.Int32;
            comm.Parameters.Add(mauzaId);

            DbParameter circleId = comm.CreateParameter();
            circleId.ParameterName = "@block_CircleId";
            circleId.Value = circle_Id;
            circleId.DbType = DbType.Int32;
            comm.Parameters.Add(circleId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public bool UpdateBlock(int Id, int number, int mauza_Id, int circle_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_UpdateSet_Block";
            // execute the stored procedure and return the results

            DbParameter id = comm.CreateParameter();
            id.ParameterName = "@block_Id";
            id.Value = Id;
            id.DbType = DbType.Int32;
            comm.Parameters.Add(id);

            DbParameter no = comm.CreateParameter();
            no.ParameterName = "@block_Number";
            no.Value = number;
            no.DbType = DbType.Int32;
            comm.Parameters.Add(no);

            DbParameter mauzaId = comm.CreateParameter();
            mauzaId.ParameterName = "@block_MauzaId";
            mauzaId.Value = mauza_Id;
            mauzaId.DbType = DbType.Int32;
            comm.Parameters.Add(mauzaId);

            DbParameter circleId = comm.CreateParameter();
            circleId.ParameterName = "@block_CircleId";
            circleId.Value = circle_Id;
            circleId.DbType = DbType.Int32;
            comm.Parameters.Add(circleId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);

        }

        public bool DeleteBlock(int id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_DeleteFrom_Block";
            // execute the stored procedure and return the results

            DbParameter Id = comm.CreateParameter();
            Id.ParameterName = "@block_Id";
            Id.Value = id;
            Id.DbType = DbType.Int32;
            comm.Parameters.Add(Id);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public DataTable GetBlockByMauzaId(int mauza_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Block_ByMauzaId";
            // execute the stored procedure and return the results

            DbParameter mauzaId = comm.CreateParameter();
            mauzaId.ParameterName = "@block_MauzaId";
            mauzaId.Value = mauza_Id;
            mauzaId.DbType = DbType.Int32;
            comm.Parameters.Add(mauzaId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetBlockByMauzaIdCircleId(int mauza_Id, int circle_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Block_ByCircleIdMauzaId";
            // execute the stored procedure and return the results

            DbParameter mauzaId = comm.CreateParameter();
            mauzaId.ParameterName = "@block_MauzaId";
            mauzaId.Value = mauza_Id;
            mauzaId.DbType = DbType.Int32;
            comm.Parameters.Add(mauzaId);

            DbParameter circleId = comm.CreateParameter();
            circleId.ParameterName = "@block_CircleId";
            circleId.Value = circle_Id;
            circleId.DbType = DbType.Int32;
            comm.Parameters.Add(circleId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetBlockByNumberMauzaIdCircleId(int number, int mauza_Id, int circle_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Block_ByNumberCircleIdMauzaId";
            // execute the stored procedure and return the results

            DbParameter no = comm.CreateParameter();
            no.ParameterName = "@block_Number";
            no.Value = number;
            no.DbType = DbType.Int32;
            comm.Parameters.Add(no);

            DbParameter mauzaId = comm.CreateParameter();
            mauzaId.ParameterName = "@block_MauzaId";
            mauzaId.Value = mauza_Id;
            mauzaId.DbType = DbType.Int32;
            comm.Parameters.Add(mauzaId);

            DbParameter circleId = comm.CreateParameter();
            circleId.ParameterName = "@block_CircleId";
            circleId.Value = circle_Id;
            circleId.DbType = DbType.Int32;
            comm.Parameters.Add(circleId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetBlockByIdNumberMauzaIdCircleId(int Id, int number, int mauza_Id, int circle_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Block_ByIdNumberCircleIdMauzaId";
            // execute the stored procedure and return the results

            DbParameter id = comm.CreateParameter();
            id.ParameterName = "@block_Id";
            id.Value = Id;
            id.DbType = DbType.Int32;
            comm.Parameters.Add(id);

            DbParameter no = comm.CreateParameter();
            no.ParameterName = "@block_Number";
            no.Value = number;
            no.DbType = DbType.Int32;
            comm.Parameters.Add(no);

            DbParameter mauzaId = comm.CreateParameter();
            mauzaId.ParameterName = "@block_MauzaId";
            mauzaId.Value = mauza_Id;
            mauzaId.DbType = DbType.Int32;
            comm.Parameters.Add(mauzaId);

            DbParameter circleId = comm.CreateParameter();
            circleId.ParameterName = "@block_CircleId";
            circleId.Value = circle_Id;
            circleId.DbType = DbType.Int32;
            comm.Parameters.Add(circleId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetAreaReport(string search)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Report_Area";

            DbParameter Search = comm.CreateParameter();
            Search.ParameterName = "@search";
            Search.Value = search;
            Search.DbType = DbType.String;
            Search.Size = 50;
            comm.Parameters.Add(Search);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetArea()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Report_AreaGeneral";

            return GenericDataAccess.ExecuteReader(comm);
        }
    }
}