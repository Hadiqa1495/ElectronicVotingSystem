﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public class PartyModel
    {

        public bool SaveParty(string PartyName, string abb, string year, string leader, int PartySymbol, string chairman, string wiseChairman, string headOffice)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_InsertInto_Party";
            // execute the stored procedure and return the results

            DbParameter party_Name = comm.CreateParameter();
            party_Name.ParameterName = "@party_Name";
            party_Name.Value = PartyName;
            party_Name.DbType = DbType.String;
            party_Name.Size = 50;
            comm.Parameters.Add(party_Name);

            DbParameter party_Abbreviation = comm.CreateParameter();
            party_Abbreviation.ParameterName = "@party_Abbreviation";
            party_Abbreviation.Value = abb;
            party_Abbreviation.DbType = DbType.String;
            party_Abbreviation.Size = 50;
            comm.Parameters.Add(party_Abbreviation);

            DbParameter party_FoundationYear = comm.CreateParameter();
            party_FoundationYear.ParameterName = "@party_FoundationYear";
            party_FoundationYear.Value = year;
            party_FoundationYear.DbType = DbType.String;
            party_FoundationYear.Size = 50;
            comm.Parameters.Add(party_FoundationYear);

            DbParameter party_CurrentLeader = comm.CreateParameter();
            party_CurrentLeader.ParameterName = "@party_CurrentLeader";
            party_CurrentLeader.Value = leader;
            party_CurrentLeader.DbType = DbType.String;
            party_CurrentLeader.Size = 50;
            comm.Parameters.Add(party_CurrentLeader);

            DbParameter party_SymbolId = comm.CreateParameter();
            party_SymbolId.ParameterName = "@party_SymbolId";
            party_SymbolId.Value = PartySymbol;
            party_SymbolId.DbType = DbType.String;
            party_SymbolId.Size = 50;
            comm.Parameters.Add(party_SymbolId);

            DbParameter Chairman = comm.CreateParameter();
            Chairman.ParameterName = "@Chairman";
            Chairman.Value = chairman;
            Chairman.DbType = DbType.String;
            Chairman.Size = 50;
            comm.Parameters.Add(Chairman);

            DbParameter WiseChairman = comm.CreateParameter();
            WiseChairman.ParameterName = "@WiseChairman";
            WiseChairman.Value = wiseChairman;
            WiseChairman.DbType = DbType.String;
            WiseChairman.Size = 50;
            comm.Parameters.Add(WiseChairman);

            DbParameter HeadOffice = comm.CreateParameter();
            HeadOffice.ParameterName = "@HeadOffice";
            HeadOffice.Value = headOffice;
            HeadOffice.DbType = DbType.String;
            HeadOffice.Size = 500;
            comm.Parameters.Add(HeadOffice);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);

        }

        public bool UpdatePartyInfo(int PartyId, string PartyName, string abb, string year, string leader, int PartySymbol, string chairman, string wiseChairman, string headOffice)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_UpdateSet_Party";
            // execute the stored procedure and return the results

            DbParameter partyId = comm.CreateParameter();
            partyId.ParameterName = "@party_Id";
            partyId.Value = PartyId;
            partyId.DbType = DbType.Int32;
            comm.Parameters.Add(partyId);

            DbParameter party_Name = comm.CreateParameter();
            party_Name.ParameterName = "@party_Name";
            party_Name.Value = PartyName;
            party_Name.DbType = DbType.String;
            party_Name.Size = 50;
            comm.Parameters.Add(party_Name);

            DbParameter party_Abbreviation = comm.CreateParameter();
            party_Abbreviation.ParameterName = "@party_Abbreviation";
            party_Abbreviation.Value = abb;
            party_Abbreviation.DbType = DbType.String;
            party_Abbreviation.Size = 50;
            comm.Parameters.Add(party_Abbreviation);

            DbParameter party_FoundationYear = comm.CreateParameter();
            party_FoundationYear.ParameterName = "@party_FoundationYear";
            party_FoundationYear.Value = year;
            party_FoundationYear.DbType = DbType.String;
            party_FoundationYear.Size = 50;
            comm.Parameters.Add(party_FoundationYear);

            DbParameter party_CurrentLeader = comm.CreateParameter();
            party_CurrentLeader.ParameterName = "@party_CurrentLeader";
            party_CurrentLeader.Value = leader;
            party_CurrentLeader.DbType = DbType.String;
            party_CurrentLeader.Size = 50;
            comm.Parameters.Add(party_CurrentLeader);

            DbParameter party_SymbolId = comm.CreateParameter();
            party_SymbolId.ParameterName = "@party_SymbolId";
            party_SymbolId.Value = PartySymbol;
            party_SymbolId.DbType = DbType.String;
            party_SymbolId.Size = 50;
            comm.Parameters.Add(party_SymbolId);

            DbParameter Chairman = comm.CreateParameter();
            Chairman.ParameterName = "@Chairman";
            Chairman.Value = chairman;
            Chairman.DbType = DbType.String;
            Chairman.Size = 50;
            comm.Parameters.Add(Chairman);

            DbParameter WiseChairman = comm.CreateParameter();
            WiseChairman.ParameterName = "@WiseChairman";
            WiseChairman.Value = wiseChairman;
            WiseChairman.DbType = DbType.String;
            WiseChairman.Size = 50;
            comm.Parameters.Add(WiseChairman);

            DbParameter HeadOffice = comm.CreateParameter();
            HeadOffice.ParameterName = "@HeadOffice";
            HeadOffice.Value = headOffice;
            HeadOffice.DbType = DbType.String;
            HeadOffice.Size = 500;
            comm.Parameters.Add(HeadOffice);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public bool DeleteParty(int partyId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_DeleteFrom_Party";
            // execute the stored procedure and return the results

            DbParameter PartyId = comm.CreateParameter();
            PartyId.ParameterName = "@original_party_Id";
            PartyId.Value = partyId;
            PartyId.DbType = DbType.Int32;
            comm.Parameters.Add(PartyId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);

        }

        public DataTable GetParty()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Party";

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetPartyByName(string Name, int symbol)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Party_ByName";
            // execute the stored procedure and return the results

            DbParameter partyName = comm.CreateParameter();
            partyName.ParameterName = "@party_Name";
            partyName.Value = Name;
            partyName.DbType = DbType.String;
            partyName.Size = 50;
            comm.Parameters.Add(partyName);

            DbParameter symbolId = comm.CreateParameter();
            symbolId.ParameterName = "@symbolId";
            symbolId.Value = symbol;
            symbolId.DbType = DbType.Int32;
            comm.Parameters.Add(symbolId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetPartyByIdName(int id, string Name, int symbol)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Party_ByIdName";
            // execute the stored procedure and return the results

            DbParameter partyId = comm.CreateParameter();
            partyId.ParameterName = "@partyId";
            partyId.Value = id;
            partyId.DbType = DbType.Int32;
            comm.Parameters.Add(partyId);

            DbParameter partyName = comm.CreateParameter();
            partyName.ParameterName = "@party_Name";
            partyName.Value = Name;
            partyName.DbType = DbType.String;
            partyName.Size = 50;
            comm.Parameters.Add(partyName);

            DbParameter symbolId = comm.CreateParameter();
            symbolId.ParameterName = "@symbolId";
            symbolId.Value = symbol;
            symbolId.DbType = DbType.Int32;
            comm.Parameters.Add(symbolId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetPartyWithSymbol()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Get_Party";

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetPartyResultReport(string search)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Report_PartyResult";

            DbParameter Search = comm.CreateParameter();
            Search.ParameterName = "@search";
            Search.Value = search;
            Search.DbType = DbType.String;
            Search.Size = 50;
            comm.Parameters.Add(Search);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetPartyResult()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Report_PartyResultGeneral";

            return GenericDataAccess.ExecuteReader(comm);
        }
    }
}