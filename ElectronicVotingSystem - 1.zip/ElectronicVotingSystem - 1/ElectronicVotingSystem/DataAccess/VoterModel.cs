﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public class VoterModel
    {

        public string GetVotersCount()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Get_VotersCount";
            // execute the stored procedure and return the results

            return GenericDataAccess.ExecuteScalar(comm);
        }
        
        public DataTable GetVoterByCnic(string cnic)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Voter_ByCnic";
            // execute the stored procedure and return the results

            DbParameter CNIC = comm.CreateParameter();
            CNIC.ParameterName = "@cnic";
            CNIC.Value = cnic;
            CNIC.DbType = DbType.String;
            CNIC.Size = 50;
            comm.Parameters.Add(CNIC);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetVoterReport(string search)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Report_Voter";

            DbParameter Search = comm.CreateParameter();
            Search.ParameterName = "@search";
            Search.Value = search;
            Search.DbType = DbType.String;
            Search.Size = 50;
            comm.Parameters.Add(Search);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetVoter()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Report_VoterGeneral";
            
            return GenericDataAccess.ExecuteReader(comm);
        }
    }
}