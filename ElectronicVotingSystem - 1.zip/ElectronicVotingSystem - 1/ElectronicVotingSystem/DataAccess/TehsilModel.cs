﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public class TehsilModel
    {
        public bool SaveTehsil(string Name, int distId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_InsertInto_Tehsil";
            // execute the stored procedure and return the results

            DbParameter districtName = comm.CreateParameter();
            districtName.ParameterName = "@tehsil_Name";
            districtName.Value = Name;
            districtName.DbType = DbType.String;
            districtName.Size = 50;
            comm.Parameters.Add(districtName);

            DbParameter adminUnitId = comm.CreateParameter();
            adminUnitId.ParameterName = "@tehsil_DistrictId";
            adminUnitId.Value = distId;
            adminUnitId.DbType = DbType.Int32;
            comm.Parameters.Add(adminUnitId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public bool UpdateTehsil(int id, string name, int distId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_UpdateSet_Tehsil";
            // execute the stored procedure and return the results

            DbParameter districtId = comm.CreateParameter();
            districtId.ParameterName = "@tehsil_DistrictId";
            districtId.Value = distId;
            districtId.DbType = DbType.Int32;
            comm.Parameters.Add(districtId);

            DbParameter Name = comm.CreateParameter();
            Name.ParameterName = "@tehsil_Name";
            Name.Value = name;
            Name.DbType = DbType.String;
            Name.Size = 50;
            comm.Parameters.Add(Name);

            DbParameter Id = comm.CreateParameter();
            Id.ParameterName = "@tehsil_Id";
            Id.Value = id;
            Id.DbType = DbType.Int32;
            comm.Parameters.Add(Id);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);

        }

        public bool DeleteTehsil(int Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_DeleteFrom_Tehsil";
            // execute the stored procedure and return the results

            DbParameter tehsilId = comm.CreateParameter();
            tehsilId.ParameterName = "@tehsil_Id";
            tehsilId.Value = Id;
            tehsilId.DbType = DbType.Int32;
            comm.Parameters.Add(tehsilId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public DataTable GetTehsilByDistrictId(int distId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Tehsil_ByDistrictId";
            // execute the stored procedure and return the results

            DbParameter districtId = comm.CreateParameter();
            districtId.ParameterName = "@distId";
            districtId.Value = distId;
            districtId.DbType = DbType.Int32;
            comm.Parameters.Add(districtId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetTehsilByNameDistrictId(string name, int distId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Tehsil_ByNameDistrictId";
            // execute the stored procedure and return the results

            DbParameter districtName = comm.CreateParameter();
            districtName.ParameterName = "@name";
            districtName.Value = name;
            districtName.DbType = DbType.String;
            districtName.Size = 50;
            comm.Parameters.Add(districtName);

            DbParameter districtId = comm.CreateParameter();
            districtId.ParameterName = "@distId";
            districtId.Value = distId;
            districtId.DbType = DbType.Int32;
            comm.Parameters.Add(districtId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetTehsilByIdNameDistrictId(int id, string name, int distId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Tehsil_ByIdNameDistrictId";
            // execute the stored procedure and return the results

            DbParameter Id = comm.CreateParameter();
            Id.ParameterName = "@id";
            Id.Value = id;
            Id.DbType = DbType.Int32;
            comm.Parameters.Add(Id);

            DbParameter districtName = comm.CreateParameter();
            districtName.ParameterName = "@name";
            districtName.Value = name;
            districtName.DbType = DbType.String;
            districtName.Size = 50;
            comm.Parameters.Add(districtName);

            DbParameter districtId = comm.CreateParameter();
            districtId.ParameterName = "@distId";
            districtId.Value = distId;
            districtId.DbType = DbType.Int32;
            comm.Parameters.Add(districtId);

            return GenericDataAccess.ExecuteReader(comm);
        }

    }
}