﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public class SymbolModel
    {

        public bool SaveSymbol(string AddSymbol, string imageName, string imageType ,byte[] n_Image_Size)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_InsertInto_Symbol";
            // execute the stored procedure and return the results
            DbParameter symbolName = comm.CreateParameter();
            symbolName.ParameterName = "@symbol_Name";
            symbolName.Value = AddSymbol;
            symbolName.DbType = DbType.String;
            symbolName.Size = 50;
            comm.Parameters.Add(symbolName);

            DbParameter Image_Name = comm.CreateParameter();
            Image_Name.ParameterName = "@symbol_ImageName";
            Image_Name.Value = imageName;
            Image_Name.DbType = DbType.String;
            Image_Name.Size = 500;
            comm.Parameters.Add(Image_Name);

            DbParameter Image_Type = comm.CreateParameter();
            Image_Type.ParameterName = "@symbol_ImageType";
            Image_Type.Value = imageType;
            Image_Type.DbType = DbType.String;
            Image_Type.Size = 500;
            comm.Parameters.Add(Image_Type);

            DbParameter N_Image_Size = comm.CreateParameter();
            N_Image_Size.ParameterName = "@symbol_ImageContent";
            N_Image_Size.Value = n_Image_Size;
            N_Image_Size.DbType = DbType.Binary;
            N_Image_Size.Size = n_Image_Size.Length;
            comm.Parameters.Add(N_Image_Size);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);

        }

        public bool UpdateSymbolInfo(int SymbolId, string SymbolName, string imageName, string imageType, byte[] n_Image_Size)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_UpdateSet_Symbol";
            // execute the stored procedure and return the results

            DbParameter symbolId = comm.CreateParameter();
            symbolId.ParameterName = "@original_symbol_Id";
            symbolId.Value = SymbolId;
            symbolId.DbType = DbType.Int32;
            comm.Parameters.Add(symbolId);

            DbParameter symbolName = comm.CreateParameter();
            symbolName.ParameterName = "@symbol_Name";
            symbolName.Value = SymbolName;
            symbolName.DbType = DbType.String;
            symbolName.Size = 50;
            comm.Parameters.Add(symbolName);

            DbParameter Image_Name = comm.CreateParameter();
            Image_Name.ParameterName = "@symbol_ImageName";
            Image_Name.Value = imageName;
            Image_Name.DbType = DbType.String;
            Image_Name.Size = 500;
            comm.Parameters.Add(Image_Name);

            DbParameter Image_Type = comm.CreateParameter();
            Image_Type.ParameterName = "@symbol_ImageType";
            Image_Type.Value = imageType;
            Image_Type.DbType = DbType.String;
            Image_Type.Size = 500;
            comm.Parameters.Add(Image_Type);

            DbParameter N_Image_Size = comm.CreateParameter();
            N_Image_Size.ParameterName = "@symbol_ImageContent";
            N_Image_Size.Value = n_Image_Size;
            N_Image_Size.DbType = DbType.Binary;
            N_Image_Size.Size = n_Image_Size.Length;
            comm.Parameters.Add(N_Image_Size);

           // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public bool DeleteSymbol(int SymbolId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_DeleteFrom_Symbol";
            // execute the stored procedure and return the results

            DbParameter symbolId = comm.CreateParameter();
            symbolId.ParameterName = "@original_symbol_Id";
            symbolId.Value = SymbolId;
            symbolId.DbType = DbType.Int32;
            comm.Parameters.Add(symbolId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);

        }

        public DataTable GetSymbol()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Symbol";
            // execute the stored procedure and return the results
            return GenericDataAccess.ExecuteReader(comm);

        }

        public DataTable GetImage(int id)
        {
            DataTable dt = new DataTable();
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Get_Image";

            DbParameter ID = comm.CreateParameter();
            ID.ParameterName = "@imgId";
            ID.Value = id;
            ID.DbType = DbType.Int32;
            comm.Parameters.Add(ID);

            // execute the stored procedure and return the results
            return GenericDataAccess.ExecuteReader(comm);
        }
        public DataTable GetSymbolFiltered()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Symbol_ByFilter";
            // execute the stored procedure and return the results
            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetSymbolByNameSymbolId(int Id, string Name)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Symbol_ByIdName";
            // execute the stored procedure and return the results

            DbParameter symbolId = comm.CreateParameter();
            symbolId.ParameterName = "@symbol_Id";
            symbolId.Value = Id;
            symbolId.DbType = DbType.Int32;
            comm.Parameters.Add(symbolId);

            DbParameter symbolName = comm.CreateParameter();
            symbolName.ParameterName = "@symbol_Name";
            symbolName.Value = Name;
            symbolName.DbType = DbType.String;
            symbolName.Size = 50;
            comm.Parameters.Add(symbolName);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetSymbolByName( string Name)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Symbol_ByName";
            // execute the stored procedure and return the results

            DbParameter symbolName = comm.CreateParameter();
            symbolName.ParameterName = "@symbol_Name";
            symbolName.Value = Name;
            symbolName.DbType = DbType.String;
            symbolName.Size = 50;
            comm.Parameters.Add(symbolName);

            return GenericDataAccess.ExecuteReader(comm);
        }

    }
}