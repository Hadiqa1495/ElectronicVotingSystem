﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public static class MemberModel
    {
        static MemberModel()
        {

        }

        public static DataTable GetRole()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Role";
            // execute the stored procedure and return the results
            return GenericDataAccess.ExecuteReader(comm);
        }

        public static bool SaveMember(int RoleId, string FirstName, string LastName, string UserName, string Password)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_InsertInto_Member";
            // execute the stored procedure and return the results
            DbParameter roleid = comm.CreateParameter();
            roleid.ParameterName = "@member_RoleId";
            roleid.Value = RoleId;
            roleid.DbType = DbType.Int32;
            comm.Parameters.Add(roleid);

            DbParameter firstName = comm.CreateParameter();
            firstName.ParameterName = "@member_FirstName";
            firstName.Value = FirstName;
            firstName.DbType = DbType.String;
            firstName.Size = 50;
            comm.Parameters.Add(firstName);

            DbParameter lastName = comm.CreateParameter();
            lastName.ParameterName = "@member_LastName";
            lastName.Value = LastName;
            lastName.DbType = DbType.String;
            lastName.Size = 50;
            comm.Parameters.Add(lastName);

            DbParameter userName = comm.CreateParameter();
            userName.ParameterName = "@member_Username";
            userName.Value = UserName;
            userName.DbType = DbType.String;
            userName.Size = 50;
            comm.Parameters.Add(userName);

            DbParameter password = comm.CreateParameter();
            password.ParameterName = "@member_Password";
            password.Value = Password;
            password.DbType = DbType.String;
            password.Size = 50;
            comm.Parameters.Add(password);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public static DataTable GetMemberByLoginInfo(int RoleId, string UserName, string Password)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_ByLoginInfo_Member";

            DbParameter roleid = comm.CreateParameter();
            roleid.ParameterName = "@member_RoleId";
            roleid.Value = RoleId;
            roleid.DbType = DbType.Int32;
            comm.Parameters.Add(roleid);

            DbParameter userName = comm.CreateParameter();
            userName.ParameterName = "@member_Username";
            userName.Value = UserName;
            userName.DbType = DbType.String;
            userName.Size = 50;
            comm.Parameters.Add(userName);

            DbParameter password = comm.CreateParameter();
            password.ParameterName = "@member_Password";
            password.Value = Password;
            password.DbType = DbType.String;
            password.Size = 50;
            comm.Parameters.Add(password);
            // execute the stored procedure and return the results

            return GenericDataAccess.ExecuteReader(comm);
        }

        public static DataTable GetMemberByEmail(int RoleId, string UserName)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_ByEmail_Member";

            DbParameter roleid = comm.CreateParameter();
            roleid.ParameterName = "@member_RoleId";
            roleid.Value = RoleId;
            roleid.DbType = DbType.Int32;
            comm.Parameters.Add(roleid);

            DbParameter userName = comm.CreateParameter();
            userName.ParameterName = "@member_Username";
            userName.Value = UserName;
            userName.DbType = DbType.String;
            userName.Size = 50;
            comm.Parameters.Add(userName);
            // execute the stored procedure and return the results
            return GenericDataAccess.ExecuteReader(comm);
        }

        public static bool UpdateMemberInfo(string Password, int MemberId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_UpdateSet_Member";
            // execute the stored procedure and return the results

            DbParameter password = comm.CreateParameter();
            password.ParameterName = "@member_Password";
            password.Value = Password;
            password.DbType = DbType.String;
            password.Size = 50;
            comm.Parameters.Add(password);

            DbParameter memberId = comm.CreateParameter();
            memberId.ParameterName = "@member_Id";
            memberId.Value = MemberId;
            memberId.DbType = DbType.Int32;
            comm.Parameters.Add(memberId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

    }
}