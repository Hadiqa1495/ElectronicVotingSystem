﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public class AdministrativeUnitModel
    {
        public bool SaveAdministrativeUnit(string administrativeUnit, int typeId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_InsertInto_AdministrativeUnit";
            // execute the stored procedure and return the results
            DbParameter adminName = comm.CreateParameter();
            adminName.ParameterName = "@administrativeUnit_Name";
            adminName.Value = administrativeUnit;
            adminName.DbType = DbType.String;
            adminName.Size = 50;
            comm.Parameters.Add(adminName);

            DbParameter adminType = comm.CreateParameter();
            adminType.ParameterName = "@adminUnitTypeId";
            adminType.Value = typeId;
            adminType.DbType = DbType.String;
            adminType.Size = 50;
            comm.Parameters.Add(adminType);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);

        }

        public bool UpdateAdministrativeUnit(int adminUnitId, string adminUnitName)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_UpdateSet_AdministrativeUnit";
            // execute the stored procedure and return the results

            DbParameter adminId = comm.CreateParameter();
            adminId.ParameterName = "@administrativeUnit_Id";
            adminId.Value = adminUnitId;
            adminId.DbType = DbType.Int32;
            comm.Parameters.Add(adminId);

            DbParameter adminName = comm.CreateParameter();
            adminName.ParameterName = "@administrativeUnit_Name";
            adminName.Value = adminUnitName;
            adminName.DbType = DbType.String;
            adminName.Size = 50;
            comm.Parameters.Add(adminName);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);

        }

        public bool DeleteAdministrativeUnit(int adminUnitId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_DeleteFrom_AdministrativeUnit";
            // execute the stored procedure and return the results

            DbParameter adminId = comm.CreateParameter();
            adminId.ParameterName = "@administrativeUnit_Id";
            adminId.Value = adminUnitId;
            adminId.DbType = DbType.Int32;
            comm.Parameters.Add(adminId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);

        }

        public DataTable GetAdminUnit()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_AdministrativeUnit";

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetProvinces()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_AdministrativeUnit_ByAdministrativeUnitTypeId";

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetAdminUnitType()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_AdministrativeUnitType";

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetAdminUnitByAdminUnitName(string adminUnitName)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_AdministrativeUnit_ByAdministrativeUnitName";

            DbParameter adminName = comm.CreateParameter();
            adminName.ParameterName = "@administrativeUnit_Name";
            adminName.Value = adminUnitName;
            adminName.DbType = DbType.String;
            adminName.Size = 50;
            comm.Parameters.Add(adminName);
            // execute the stored procedure and return the results
            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetAdminUnitByIdName(int id,string adminUnitName)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_AdministrativeUnit_ByIdName";
            DbParameter adminId = comm.CreateParameter();
            adminId.ParameterName = "@id";
            adminId.Value = id;
            adminId.DbType = DbType.Int32;
            comm.Parameters.Add(adminId);
            DbParameter adminName = comm.CreateParameter();
            adminName.ParameterName = "@name";
            adminName.Value = adminUnitName;
            adminName.DbType = DbType.String;
            adminName.Size = 50;
            comm.Parameters.Add(adminName);
            // execute the stored procedure and return the results
            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetAdminUnitTypeByAdminUnit(int adminUnitId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_AdministrativeUnitType_ByAdministrativeUnitId";

            DbParameter id = comm.CreateParameter();
            id.ParameterName = "@administrativeUnit_Id";
            id.Value = adminUnitId;
            id.DbType = DbType.Int32;
            comm.Parameters.Add(id);
            // execute the stored procedure and return the results
            return GenericDataAccess.ExecuteReader(comm);
        }

    }
}