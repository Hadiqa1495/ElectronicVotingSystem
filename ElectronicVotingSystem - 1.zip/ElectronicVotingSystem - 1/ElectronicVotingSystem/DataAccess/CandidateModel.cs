﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public class CandidateModel
    {
       public DataTable GetSeatTypeByConstituencyType(int cType)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_SeatType_ByConstituencyType";

            DbParameter constituencyType = comm.CreateParameter();
            constituencyType.ParameterName = "@consTypeId";
            constituencyType.Value = cType;
            constituencyType.DbType = DbType.Int32;
            comm.Parameters.Add(constituencyType);


            return GenericDataAccess.ExecuteReader(comm);
        }

       public DataTable GetSeatTypeByElectionDistrict(int election, int district)
       {
           // get a configured DbCommand object
           DbCommand comm = GenericDataAccess.CreateCommand();
           // set the stored procedure name
           comm.CommandText = "sp_SelectFrom_SeatType_ByElectionDistrict";

           DbParameter district_Id = comm.CreateParameter();
           district_Id.ParameterName = "@district_Id";
           district_Id.Value = district;
           district_Id.DbType = DbType.Int32;
           comm.Parameters.Add(district_Id);

           DbParameter vote_ElectionId = comm.CreateParameter();
           vote_ElectionId.ParameterName = "@vote_ElectionId";
           vote_ElectionId.Value = election;
           vote_ElectionId.DbType = DbType.Int32;
           comm.Parameters.Add(vote_ElectionId);


           return GenericDataAccess.ExecuteReader(comm);
       }

        public bool SaveCandidate(int voterId, int seatTypeId, int symbolId, int electId,int partyId, int cons)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_InsertInto_Candidate";
            // execute the stored procedure and return the results
            DbParameter candidate_VoterId = comm.CreateParameter();
            candidate_VoterId.ParameterName = "@candidate_VoterId";
            candidate_VoterId.Value = voterId;
            candidate_VoterId.DbType = DbType.Int64;
            comm.Parameters.Add(candidate_VoterId);

            if (symbolId > 0)
            {
                DbParameter candiadte_SymbolId = comm.CreateParameter();
                candiadte_SymbolId.ParameterName = "@candiadte_SymbolId";
                candiadte_SymbolId.Value = symbolId;
                candiadte_SymbolId.DbType = DbType.Int32;
                comm.Parameters.Add(candiadte_SymbolId);
            }

            DbParameter candidate_ElectionId = comm.CreateParameter();
            candidate_ElectionId.ParameterName = "@candidate_ElectionId";
            candidate_ElectionId.Value = electId;
            candidate_ElectionId.DbType = DbType.Int32;
            comm.Parameters.Add(candidate_ElectionId);

            DbParameter candidate_SeatTypeId = comm.CreateParameter();
            candidate_SeatTypeId.ParameterName = "@candidate_SeatTypeId";
            candidate_SeatTypeId.Value = seatTypeId;
            candidate_SeatTypeId.DbType = DbType.Int32;
            comm.Parameters.Add(candidate_SeatTypeId);

            if (partyId > 0)
            {
                DbParameter candidate_PartyId = comm.CreateParameter();
                candidate_PartyId.ParameterName = "@candidate_PartyId";
                candidate_PartyId.Value = partyId;
                candidate_PartyId.DbType = DbType.Int32;
                comm.Parameters.Add(candidate_PartyId);
            }

            DbParameter Cons = comm.CreateParameter();
            Cons.ParameterName = "@Cons";
            Cons.Value = cons;
            Cons.DbType = DbType.Int32;
            comm.Parameters.Add(Cons);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);

        }

        public bool DeleteCandidate(int candidate)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_DeleteFrom_Candidate";
            // execute the stored procedure and return the results

            DbParameter candidate_Id = comm.CreateParameter();
            candidate_Id.ParameterName = "@candidate_Id";
            candidate_Id.Value = candidate;
            candidate_Id.DbType = DbType.Int32;
            comm.Parameters.Add(candidate_Id);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);

        }

        public DataTable GetCandidateByElectionSeatType(int elec, int seatType, int cons)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Candidate_ByElectionSeatType";

            DbParameter candidate_ElectionId = comm.CreateParameter();
            candidate_ElectionId.ParameterName = "@candidate_ElectionId";
            candidate_ElectionId.Value = elec;
            candidate_ElectionId.DbType = DbType.Int32;
            comm.Parameters.Add(candidate_ElectionId);

            DbParameter candidate_seatTypeId = comm.CreateParameter();
            candidate_seatTypeId.ParameterName = "@candidate_SeatTypeId";
            candidate_seatTypeId.Value = seatType;
            candidate_seatTypeId.DbType = DbType.Int32;
            comm.Parameters.Add(candidate_seatTypeId);

            DbParameter candidate_ConsTypeId = comm.CreateParameter();
            candidate_ConsTypeId.ParameterName = "@candidate_ConsTypeId";
            candidate_ConsTypeId.Value = cons;
            candidate_ConsTypeId.DbType = DbType.Int32;
            comm.Parameters.Add(candidate_ConsTypeId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetCVCandidate(int voterId, int electId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_CustomValidator_Candidate";

            DbParameter ElectId = comm.CreateParameter();
            ElectId.ParameterName = "@electId";
            ElectId.Value = electId;
            ElectId.DbType = DbType.Int32;
            comm.Parameters.Add(ElectId);

            DbParameter VoterId = comm.CreateParameter();
            VoterId.ParameterName = "@voterId";
            VoterId.Value = voterId;
            VoterId.DbType = DbType.Int32;
            comm.Parameters.Add(VoterId);
            
            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetCVCandidateCons(int parentId , int electId, int symbolId, int partyId, int seatTypeId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_CustomValidator_CandidateCons";

            DbParameter ElectId = comm.CreateParameter();
            ElectId.ParameterName = "@electId";
            ElectId.Value = electId;
            ElectId.DbType = DbType.Int32;
            comm.Parameters.Add(ElectId);

            DbParameter ParentId = comm.CreateParameter();
            ParentId.ParameterName = "@parentId";
            ParentId.Value = parentId;
            ParentId.DbType = DbType.Int32;
            comm.Parameters.Add(ParentId);

            DbParameter SymbolId = comm.CreateParameter();
            SymbolId.ParameterName = "@symbolId";
            SymbolId.Value = symbolId;
            SymbolId.DbType = DbType.Int32;
            comm.Parameters.Add(SymbolId);

            DbParameter SeatTypeId = comm.CreateParameter();
            SeatTypeId.ParameterName = "@seatTypeId";
            SeatTypeId.Value = seatTypeId;
            SeatTypeId.DbType = DbType.Int32;
            comm.Parameters.Add(SeatTypeId);

            DbParameter PartyId = comm.CreateParameter();
            PartyId.ParameterName = "@partyId";
            PartyId.Value = partyId;
            PartyId.DbType = DbType.Int32;
            comm.Parameters.Add(PartyId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetCandidateReport(string search)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Report_Candidate";

            DbParameter Search = comm.CreateParameter();
            Search.ParameterName = "@search";
            Search.Value = search;
            Search.DbType = DbType.String;
            Search.Size = 50;
            comm.Parameters.Add(Search);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetCandidate()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Report_CandidateGeneral";
            
            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetCandidateResultReport(string search)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Report_CandidateResult";

            DbParameter Search = comm.CreateParameter();
            Search.ParameterName = "@search";
            Search.Value = search;
            Search.DbType = DbType.String;
            Search.Size = 50;
            comm.Parameters.Add(Search);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetCandidateResult()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Report_CandidateresultGeneral";

            return GenericDataAccess.ExecuteReader(comm);
        }
    }
}