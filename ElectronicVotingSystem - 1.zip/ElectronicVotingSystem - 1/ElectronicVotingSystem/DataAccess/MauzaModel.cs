﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public class MauzaModel
    {
        public bool SaveMauza(string name, int tehsil_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_InsertInto_Mauza";
            // execute the stored procedure and return the results

            DbParameter Name = comm.CreateParameter();
            Name.ParameterName = "@mauza_Name";
            Name.Value = name;
            Name.DbType = DbType.String;
            Name.Size = 50;
            comm.Parameters.Add(Name);

            DbParameter tehsilId = comm.CreateParameter();
            tehsilId.ParameterName = "@mauza_TehsilId";
            tehsilId.Value = tehsil_Id;
            tehsilId.DbType = DbType.Int32;
            comm.Parameters.Add(tehsilId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public bool UpdateMauza(int id, string name, int tehsil_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_UpdateSet_Mauza";
            // execute the stored procedure and return the results

            DbParameter Id = comm.CreateParameter();
            Id.ParameterName = "@mauza_Id";
            Id.Value = id;
            Id.DbType = DbType.Int32;
            comm.Parameters.Add(Id);

            DbParameter Name = comm.CreateParameter();
            Name.ParameterName = "@mauza_Name";
            Name.Value = name;
            Name.DbType = DbType.String;
            Name.Size = 50;
            comm.Parameters.Add(Name);

            DbParameter tehsilId = comm.CreateParameter();
            tehsilId.ParameterName = "@mauza_TehsilId";
            tehsilId.Value = tehsil_Id;
            tehsilId.DbType = DbType.Int32;
            comm.Parameters.Add(tehsilId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);

        }

        public bool DeleteMauza(int id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_DeleteFrom_Mauza";
            // execute the stored procedure and return the results

            DbParameter Id = comm.CreateParameter();
            Id.ParameterName = "@mauza_Id";
            Id.Value = id;
            Id.DbType = DbType.Int32;
            comm.Parameters.Add(Id);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public DataTable GetMauzaByTehsilId(int tehsil_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Mauza_ByTehsilId";
            // execute the stored procedure and return the results

            DbParameter tehsilId = comm.CreateParameter();
            tehsilId.ParameterName = "@mauza_TehsilId";
            tehsilId.Value = tehsil_Id;
            tehsilId.DbType = DbType.Int32;
            comm.Parameters.Add(tehsilId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetMauzaByNameTehsilId(string name, int tehsil_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Mauza_ByNameTehsilId";
            // execute the stored procedure and return the results

            DbParameter districtName = comm.CreateParameter();
            districtName.ParameterName = "@mauza_Name";
            districtName.Value = name;
            districtName.DbType = DbType.String;
            districtName.Size = 50;
            comm.Parameters.Add(districtName);

            DbParameter tehsilId = comm.CreateParameter();
            tehsilId.ParameterName = "@mauza_TehsilId";
            tehsilId.Value = tehsil_Id;
            tehsilId.DbType = DbType.Int32;
            comm.Parameters.Add(tehsilId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetMauzaByIdNameTehsilId(int id, string name, int tehsil_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Mauza_ByIdNameTehsilId";
            // execute the stored procedure and return the results

            DbParameter Id = comm.CreateParameter();
            Id.ParameterName = "@mauza_Id";
            Id.Value = id;
            Id.DbType = DbType.Int32;
            comm.Parameters.Add(Id);

            DbParameter districtName = comm.CreateParameter();
            districtName.ParameterName = "@mauza_Name";
            districtName.Value = name;
            districtName.DbType = DbType.String;
            districtName.Size = 50;
            comm.Parameters.Add(districtName);

            DbParameter tehsilId = comm.CreateParameter();
            tehsilId.ParameterName = "@mauza_TehsilId";
            tehsilId.Value = tehsil_Id;
            tehsilId.DbType = DbType.Int32;
            comm.Parameters.Add(tehsilId);

            return GenericDataAccess.ExecuteReader(comm);
        }

    }
}