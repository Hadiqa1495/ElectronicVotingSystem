﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public class ChartsModel
    {
        public DataTable candidateVsConstituency(int id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Chart_CandidateVSConstituency";

            DbParameter electionId = comm.CreateParameter();
            electionId.ParameterName = "@id";
            electionId.Value = id;
            electionId.DbType = DbType.Int32;
            comm.Parameters.Add(electionId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable voterVsConstituency()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Chart_VoterVSConstituency";

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable ElectionVSCandidate(int id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Chart_ElectionVSCandidate";

            DbParameter electionId = comm.CreateParameter();
            electionId.ParameterName = "@id";
            electionId.Value = id;
            electionId.DbType = DbType.Int32;
            comm.Parameters.Add(electionId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable electionVSVote()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Chart_ElectionVSVote";

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable pollingstationVSConstituency()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Chart_PollingStationVSConstituency";

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable pollingstationVSDistrict()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Chart_PollingStationVSDistrict";

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable VoteVSConstituency(int id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Chart_VoteVSConstituency";

            DbParameter electionId = comm.CreateParameter();
            electionId.ParameterName = "@id";
            electionId.Value = id;
            electionId.DbType = DbType.Int32;
            comm.Parameters.Add(electionId);


            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable PartyVSSeatsWinBySeatType(int id, string seat)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Chart_PartyVSSeatsWinBySeatType";

            DbParameter electionId = comm.CreateParameter();
            electionId.ParameterName = "@id";
            electionId.Value = id;
            electionId.DbType = DbType.Int32;
            comm.Parameters.Add(electionId);

            DbParameter Seat = comm.CreateParameter();
            Seat.ParameterName = "@seat";
            Seat.Value = seat;
            Seat.DbType = DbType.String;
            Seat.Size = 50;
            comm.Parameters.Add(Seat);


            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable PartyVSSeatsWinByElectionType(int id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Chart_PartyVSSeatsWinByElectionType";

            DbParameter electionId = comm.CreateParameter();
            electionId.ParameterName = "@id";
            electionId.Value = id;
            electionId.DbType = DbType.Int32;
            comm.Parameters.Add(electionId);
            
            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable VoterVSDistrict()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Chart_VoterVSDistrict";

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetSeatType(int id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_SeatType";

            DbParameter electionId = comm.CreateParameter();
            electionId.ParameterName = "@id";
            electionId.Value = id;
            electionId.DbType = DbType.Int32;
            comm.Parameters.Add(electionId);

            return GenericDataAccess.ExecuteReader(comm);
        }
    }
}