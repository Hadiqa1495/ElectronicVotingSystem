﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public class ElectionModel
    {
        public DataTable GetElectionType()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_ElectionType";

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetPrevious10ElectionByElectionType(int etId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Election_ByElectionTypeIdPrevious10";

            DbParameter ElectionTypeId = comm.CreateParameter();
            ElectionTypeId.ParameterName = "@etId";
            ElectionTypeId.Value = etId;
            ElectionTypeId.DbType = DbType.Int32;
            comm.Parameters.Add(ElectionTypeId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public bool SaveElection(int electionTypeId, int startingYear, int endingYear, DateTime electionDay)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_InsertInto_Election";
            // execute the stored procedure and return the results
            DbParameter ElectionTypeId = comm.CreateParameter();
            ElectionTypeId.ParameterName = "@etId";
            ElectionTypeId.Value = electionTypeId;
            ElectionTypeId.DbType = DbType.Int32;
            comm.Parameters.Add(ElectionTypeId);

            DbParameter StartingYear = comm.CreateParameter();
            StartingYear.ParameterName = "@election_StartingYear";
            StartingYear.Value = startingYear;
            StartingYear.DbType = DbType.Int32;
            comm.Parameters.Add(StartingYear);

            DbParameter EndingYear = comm.CreateParameter();
            EndingYear.ParameterName = "@election_EndingYear";
            EndingYear.Value = endingYear;
            EndingYear.DbType = DbType.Int32;
            comm.Parameters.Add(EndingYear);

            DbParameter ElectionDay = comm.CreateParameter();
            ElectionDay.ParameterName = "@election_Day";
            ElectionDay.Value = electionDay;
            ElectionDay.DbType = DbType.Date;
            comm.Parameters.Add(ElectionDay);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public DataTable GetElection(int electionTypeId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Election_ByElectionTypeId";

            DbParameter ElectionTypeId = comm.CreateParameter();
            ElectionTypeId.ParameterName = "@etId";
            ElectionTypeId.Value = electionTypeId;
            ElectionTypeId.DbType = DbType.Int32;
            comm.Parameters.Add(ElectionTypeId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetElectionFiltered(int electionTypeId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Election_Filtered";

            DbParameter ElectionTypeId = comm.CreateParameter();
            ElectionTypeId.ParameterName = "@etId";
            ElectionTypeId.Value = electionTypeId;
            ElectionTypeId.DbType = DbType.Int32;
            comm.Parameters.Add(ElectionTypeId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetLatestElection()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Get_LatestElection";

            return GenericDataAccess.ExecuteReader(comm);
        }

        public bool DeleteElection(int Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_DeleteFrom_Election";
            // execute the stored procedure and return the results

            DbParameter ElectionId = comm.CreateParameter();
            ElectionId.ParameterName = "@original_election_Id";
            ElectionId.Value = Id;
            ElectionId.DbType = DbType.Int32;
            comm.Parameters.Add(ElectionId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public bool UpdateElection(int electionId , int electionTypeId, string startingYear, string endingYear, DateTime electionDay)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_UpdateSet_Election";
            // execute the stored procedure and return the results
            DbParameter ElectionId = comm.CreateParameter();
            ElectionId.ParameterName = "@original_election_Id";
            ElectionId.Value = electionId;
            ElectionId.DbType = DbType.Int32;
            ElectionId.Size = 50;
            comm.Parameters.Add(ElectionId);

            DbParameter ElectionTypeId = comm.CreateParameter();
            ElectionTypeId.ParameterName = "@election_Type";
            ElectionTypeId.Value = electionTypeId;
            ElectionTypeId.DbType = DbType.Int32;
            ElectionTypeId.Size = 50;
            comm.Parameters.Add(ElectionTypeId);

            DbParameter StartingYear = comm.CreateParameter();
            StartingYear.ParameterName = "@election_StartingYear";
            StartingYear.Value = startingYear;
            StartingYear.DbType = DbType.String;
            StartingYear.Size = 50;
            comm.Parameters.Add(StartingYear);

            DbParameter EndingYear = comm.CreateParameter();
            EndingYear.ParameterName = "@election_EndingYear";
            EndingYear.Value = endingYear;
            EndingYear.DbType = DbType.String;
            EndingYear.Size = 50;
            comm.Parameters.Add(EndingYear);

            DbParameter ElectionDay = comm.CreateParameter();
            ElectionDay.ParameterName = "@election_Day";
            ElectionDay.Value = electionDay;
            ElectionDay.DbType = DbType.DateTime;
            ElectionDay.Size = 50;
            comm.Parameters.Add(ElectionDay);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public DataTable GetElectionDuration()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_ElectionDuration";

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetElectionByElectionDuration(int etId, int startingYear, int endingYear, DateTime eday)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Election_ByElectionDuration";
            // execute the stored procedure and return the results

            DbParameter EtypeId = comm.CreateParameter();
            EtypeId.ParameterName = "@etId";
            EtypeId.Value = etId;
            EtypeId.DbType = DbType.Int32;
            comm.Parameters.Add(EtypeId);

            DbParameter StartingYear = comm.CreateParameter();
            StartingYear.ParameterName = "@election_StartingYear";
            StartingYear.Value = startingYear;
            StartingYear.DbType = DbType.String;
            StartingYear.Size = 50;
            comm.Parameters.Add(StartingYear);

            DbParameter EndingYear = comm.CreateParameter();
            EndingYear.ParameterName = "@election_EndingYear";
            EndingYear.Value = endingYear;
            EndingYear.DbType = DbType.String;
            EndingYear.Size = 50;
            comm.Parameters.Add(EndingYear);

            DbParameter EDay = comm.CreateParameter();
            EDay.ParameterName = "@election_Day";
            EDay.Value = eday;
            EDay.DbType = DbType.Date;
            EDay.Size = 50;
            comm.Parameters.Add(EDay);

            return GenericDataAccess.ExecuteReader(comm);
        }
        
        public DataTable GetElectionByElectionId(int eId, int startingYear, int endingYear, DateTime eday)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Election_ByElectionId";
            // execute the stored procedure and return the results

            DbParameter ElectionId = comm.CreateParameter();
            ElectionId.ParameterName = "@eId";
            ElectionId.Value = eId;
            ElectionId.DbType = DbType.Int32;
            comm.Parameters.Add(ElectionId);

            DbParameter StartingYear = comm.CreateParameter();
            StartingYear.ParameterName = "@election_StartingYear";
            StartingYear.Value = startingYear;
            StartingYear.DbType = DbType.String;
            StartingYear.Size = 50;
            comm.Parameters.Add(StartingYear);

            DbParameter EndingYear = comm.CreateParameter();
            EndingYear.ParameterName = "@election_EndingYear";
            EndingYear.Value = endingYear;
            EndingYear.DbType = DbType.String;
            EndingYear.Size = 50;
            comm.Parameters.Add(EndingYear);

            DbParameter EDay = comm.CreateParameter();
            EDay.ParameterName = "@election_Day";
            EDay.Value = eday;
            EDay.DbType = DbType.Date;
            EDay.Size = 50;
            comm.Parameters.Add(EDay);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetElectionReport(string search)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Report_Election";

            DbParameter Search = comm.CreateParameter();
            Search.ParameterName = "@search";
            Search.Value = search;
            Search.DbType = DbType.String;
            Search.Size = 50;
            comm.Parameters.Add(Search);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetElection()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_Report_ElectionGeneral";

            return GenericDataAccess.ExecuteReader(comm);
        }
    }
}