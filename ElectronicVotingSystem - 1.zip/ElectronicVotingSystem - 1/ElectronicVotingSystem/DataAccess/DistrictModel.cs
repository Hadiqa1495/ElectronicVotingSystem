﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace ElectronicVotingSystem.DataAccess
{
    public class DistrictModel
    {
        public bool SaveDistrict(string Name, int adminId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_InsertInto_District";
            // execute the stored procedure and return the results

            DbParameter districtName = comm.CreateParameter();
            districtName.ParameterName = "@district_Name";
            districtName.Value = Name;
            districtName.DbType = DbType.String;
            districtName.Size = 50;
            comm.Parameters.Add(districtName);

            DbParameter adminUnitId = comm.CreateParameter();
            adminUnitId.ParameterName = "@district_AdministrativeUnitId";
            adminUnitId.Value = adminId;
            adminUnitId.DbType = DbType.Int32;
            comm.Parameters.Add(adminUnitId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public bool UpdateDistrict(int Id, string Name, int adminId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_UpdateSet_District";
            // execute the stored procedure and return the results

            DbParameter districtId = comm.CreateParameter();
            districtId.ParameterName = "@district_Id";
            districtId.Value = Id;
            districtId.DbType = DbType.Int32;
            comm.Parameters.Add(districtId);

            DbParameter districtName = comm.CreateParameter();
            districtName.ParameterName = "@district_Name";
            districtName.Value = Name;
            districtName.DbType = DbType.String;
            districtName.Size = 50;
            comm.Parameters.Add(districtName);

            DbParameter adminUnitId = comm.CreateParameter();
            adminUnitId.ParameterName = "@district_AdministrativeUnitId";
            adminUnitId.Value = adminId;
            adminUnitId.DbType = DbType.Int32;
            comm.Parameters.Add(adminUnitId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);

        }

        public DataTable GetDistrictByName(string Name)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_District_ByDistrictName";

            DbParameter districtName = comm.CreateParameter();
            districtName.ParameterName = "@district_Name";
            districtName.Value = Name;
            districtName.DbType = DbType.String;
            districtName.Size = 50;
            comm.Parameters.Add(districtName);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetDistrictByNameDistrictId(int Id, string Name)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_District_ByIdName";
            // execute the stored procedure and return the results

            DbParameter districtId = comm.CreateParameter();
            districtId.ParameterName = "@district_Id";
            districtId.Value = Id;
            districtId.DbType = DbType.Int32;
            comm.Parameters.Add(districtId);

            DbParameter districtName = comm.CreateParameter();
            districtName.ParameterName = "@district_Name";
            districtName.Value = Name;
            districtName.DbType = DbType.String;
            districtName.Size = 50;
            comm.Parameters.Add(districtName);
            
            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetDistrictByAdminUnit(int adminUnitId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_District_ByAdminUnit";

            DbParameter adminId = comm.CreateParameter();
            adminId.ParameterName = "@adminUnitId";
            adminId.Value = adminUnitId;
            adminId.DbType = DbType.Int32;
            comm.Parameters.Add(adminId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetDistrictByElectionId(int electionId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_District_ByElectionId";

            DbParameter elecId = comm.CreateParameter();
            elecId.ParameterName = "@electionId";
            elecId.Value = electionId;
            elecId.DbType = DbType.Int32;
            comm.Parameters.Add(elecId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public bool DeleteDistrict(int Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_DeleteFrom_District";
            // execute the stored procedure and return the results

            DbParameter districtId = comm.CreateParameter();
            districtId.ParameterName = "@district_Id";
            districtId.Value = Id;
            districtId.DbType = DbType.Int32;
            comm.Parameters.Add(districtId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }
    }
}