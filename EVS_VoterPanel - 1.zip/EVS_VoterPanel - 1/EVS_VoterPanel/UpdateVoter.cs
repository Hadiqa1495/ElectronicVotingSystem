﻿using EVS_VoterPanel.DataAccess;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using EVS_VoterPanel.Helper;
using DPUruNet;

namespace EVS_VoterPanel
{
    public partial class UpdateVoter : Master
    {
        private Validation objValidate = new Validation();
        private VoterModel objVoter = new VoterModel();
        LocationModel objLoc = new LocationModel();

        private DataTable tblVoter = null;

        public UpdateVoter()
        {
            InitializeComponent();
        }

        private void UpdateVoter_Load(object sender, EventArgs e)
        {
            if (CurrentReader.Description == null)
            {
                this.Close();
            }
            else
            {
                button1.Visible = false;
                button3.Visible = false;
                button4.Visible = false;
                BindAdminUnit();
                BindDistrict();
                BindTehsil();
                BindMauza();
                BindBlock();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                if (tblVoter.Rows.Count > 0)
                {
                    string gender = null; string religion = null;
                    foreach (Control control in this.gboxGender.Controls)
                    {
                        RadioButton radio = control as RadioButton;
                        if (radio.Checked)
                        {
                            gender = radio.Text;
                        }
                    }
                    foreach (Control control in this.gboxReligion.Controls)
                    {
                        RadioButton radio = control as RadioButton;
                        if (radio.Checked)
                        {
                            religion = radio.Text;
                        }
                    }

                    string fingerprint; int key = 0;
                    if (fmds.Count > 0)
                    {
                        Fmd value = null;
                        foreach (var fmd in fmds)
                        {
                            key = fmd.Key;
                            value = fmd.Value;
                        }
                        fingerprint = Fmd.SerializeXml(value);
                    }
                    else
                    {
                        fingerprint = tblVoter.Rows[0]["voter_ThumbImpression"].ToString();
                    }
                    string firstName = txtFirstName.Text;
                    string lastname = txtLastName.Text;
                    DateTime dob = DateTime.Parse(txtDob.Text);
                    string cnic = txtCnic.Text;
                    int house = int.Parse(txtHouse.Text);
                    string street = txtStreet.Text;
                    string mobile = txtMobile.Text;

                    string imgName; string imgContentType; byte[] imgVoter;
                    if (openFileDialog1.FileName != "openFileDialog1")
                    {
                        FileStream fs = new FileStream(openFileDialog1.FileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                        imgVoter = new byte[fs.Length];
                        fs.Read(imgVoter, 0, Convert.ToInt32(fs.Length));
                        fs.Close();
                        imgName = Path.GetFileName(openFileDialog1.FileName);
                        imgContentType = GetContentType(imgName);
                    }
                    else
                    {
                        imgVoter = (byte[])tblVoter.Rows[0]["voter_ImageContent"];
                        imgName = tblVoter.Rows[0]["voter_ImageName"].ToString();
                        imgContentType = tblVoter.Rows[0]["voter_ImageType"].ToString();
                    }

                    int blockId = int.Parse(cboxBlock.SelectedValue.ToString());
                    int voterId = int.Parse(tblVoter.Rows[0]["voter_Id"].ToString());
                    bool success = objVoter.UpdateVoter(voterId, firstName, lastname, dob, gender, religion, house, street, mobile, imgName, imgContentType, imgVoter, blockId, fingerprint);
                    if (success)
                    {
                        MessageBox.Show("Voter updated successfully!");

                        UpdateVoter form = new UpdateVoter();
                        form.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Sorry failed to update voter!");
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string extension = Path.GetExtension(openFileDialog1.FileName);
                string file = Path.GetFileName(openFileDialog1.FileName);
                string contentType = GetContentType(file);
                pboxVoter.ImageLocation = openFileDialog1.FileName;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (enrollmentControl == null)
            {
                enrollmentControl = new EnrollmentControl();
                enrollmentControl._sender = this;
            }

            enrollmentControl.ShowDialog();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string cnic = txtCnic.Text;
            tblVoter = objVoter.GetVoterByCnic(cnic);
            if (tblVoter.Rows.Count > 0)
            {
                cboxAdminUnit.SelectedValue = tblVoter.Rows[0]["administrativeUnit_Id"].ToString();
                cboxDistrict.SelectedValue = tblVoter.Rows[0]["district_Id"].ToString();
                cboxTehsil.SelectedValue = tblVoter.Rows[0]["tehsil_Id"].ToString();
                cboxMauza.SelectedValue = tblVoter.Rows[0]["mauza_Id"].ToString();
                cboxBlock.SelectedValue = tblVoter.Rows[0]["voter_BlockId"].ToString();
                foreach (Control control in this.gboxGender.Controls)
                {
                    RadioButton radio = control as RadioButton;
                    if (radio.Text == tblVoter.Rows[0]["voter_Gender"].ToString())
                    {
                        radio.Checked = true;
                    }
                    else
                    {
                        radio.Checked = false;
                    }
                }
                foreach (Control control in this.gboxReligion.Controls)
                {
                    RadioButton radio = control as RadioButton;
                    if (radio.Text == tblVoter.Rows[0]["voter_Religion"].ToString())
                    {
                        radio.Checked = true;
                    }
                    else
                    {
                        radio.Checked = false;
                    }
                }
                txtFirstName.Text = tblVoter.Rows[0]["voter_FirstName"].ToString();
                txtLastName.Text = tblVoter.Rows[0]["voter_LastName"].ToString();
                txtDob.Text = ((DateTime)tblVoter.Rows[0]["voter_DateOfBirth"]).ToShortDateString();
                txtMobile.Text = tblVoter.Rows[0]["voter_Mobile"].ToString();
                txtHouse.Text = tblVoter.Rows[0]["voter_HouseNo"].ToString();
                txtStreet.Text = tblVoter.Rows[0]["voter_Street"].ToString();

                byte[] imgData = new byte[0];
                imgData = (byte[])tblVoter.Rows[0]["voter_ImageContent"];
                MemoryStream imgStream = new MemoryStream(imgData);
                pboxVoter.Image = Image.FromStream(imgStream);
                pboxVoter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;

                button1.Visible = true;
                button3.Visible = true;
                button4.Visible = true;
            }
            else
            {
                MessageBox.Show("No match found!");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (tblVoter.Rows.Count > 0)
            {
                int voterId = int.Parse(tblVoter.Rows[0]["voter_Id"].ToString());
                bool success = objVoter.DeleteVoter(voterId);
                if (success)
                {
                    MessageBox.Show("Voter deleted successfully!");
                }
                else
                {
                    MessageBox.Show("Sorry failed to delete voter!");
                }
            }
        }

        private void cboxAdminUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindDistrict();
            BindTehsil();
            BindMauza();
            BindBlock();
        }

        private void cboxDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindTehsil();
            BindMauza();
            BindBlock();
        }

        private void cboxTehsil_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindMauza();
            BindBlock();
        }

        private void cboxMauza_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindBlock();
        }

        private void cboxAdminUnit_Validating(object sender, CancelEventArgs e)
        {
            if (cboxAdminUnit.SelectedValue.ToString() == "0")
            {
                e.Cancel = true;
                errAdminUnit.SetError(cboxAdminUnit, "Invalid Selected Value!");
            }
            else
            {
                e.Cancel = false;
                errAdminUnit.SetError(cboxAdminUnit, "");
            }
        }

        private void cboxDistrict_Validating(object sender, CancelEventArgs e)
        {
            if (cboxDistrict.SelectedValue.ToString() == "0")
            {
                e.Cancel = true;
                errDistrict.SetError(cboxDistrict, "Invalid Selected Value!");
            }
            else
            {
                e.Cancel = false;
                errDistrict.SetError(cboxDistrict, "");
            }
        }

        private void cboxTehsil_Validating(object sender, CancelEventArgs e)
        {
            if (cboxTehsil.SelectedValue.ToString() == "0")
            {
                e.Cancel = true;
                errTehsil.SetError(cboxTehsil, "Invalid Selected Value!");
            }
            else
            {
                e.Cancel = false;
                errTehsil.SetError(cboxTehsil, "");
            }
        }

        private void cboxMauza_Validating(object sender, CancelEventArgs e)
        {
            if (cboxMauza.SelectedValue.ToString() == "0")
            {
                e.Cancel = true;
                errMauza.SetError(cboxMauza, "Invalid Selected Value!");
            }
            else
            {
                e.Cancel = false;
                errMauza.SetError(cboxMauza, "");
            }
        }

        private void cboxBlock_Validating(object sender, CancelEventArgs e)
        {
            if (cboxBlock.SelectedValue.ToString() == "0")
            {
                e.Cancel = true;
                errBlock.SetError(cboxBlock, "Invalid Selected Value!");
            }
            else
            {
                e.Cancel = false;
                errBlock.SetError(cboxBlock, "");
            }
        }

        private void txtFirstName_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFirstName.Text))
            {
                e.Cancel = true;
                errFirstName.SetError(txtFirstName, "First Name should not be left blank!");
            }
            else if (!objValidate.ValidateText(txtFirstName.Text))
            {
                e.Cancel = true;
                errFirstName.SetError(txtFirstName, "Enter alphabets only!");
            }
            else
            {
                e.Cancel = false;
                errFirstName.SetError(txtFirstName, "");
            }
        }

        private void txtLastName_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtLastName.Text))
            {
                e.Cancel = true;
                errLastName.SetError(txtLastName, "Last Name should not be left blank!");
            }
            else if (!objValidate.ValidateText(txtLastName.Text))
            {
                e.Cancel = true;
                errLastName.SetError(txtLastName, "Enter alphabets only!");
            }
            else
            {
                e.Cancel = false;
                errLastName.SetError(txtLastName, "");
            }
        }

        private void txtCnic_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCnic.Text))
            {
                e.Cancel = true;
                errCnic.SetError(txtCnic, "Cnic should not be left blank!");
            }
            else if (!objValidate.ValidateNumeric(txtCnic.Text))
            {
                e.Cancel = true;
                errCnic.SetError(txtCnic, "Enter numbers only!");
            }
            else
            {
                e.Cancel = false;
                errCnic.SetError(txtCnic, "");
            }
        }

        private void txtMobile_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMobile.Text))
            {
                e.Cancel = true;
                errMobile.SetError(txtMobile, "Mobile No should not be left blank!");
            }
            else if (!objValidate.ValidateNumeric(txtMobile.Text))
            {
                e.Cancel = true;
                errMobile.SetError(txtMobile, "Enter numbers only!");
            }
            else
            {
                e.Cancel = false;
                errMobile.SetError(txtMobile, "");
            }
        }

        private void txtStreet_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtStreet.Text))
            {
                e.Cancel = true;
                errStreet.SetError(txtStreet, "Street No should not be left blank!");
            }
            else if (!objValidate.ValidateAlphaNumeric(txtStreet.Text))
            {
                e.Cancel = true;
                errStreet.SetError(txtStreet, "Enter alphabets and only!");
            }
            else
            {
                e.Cancel = false;
                errStreet.SetError(txtStreet, "");
            }
        }

        private void txtHouse_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtHouse.Text))
            {
                e.Cancel = true;
                errHouse.SetError(txtHouse, "House No should not be left blank!");
            }
            else if (!objValidate.ValidateNumeric(txtHouse.Text))
            {
                e.Cancel = true;
                errHouse.SetError(txtHouse, "Enter numbers only!");
            }
            else
            {
                e.Cancel = false;
                errHouse.SetError(txtHouse, "");
            }
        }

        private void txtDob_Validating(object sender, CancelEventArgs e)
        {
            if (!calendarDob.Focused)
            {
                if (string.IsNullOrWhiteSpace(txtDob.Text))
                {
                    e.Cancel = true;
                    errDob.SetError(txtDob, "Date of birth should not be left blank!");
                }
                else if (!objValidate.ValidateDate(txtDob.Text))
                {
                    e.Cancel = true;
                    errDob.SetError(txtDob, "Invalid date format!");
                }
                else if ((DateTime.Now.Year - DateTime.Parse(txtDob.Text).Year) > 100 || DateTime.Parse(txtDob.Text) > DateTime.Now)
                {
                    e.Cancel = true;
                    errDob.SetError(txtDob, "Enter valid date range!");
                }
                else if (objValidate.calculateAge(txtDob.Text) < 18)
                {
                    e.Cancel = true;
                    errDob.SetError(txtDob, "Your age must be greater than 18!");
                }
                else
                {
                    e.Cancel = false;
                    errDob.SetError(txtDob, "");
                }
            }
        }

        private void txtDob_Enter(object sender, EventArgs e)
        {
            calendarDob.Visible = true;
            calendarDob.MaxDate = DateTime.Now;
            calendarDob.MinDate = Convert.ToDateTime("1/1/" + (DateTime.Now.Year - 100));
        }

        private void txtDob_Leave(object sender, EventArgs e)
        {
            if (!calendarDob.Focused)
            {
                calendarDob.Visible = false;
            }
        }

        private void calendarDob_DateSelected(object sender, DateRangeEventArgs e)
        {
            var calendar = sender as MonthCalendar;
            txtDob.Text = calendar.SelectionStart.ToShortDateString();
            calendar.Visible = false;
        }

        private void calendarDob_Validating(object sender, CancelEventArgs e)
        {
            if (calendarDob.Focused)
            {
                if (string.IsNullOrWhiteSpace(txtDob.Text))
                {
                    e.Cancel = true;
                    errDob.SetError(txtDob, "Date of birth should not be left blank!");
                }
                else if (!objValidate.ValidateDate(txtDob.Text))
                {
                    e.Cancel = true;
                    errDob.SetError(txtDob, "Invalid date format!");
                }
                else if ((DateTime.Now.Year - DateTime.Parse(txtDob.Text).Year) < 100 || DateTime.Parse(txtDob.Text) > DateTime.Now)
                {
                    e.Cancel = true;
                    errDob.SetError(txtDob, "Enter valid date range!");
                }
                else if (objValidate.calculateAge(txtDob.Text) < 18)
                {
                    e.Cancel = true;
                    errDob.SetError(txtDob, "Your age must be greater than 18!");
                }
                else
                {
                    e.Cancel = false;
                    errDob.SetError(txtDob, "");
                }
            }
        }

        private void btnSearch_Validating(object sender, CancelEventArgs e)
        {
            if (tblVoter == null)
            {
                e.Cancel = true;
                errSearch.SetError(btnSearch, "Please search voter for update first!");
            }
            else
            {
                e.Cancel = false;
                errSearch.SetError(btnSearch, "");
            }
        }

        // get content type
        private string GetContentType(string filepath)
        {
            var contentType = "image/jpeg";
            var extension = Path.GetExtension(filepath);

            RegistryKey registryKey = Registry.ClassesRoot.OpenSubKey(extension);

            if (registryKey != null && registryKey.GetValue("Content Type") != null)
                contentType = registryKey.GetValue("Content Type").ToString();

            return contentType;
        }

        private void BindAdminUnit()
        {
            try
            {
                DataTable tblAdminUnit = objLoc.GetAdminUnit();
                if (tblAdminUnit.Rows.Count > 0)
                {
                    cboxAdminUnit.DataSource = tblAdminUnit;
                    cboxAdminUnit.DisplayMember = "administrativeUnit_Name";
                    cboxAdminUnit.ValueMember = "administrativeUnit_Id";
                }
                else
                {
                    Dictionary<int, string> item = new Dictionary<int, string>();
                    item.Add(0, "No results found!");
                    cboxAdminUnit.DataSource = new BindingSource(item, null);
                    cboxAdminUnit.DisplayMember = "Value";
                    cboxAdminUnit.ValueMember = "Key";
                    cboxAdminUnit.SelectedIndex = 0;
                }
            }
            catch
            {
                Dictionary<int, string> item = new Dictionary<int, string>();
                item.Add(0, "No results found!");
                cboxAdminUnit.DataSource = new BindingSource(item, null);
                cboxAdminUnit.DisplayMember = "Value";
                cboxAdminUnit.ValueMember = "Key";
                cboxAdminUnit.SelectedIndex = 0;
            }
        }

        private void BindDistrict()
        {
            try
            {
                int unitId = int.Parse(cboxAdminUnit.SelectedValue.ToString());
                cboxDistrict.DataSource = null;
                DataTable tblDistrict = objLoc.GetDistrictByAdminUnit(unitId);
                if (tblDistrict.Rows.Count > 0)
                {
                    cboxDistrict.DataSource = tblDistrict;
                    cboxDistrict.DisplayMember = "district_Name";
                    cboxDistrict.ValueMember = "district_Id";
                }
                else
                {
                    Dictionary<int, string> item = new Dictionary<int, string>();
                    item.Add(0, "No results found!");
                    cboxDistrict.DataSource = new BindingSource(item, null);
                    cboxDistrict.DisplayMember = "Value";
                    cboxDistrict.ValueMember = "Key";
                    cboxDistrict.SelectedIndex = 0;
                }
            }
            catch
            {
                Dictionary<int, string> item = new Dictionary<int, string>();
                item.Add(0, "No results found!");
                cboxDistrict.DataSource = new BindingSource(item, null);
                cboxDistrict.DisplayMember = "Value";
                cboxDistrict.ValueMember = "Key";
                cboxDistrict.SelectedIndex = 0;
            }
        }

        private void BindTehsil()
        {
            try
            {
                int distId = int.Parse(cboxDistrict.SelectedValue.ToString());
                cboxTehsil.DataSource = null;
                DataTable tblTehsil = objLoc.GetTehsilByDistrictId(distId);
                if (tblTehsil.Rows.Count > 0)
                {
                    cboxTehsil.DataSource = tblTehsil;
                    cboxTehsil.DisplayMember = "tehsil_Name";
                    cboxTehsil.ValueMember = "tehsil_Id";
                }
                else
                {
                    Dictionary<int, string> item = new Dictionary<int, string>();
                    item.Add(0, "No results found!");
                    cboxTehsil.DataSource = new BindingSource(item, null);
                    cboxTehsil.DisplayMember = "Value";
                    cboxTehsil.ValueMember = "Key";
                    cboxTehsil.SelectedIndex = 0;
                }
            }
            catch
            {
                Dictionary<int, string> item = new Dictionary<int, string>();
                item.Add(0, "No results found!");
                cboxTehsil.DataSource = new BindingSource(item, null);
                cboxTehsil.DisplayMember = "Value";
                cboxTehsil.ValueMember = "Key";
                cboxTehsil.SelectedIndex = 0;
            }
        }

        private void BindMauza()
        {
            try
            {
                int tehsilId = int.Parse(cboxTehsil.SelectedValue.ToString());
                cboxMauza.DataSource = null;
                DataTable tblMauza = objLoc.GetMauzaByTehsilId(tehsilId);
                if (tblMauza.Rows.Count > 0)
                {
                    cboxMauza.DataSource = tblMauza;
                    cboxMauza.DisplayMember = "mauza_Name";
                    cboxMauza.ValueMember = "mauza_Id";
                }
                else
                {
                    Dictionary<int, string> item = new Dictionary<int, string>();
                    item.Add(0, "No results found!");
                    cboxMauza.DataSource = new BindingSource(item, null);
                    cboxMauza.DisplayMember = "Value";
                    cboxMauza.ValueMember = "Key";
                    cboxMauza.SelectedIndex = 0;
                }
            }
            catch
            {
                Dictionary<int, string> item = new Dictionary<int, string>();
                item.Add(0, "No results found!");
                cboxMauza.DataSource = new BindingSource(item, null);
                cboxMauza.DisplayMember = "Value";
                cboxMauza.ValueMember = "Key";
                cboxMauza.SelectedIndex = 0;
            }
        }

        private void BindBlock()
        {
            try
            {
                int mauzaId = int.Parse(cboxMauza.SelectedValue.ToString());
                cboxBlock.DataSource = null;
                DataTable tblBlock = objLoc.GetBlockByMauzaId(mauzaId);
                if (tblBlock.Rows.Count > 0)
                {
                    cboxBlock.DataSource = tblBlock;
                    cboxBlock.DisplayMember = "block_Number";
                    cboxBlock.ValueMember = "block_Id";
                }
                else
                {
                    Dictionary<int, string> item = new Dictionary<int, string>();
                    item.Add(0, "No results found!");
                    cboxBlock.DataSource = new BindingSource(item, null);
                    cboxBlock.DisplayMember = "Value";
                    cboxBlock.ValueMember = "Key";
                    cboxBlock.SelectedIndex = 0;
                }
            }
            catch
            {
                Dictionary<int, string> item = new Dictionary<int, string>();
                item.Add(0, "No results found!");
                cboxBlock.DataSource = new BindingSource(item, null);
                cboxBlock.DisplayMember = "Value";
                cboxBlock.ValueMember = "Key";
                cboxBlock.SelectedIndex = 0;
            }
        }

        private void button3_Validating(object sender, CancelEventArgs e)
        {
            Fmd currFingerprint = null;
            foreach (var fmd in fmds)
            {
                currFingerprint = fmd.Value;
            }
            if (fmds.Count > 0)
            {
                if (validateThumbImpression(currFingerprint))
                {
                    e.Cancel = true;
                    errThumb.SetError(button3, "Finger print already exists!");
                }
            }
            else
            {
                e.Cancel = false;
                errThumb.SetError(button3, "");
            }
        }

        private const int DPFJ_PROBABILITY_ONE = 0x7fffffff;
        private bool validateThumbImpression(Fmd currFinger)
        {
            DataTable tblVoter = objVoter.GetVoters();
            int count = tblVoter.Rows.Count;
            Fmd[] allVoterFmds = new Fmd[count];
            if (tblVoter.Rows.Count > 0)
            {
                int index = 0;
                foreach (DataRow dr in tblVoter.Rows)
                {
                    Fmd anyFmd = Fmd.DeserializeXml(dr["voter_ThumbImpression"].ToString());
                    allVoterFmds[index] = anyFmd;
                    index++;
                }
            }
            // See the SDK documentation for an explanation on threshold scores.
            int thresholdScore = DPFJ_PROBABILITY_ONE * 1 / 100000;

            IdentifyResult identifyResult = Comparison.Identify(currFinger, 0, allVoterFmds, thresholdScore, count);
            if (identifyResult.Indexes.Length > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void UpdateVoter_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }

    }
}
