﻿using EVS_VoterPanel.DataAccess;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using EVS_VoterPanel.Helper;
using DPUruNet;

namespace EVS_VoterPanel
{
    public partial class RegisterVoter : Master
    {
        private Validation objValidate = new Validation();
        private VoterModel objVoter = new VoterModel();
        LocationModel objLoc = new LocationModel();

        public RegisterVoter()
        {
            InitializeComponent();
        }

        private void RegisterVoter_Load(object sender, EventArgs e)
        {
            if (CurrentReader.Description == null)
            {
                this.Close();
            }
            else
            {
                BindAdminUnit();
                BindDistrict();
                BindTehsil();
                BindMauza();
                BindBlock();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                string gender = null;
                string religion = null;
                foreach (Control control in this.gboxGender.Controls)
                {
                    RadioButton radio = control as RadioButton;
                    if (radio.Checked)
                    {
                        gender = radio.Text;
                    }
                }
                foreach (Control control in this.gboxReligion.Controls)
                {
                    RadioButton radio = control as RadioButton;
                    if (radio.Checked)
                    {
                        religion = radio.Text;
                    }
                }
                int key = 0;
                Fmd value = null;
                foreach (var fmd in fmds)
                {
                    key = fmd.Key;
                    value = fmd.Value;
                }
                VoterModel objVoter = new VoterModel();
                string fingerprint = Fmd.SerializeXml(value);
                string firstName = txtFirstName.Text;
                string lastname = txtLastName.Text;
                DateTime dob = DateTime.Parse(txtDob.Text);
                string cnic = txtCnic.Text;
                int house = int.Parse(txtHouse.Text);
                string street = txtStreet.Text;
                string mobile = txtMobile.Text;

                FileStream fs = new FileStream(openFileDialog1.FileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                byte[] imgVoter = new byte[fs.Length];
                fs.Read(imgVoter, 0, Convert.ToInt32(fs.Length));
                fs.Close();

                string imgName = Path.GetFileName(openFileDialog1.FileName);
                string imgContentType = GetContentType(imgName);
                int blockId = int.Parse(cboxBlock.SelectedValue.ToString());
                bool success = objVoter.SaveVoter(firstName, lastname, dob, cnic, gender, religion, house, street, mobile, imgName, imgContentType, imgVoter, blockId, fingerprint);
                if (success)
                {
                    MessageBox.Show("Voter saved successfully!");

                    RegisterVoter form = new RegisterVoter();
                    form.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Sorry failed to register voter!");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string extension = Path.GetExtension(openFileDialog1.FileName);
                string file = Path.GetFileName(openFileDialog1.FileName);
                string contentType = GetContentType(file);
                pboxVoter.ImageLocation = openFileDialog1.FileName;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (enrollmentControl == null)
            {
                enrollmentControl = new EnrollmentControl();
                enrollmentControl._sender = this;
            }

            enrollmentControl.ShowDialog();
        }

        private void cboxAdminUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindDistrict();
            BindTehsil();
            BindMauza();
            BindBlock();
        }

        private void cboxDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindTehsil();
            BindMauza();
            BindBlock();
        }

        private void cboxTehsil_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindMauza();
            BindBlock();
        }

        private void cboxMauza_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindBlock();
        }

        private void cboxAdminUnit_Validating(object sender, CancelEventArgs e)
        {
            if (cboxAdminUnit.SelectedValue.ToString() == "0")
            {
                e.Cancel = true;
                errAdminUnit.SetError(cboxAdminUnit, "Invalid Selected Value!");
            }
            else
            {
                e.Cancel = false;
                errAdminUnit.SetError(cboxAdminUnit, "");
            }
        }

        private void cboxDistrict_Validating(object sender, CancelEventArgs e)
        {
            if (cboxDistrict.SelectedValue.ToString() == "0")
            {
                e.Cancel = true;
                errDistrict.SetError(cboxDistrict, "Invalid Selected Value!");
            }
            else
            {
                e.Cancel = false;
                errDistrict.SetError(cboxDistrict, "");
            }
        }

        private void cboxTehsil_Validating(object sender, CancelEventArgs e)
        {
            if (cboxTehsil.SelectedValue.ToString() == "0")
            {
                e.Cancel = true;
                errTehsil.SetError(cboxTehsil, "Invalid Selected Value!");
            }
            else
            {
                e.Cancel = false;
                errTehsil.SetError(cboxTehsil, "");
            }
        }

        private void cboxMauza_Validating(object sender, CancelEventArgs e)
        {
            if (cboxMauza.SelectedValue.ToString() == "0")
            {
                e.Cancel = true;
                errMauza.SetError(cboxMauza, "Invalid Selected Value!");
            }
            else
            {
                e.Cancel = false;
                errMauza.SetError(cboxMauza, "");
            }
        }

        private void cboxBlock_Validating(object sender, CancelEventArgs e)
        {
            if (cboxBlock.SelectedValue.ToString() == "0")
            {
                e.Cancel = true;
                errBlock.SetError(cboxBlock, "Invalid Selected Value!");
            }
            else
            {
                e.Cancel = false;
                errBlock.SetError(cboxBlock, "");
            }
        }

        private void txtFirstName_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFirstName.Text))
            {
                e.Cancel = true;
                errFirstName.SetError(txtFirstName, "First Name should not be left blank!");
            }
            else if (!objValidate.ValidateText(txtFirstName.Text))
            {
                e.Cancel = true;
                errFirstName.SetError(txtFirstName, "Enter alphabets only!");
            }
            else
            {
                e.Cancel = false;
                errFirstName.SetError(txtFirstName, "");
            }
        }

        private void txtLastName_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtLastName.Text))
            {
                e.Cancel = true;
                errLastName.SetError(txtLastName, "Last Name should not be left blank!");
            }
            else if (!objValidate.ValidateText(txtLastName.Text))
            {
                e.Cancel = true;
                errLastName.SetError(txtLastName, "Enter alphabets only!");
            }
            else
            {
                e.Cancel = false;
                errLastName.SetError(txtLastName, "");
            }
        }

        private void txtCnic_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCnic.Text))
            {
                e.Cancel = true;
                errCnic.SetError(txtCnic, "Cnic should not be left blank!");
            }
            else if (!objValidate.ValidateNumeric(txtCnic.Text))
            {
                e.Cancel = true;
                errCnic.SetError(txtCnic, "Enter numbers only!");
            }
            else if (validateCnic(txtCnic.Text))
            {
                e.Cancel = true;
                errCnic.SetError(txtCnic, "CNIC already registered!");
            }
            else
            {
                e.Cancel = false;
                errCnic.SetError(txtCnic, "");
            }
        }

        private void txtMobile_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMobile.Text))
            {
                e.Cancel = true;
                errMobile.SetError(txtMobile, "Mobile No should not be left blank!");
            }
            else if (!objValidate.ValidateNumeric(txtMobile.Text))
            {
                e.Cancel = true;
                errMobile.SetError(txtMobile, "Enter numbers only!");
            }
            else
            {
                e.Cancel = false;
                errMobile.SetError(txtMobile, "");
            }
        }

        private void txtStreet_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtStreet.Text))
            {
                e.Cancel = true;
                errStreet.SetError(txtStreet, "Street No should not be left blank!");
            }
            else if (!objValidate.ValidateAlphaNumeric(txtStreet.Text))
            {
                e.Cancel = true;
                errStreet.SetError(txtStreet, "Enter alphabets and only!");
            }
            else
            {
                e.Cancel = false;
                errStreet.SetError(txtStreet, "");
            }
        }

        private void txtHouse_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtHouse.Text))
            {
                e.Cancel = true;
                errHouse.SetError(txtHouse, "House No should not be left blank!");
            }
            else if (!objValidate.ValidateNumeric(txtHouse.Text))
            {
                e.Cancel = true;
                errHouse.SetError(txtHouse, "Enter numbers only!");
            }
            else
            {
                e.Cancel = false;
                errHouse.SetError(txtHouse, "");
            }
        }

        private void button2_Validating(object sender, CancelEventArgs e)
        {
            if (pboxVoter.Image == null)
            {
                e.Cancel = true;
                errImage.SetError(button2, "Please select an image");
            }
            else
            {
                e.Cancel = false;
                errImage.SetError(button2, "");
            }
        }

        private void button3_Validating(object sender, CancelEventArgs e)
        {
            Fmd currFingerprint=null;
            foreach (var fmd in fmds)
            {
                currFingerprint = fmd.Value;
            }
            if (fmds.Count == 0)
            {
                e.Cancel = true;
                errThumb.SetError(button3, "Please register your thumb first!");
            }
            else if (validateThumbImpression(currFingerprint))
            {
                e.Cancel = true;
                errThumb.SetError(button3, "Finger print already exists!");
            }
            else
            {
                e.Cancel = false;
                errThumb.SetError(button3, "");
            }
        }

        private void txtDob_Validating(object sender, CancelEventArgs e)
        {
            if (!calendarDob.Focused)
            {
                if (string.IsNullOrWhiteSpace(txtDob.Text))
                {
                    e.Cancel = true;
                    errDob.SetError(txtDob, "Date of birth should not be left blank!");
                }
                else if (!objValidate.ValidateDate(txtDob.Text))
                {
                    e.Cancel = true;
                    errDob.SetError(txtDob, "Invalid date format!");
                }
                else if ((DateTime.Now.Year - DateTime.Parse(txtDob.Text).Year) > 100 || DateTime.Parse(txtDob.Text) > DateTime.Now)
                {
                    e.Cancel = true;
                    errDob.SetError(txtDob, "Enter valid date range!");
                }
                else if (objValidate.calculateAge(txtDob.Text) < 18)
                {
                    e.Cancel = true;
                    errDob.SetError(txtDob, "Your age must be greater than 18!");
                }
                else
                {
                    e.Cancel = false;
                    errDob.SetError(txtDob, "");
                }
            }
        }

        private void txtDob_Enter(object sender, EventArgs e)
        {
            calendarDob.Visible = true;
            calendarDob.MaxDate = DateTime.Now;
            calendarDob.MinDate = Convert.ToDateTime("1/1/" + (DateTime.Now.Year - 100));
        }

        private void txtDob_Leave(object sender, EventArgs e)
        {
            if (!calendarDob.Focused)
            {
                calendarDob.Visible = false;
            }
        }

        private void calendarDob_DateSelected(object sender, DateRangeEventArgs e)
        {
            var calendar = sender as MonthCalendar;
            txtDob.Text = calendar.SelectionStart.ToShortDateString();
            calendar.Visible = false;
        }

        private void calendarDob_Validating(object sender, CancelEventArgs e)
        {
            if (calendarDob.Focused)
            {
                if (string.IsNullOrWhiteSpace(txtDob.Text))
                {
                    e.Cancel = true;
                    errDob.SetError(txtDob, "Date of birth should not be left blank!");
                }
                else if (!objValidate.ValidateDate(txtDob.Text))
                {
                    e.Cancel = true;
                    errDob.SetError(txtDob, "Invalid date format!");
                }
                else if ((DateTime.Now.Year - DateTime.Parse(txtDob.Text).Year) < 100 || DateTime.Parse(txtDob.Text) > DateTime.Now)
                {
                    e.Cancel = true;
                    errDob.SetError(txtDob, "Enter valid date range!");
                }
                else if (objValidate.calculateAge(txtDob.Text) < 18)
                {
                    e.Cancel = true;
                    errDob.SetError(txtDob, "Your age must be greater than 18!");
                }
                else
                {
                    e.Cancel = false;
                    errDob.SetError(txtDob, "");
                }
            }
        }

        private bool validateCnic(string cnic)
        {
            VoterModel objVoter = new VoterModel();
            DataTable tblCnic = objVoter.GetVoterByCnic(cnic);
            if (tblCnic.Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private const int DPFJ_PROBABILITY_ONE = 0x7fffffff;
        private bool validateThumbImpression(Fmd currFinger)
        {
            DataTable tblVoter = objVoter.GetVoters();
            int count = tblVoter.Rows.Count;
            Fmd[] allVoterFmds = new Fmd[count];
            if (tblVoter.Rows.Count > 0)
            {
                int index = 0;
                foreach(DataRow dr in tblVoter.Rows)
                {
                    Fmd anyFmd = Fmd.DeserializeXml(dr["voter_ThumbImpression"].ToString());
                    allVoterFmds[index] = anyFmd;
                    index++;
                }
            }
            // See the SDK documentation for an explanation on threshold scores.
            int thresholdScore = DPFJ_PROBABILITY_ONE * 1 / 100000;

            IdentifyResult identifyResult = Comparison.Identify(currFinger, 0, allVoterFmds, thresholdScore, count);
            if (identifyResult.Indexes.Length>0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // get content type
        private string GetContentType(string filepath)
        {
            var contentType = "image/jpeg";
            var extension = Path.GetExtension(filepath);

            RegistryKey registryKey = Registry.ClassesRoot.OpenSubKey(extension);

            if (registryKey != null && registryKey.GetValue("Content Type") != null)
                contentType = registryKey.GetValue("Content Type").ToString();

            return contentType;
        }

        private void BindAdminUnit()
        {
            try
            {
                DataTable tblAdminUnit = objLoc.GetAdminUnit();
                if (tblAdminUnit.Rows.Count > 0)
                {
                    cboxAdminUnit.DataSource = tblAdminUnit;
                    cboxAdminUnit.DisplayMember = "administrativeUnit_Name";
                    cboxAdminUnit.ValueMember = "administrativeUnit_Id";
                }
                else
                {
                    Dictionary<int, string> item = new Dictionary<int, string>();
                    item.Add(0, "No results found!");
                    cboxAdminUnit.DataSource = new BindingSource(item, null);
                    cboxAdminUnit.DisplayMember = "Value";
                    cboxAdminUnit.ValueMember = "Key";
                    cboxAdminUnit.SelectedIndex = 0;
                }
            }
            catch
            {
                Dictionary<int, string> item = new Dictionary<int, string>();
                item.Add(0, "No results found!");
                cboxAdminUnit.DataSource = new BindingSource(item, null);
                cboxAdminUnit.DisplayMember = "Value";
                cboxAdminUnit.ValueMember = "Key";
                cboxAdminUnit.SelectedIndex = 0;
            }
        }

        private void BindDistrict()
        {
            try
            {
                int unitId = int.Parse(cboxAdminUnit.SelectedValue.ToString());
                cboxDistrict.DataSource = null;
                DataTable tblDistrict = objLoc.GetDistrictByAdminUnit(unitId);
                if (tblDistrict.Rows.Count > 0)
                {
                    cboxDistrict.DataSource = tblDistrict;
                    cboxDistrict.DisplayMember = "district_Name";
                    cboxDistrict.ValueMember = "district_Id";
                }
                else
                {
                    Dictionary<int, string> item = new Dictionary<int, string>();
                    item.Add(0, "No results found!");
                    cboxDistrict.DataSource = new BindingSource(item, null);
                    cboxDistrict.DisplayMember = "Value";
                    cboxDistrict.ValueMember = "Key";
                    cboxDistrict.SelectedIndex = 0;
                }
            }
            catch
            {
                Dictionary<int, string> item = new Dictionary<int, string>();
                item.Add(0, "No results found!");
                cboxDistrict.DataSource = new BindingSource(item, null);
                cboxDistrict.DisplayMember = "Value";
                cboxDistrict.ValueMember = "Key";
                cboxDistrict.SelectedIndex = 0;
            }
        }

        private void BindTehsil()
        {
            try
            {
                int distId = int.Parse(cboxDistrict.SelectedValue.ToString());
                cboxTehsil.DataSource = null;
                DataTable tblTehsil = objLoc.GetTehsilByDistrictId(distId);
                if (tblTehsil.Rows.Count > 0)
                {
                    cboxTehsil.DataSource = tblTehsil;
                    cboxTehsil.DisplayMember = "tehsil_Name";
                    cboxTehsil.ValueMember = "tehsil_Id";
                }
                else
                {
                    Dictionary<int, string> item = new Dictionary<int, string>();
                    item.Add(0, "No results found!");
                    cboxTehsil.DataSource = new BindingSource(item, null);
                    cboxTehsil.DisplayMember = "Value";
                    cboxTehsil.ValueMember = "Key";
                    cboxTehsil.SelectedIndex = 0;
                }
            }
            catch
            {
                Dictionary<int, string> item = new Dictionary<int, string>();
                item.Add(0, "No results found!");
                cboxTehsil.DataSource = new BindingSource(item, null);
                cboxTehsil.DisplayMember = "Value";
                cboxTehsil.ValueMember = "Key";
                cboxTehsil.SelectedIndex = 0;
            }
        }

        private void BindMauza()
        {
            try
            {
                int tehsilId = int.Parse(cboxTehsil.SelectedValue.ToString());
                cboxMauza.DataSource = null;
                DataTable tblMauza = objLoc.GetMauzaByTehsilId(tehsilId);
                if (tblMauza.Rows.Count > 0)
                {
                    cboxMauza.DataSource = tblMauza;
                    cboxMauza.DisplayMember = "mauza_Name";
                    cboxMauza.ValueMember = "mauza_Id";
                }
                else
                {
                    Dictionary<int, string> item = new Dictionary<int, string>();
                    item.Add(0, "No results found!");
                    cboxMauza.DataSource = new BindingSource(item, null);
                    cboxMauza.DisplayMember = "Value";
                    cboxMauza.ValueMember = "Key";
                    cboxMauza.SelectedIndex = 0;
                }
            }
            catch
            {
                Dictionary<int, string> item = new Dictionary<int, string>();
                item.Add(0, "No results found!");
                cboxMauza.DataSource = new BindingSource(item, null);
                cboxMauza.DisplayMember = "Value";
                cboxMauza.ValueMember = "Key";
                cboxMauza.SelectedIndex = 0;
            }
        }

        private void BindBlock()
        {
            try
            {
                int mauzaId = int.Parse(cboxMauza.SelectedValue.ToString());
                cboxBlock.DataSource = null;
                DataTable tblBlock = objLoc.GetBlockByMauzaId(mauzaId);
                if (tblBlock.Rows.Count > 0)
                {
                    cboxBlock.DataSource = tblBlock;
                    cboxBlock.DisplayMember = "block_Number";
                    cboxBlock.ValueMember = "block_Id";
                }
                else
                {
                    Dictionary<int, string> item = new Dictionary<int, string>();
                    item.Add(0, "No results found!");
                    cboxBlock.DataSource = new BindingSource(item, null);
                    cboxBlock.DisplayMember = "Value";
                    cboxBlock.ValueMember = "Key";
                    cboxBlock.SelectedIndex = 0;
                }
            }
            catch
            {
                Dictionary<int, string> item = new Dictionary<int, string>();
                item.Add(0, "No results found!");
                cboxBlock.DataSource = new BindingSource(item, null);
                cboxBlock.DisplayMember = "Value";
                cboxBlock.ValueMember = "Key";
                cboxBlock.SelectedIndex = 0;
            }
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void lblMobile_Click(object sender, EventArgs e)
        {

        }

        private void lblLastName_Click(object sender, EventArgs e)
        {

        }

        private void RegisterVoter_FormClosing_1(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }

    }
}
