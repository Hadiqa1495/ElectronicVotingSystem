﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EVS_VoterPanel.DataAccess;
using System.Text.RegularExpressions;

namespace EVS_VoterPanel
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        //private RegisterVoter form;
        private void button1_Click(object sender, EventArgs e)
        {
            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                LoginModel objLogin=new LoginModel();
                string username = txtName.Text;
                string pwd = txtPassword.Text;
                string hash = objLogin.GetMd5Hash(pwd);
                int role = 1;
                DataTable success = objLogin.GetMemberByLoginInfo(role, username, hash);
                if (success.Rows.Count > 0)
                {
                    //if (form == null)
                    //{
                    //    form = new RegisterVoter();
                    //}
                    //this.Hide();
                    //form.ShowDialog();

                    //form.Dispose();
                    //form = null;

                    this.Hide();
                    RegisterVoter form = new RegisterVoter();
                    form.Show();
                }
                else
                {
                    label5.Text = "Invalid username or password!";
                }
            } 
        }

        private void txtName_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                e.Cancel = true;
                errUsername.SetError(txtName, "Username should not be left blank!");
            }
            else if(!ValidateEmail(txtName.Text))
            {
                e.Cancel = true;
                errUsername.SetError(txtName, "Enter valid email!");         
            }
            else
            {
                e.Cancel = false;
                errUsername.SetError(txtName, "");
            }
        }

        private void textBox2_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                e.Cancel = true;
                errPassword.SetError(txtPassword, "Password should not be left blank!");
            }
            else
            {
                e.Cancel = false;
                errPassword.SetError(txtPassword, "");
            }
        }

        private bool ValidateEmail(string emailAddress)
        {
            string regexPattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$";
            Match matches = Regex.Match(emailAddress, regexPattern);
            return matches.Success;
        }

        private void btnShutdown_Click(object sender, EventArgs e)
        {
            CausesValidation = false;
            foreach (Control control in this.Controls)
            {
                control.CausesValidation = false;
            }
            errUsername.Clear();
            errPassword.Clear();
            Application.Exit();
        }

        private void Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }
    }
}
