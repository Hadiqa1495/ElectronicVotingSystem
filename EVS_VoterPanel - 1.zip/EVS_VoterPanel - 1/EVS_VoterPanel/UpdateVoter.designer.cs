﻿namespace EVS_VoterPanel
{
    partial class UpdateVoter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }


        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DPUruNet.Reader reader1 = new DPUruNet.Reader();
            this.lblAdminUnit = new System.Windows.Forms.Label();
            this.cboxAdminUnit = new System.Windows.Forms.ComboBox();
            this.lblDistrict = new System.Windows.Forms.Label();
            this.cboxDistrict = new System.Windows.Forms.ComboBox();
            this.lblTehsil = new System.Windows.Forms.Label();
            this.cboxTehsil = new System.Windows.Forms.ComboBox();
            this.lblBlock = new System.Windows.Forms.Label();
            this.cboxBlock = new System.Windows.Forms.ComboBox();
            this.lblFirstname = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.lblDob = new System.Windows.Forms.Label();
            this.txtDob = new System.Windows.Forms.TextBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.lblCnic = new System.Windows.Forms.Label();
            this.txtCnic = new System.Windows.Forms.TextBox();
            this.lblHouse = new System.Windows.Forms.Label();
            this.lblStreet = new System.Windows.Forms.Label();
            this.txtHouse = new System.Windows.Forms.TextBox();
            this.txtStreet = new System.Windows.Forms.TextBox();
            this.lblMobile = new System.Windows.Forms.Label();
            this.txtMobile = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cboxMauza = new System.Windows.Forms.ComboBox();
            this.gboxGender = new System.Windows.Forms.GroupBox();
            this.gboxReligion = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.errDistrict = new System.Windows.Forms.ErrorProvider(this.components);
            this.errAdminUnit = new System.Windows.Forms.ErrorProvider(this.components);
            this.errTehsil = new System.Windows.Forms.ErrorProvider(this.components);
            this.errMauza = new System.Windows.Forms.ErrorProvider(this.components);
            this.errBlock = new System.Windows.Forms.ErrorProvider(this.components);
            this.errFirstName = new System.Windows.Forms.ErrorProvider(this.components);
            this.errLastName = new System.Windows.Forms.ErrorProvider(this.components);
            this.errDob = new System.Windows.Forms.ErrorProvider(this.components);
            this.errCnic = new System.Windows.Forms.ErrorProvider(this.components);
            this.errHouse = new System.Windows.Forms.ErrorProvider(this.components);
            this.errStreet = new System.Windows.Forms.ErrorProvider(this.components);
            this.errMobile = new System.Windows.Forms.ErrorProvider(this.components);
            this.lblMsg = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.pboxVoter = new System.Windows.Forms.PictureBox();
            this.calendarDob = new System.Windows.Forms.MonthCalendar();
            this.button3 = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.errSearch = new System.Windows.Forms.ErrorProvider(this.components);
            this.errThumb = new System.Windows.Forms.ErrorProvider(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.gboxGender.SuspendLayout();
            this.gboxReligion.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errDistrict)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errAdminUnit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errTehsil)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errMauza)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errBlock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errFirstName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errLastName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errDob)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errCnic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errHouse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errStreet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errMobile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pboxVoter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errSearch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errThumb)).BeginInit();
            this.SuspendLayout();
            // 
            // lblAdminUnit
            // 
            this.lblAdminUnit.AutoSize = true;
            this.lblAdminUnit.BackColor = System.Drawing.Color.Transparent;
            this.lblAdminUnit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdminUnit.Location = new System.Drawing.Point(97, 335);
            this.lblAdminUnit.Name = "lblAdminUnit";
            this.lblAdminUnit.Size = new System.Drawing.Size(259, 25);
            this.lblAdminUnit.TabIndex = 0;
            this.lblAdminUnit.Text = "Select Administrative Unit";
            // 
            // cboxAdminUnit
            // 
            this.cboxAdminUnit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxAdminUnit.FormattingEnabled = true;
            this.cboxAdminUnit.Location = new System.Drawing.Point(102, 363);
            this.cboxAdminUnit.Name = "cboxAdminUnit";
            this.cboxAdminUnit.Size = new System.Drawing.Size(289, 34);
            this.cboxAdminUnit.TabIndex = 1;
            this.cboxAdminUnit.SelectedIndexChanged += new System.EventHandler(this.cboxAdminUnit_SelectedIndexChanged);
            this.cboxAdminUnit.Validating += new System.ComponentModel.CancelEventHandler(this.cboxAdminUnit_Validating);
            // 
            // lblDistrict
            // 
            this.lblDistrict.AutoSize = true;
            this.lblDistrict.BackColor = System.Drawing.Color.Transparent;
            this.lblDistrict.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDistrict.Location = new System.Drawing.Point(580, 335);
            this.lblDistrict.Name = "lblDistrict";
            this.lblDistrict.Size = new System.Drawing.Size(145, 25);
            this.lblDistrict.TabIndex = 2;
            this.lblDistrict.Text = "Select District";
            // 
            // cboxDistrict
            // 
            this.cboxDistrict.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxDistrict.FormattingEnabled = true;
            this.cboxDistrict.Location = new System.Drawing.Point(585, 363);
            this.cboxDistrict.Name = "cboxDistrict";
            this.cboxDistrict.Size = new System.Drawing.Size(289, 34);
            this.cboxDistrict.TabIndex = 3;
            this.cboxDistrict.SelectedIndexChanged += new System.EventHandler(this.cboxDistrict_SelectedIndexChanged);
            this.cboxDistrict.Validating += new System.ComponentModel.CancelEventHandler(this.cboxDistrict_Validating);
            // 
            // lblTehsil
            // 
            this.lblTehsil.AutoSize = true;
            this.lblTehsil.BackColor = System.Drawing.Color.Transparent;
            this.lblTehsil.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTehsil.Location = new System.Drawing.Point(1087, 335);
            this.lblTehsil.Name = "lblTehsil";
            this.lblTehsil.Size = new System.Drawing.Size(138, 25);
            this.lblTehsil.TabIndex = 4;
            this.lblTehsil.Text = "Select Tehsil";
            // 
            // cboxTehsil
            // 
            this.cboxTehsil.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxTehsil.FormattingEnabled = true;
            this.cboxTehsil.Location = new System.Drawing.Point(1092, 363);
            this.cboxTehsil.Name = "cboxTehsil";
            this.cboxTehsil.Size = new System.Drawing.Size(289, 34);
            this.cboxTehsil.TabIndex = 5;
            this.cboxTehsil.SelectedIndexChanged += new System.EventHandler(this.cboxTehsil_SelectedIndexChanged);
            this.cboxTehsil.Validating += new System.ComponentModel.CancelEventHandler(this.cboxTehsil_Validating);
            // 
            // lblBlock
            // 
            this.lblBlock.AutoSize = true;
            this.lblBlock.BackColor = System.Drawing.Color.Transparent;
            this.lblBlock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBlock.Location = new System.Drawing.Point(580, 418);
            this.lblBlock.Name = "lblBlock";
            this.lblBlock.Size = new System.Drawing.Size(132, 25);
            this.lblBlock.TabIndex = 6;
            this.lblBlock.Text = "Select Block";
            // 
            // cboxBlock
            // 
            this.cboxBlock.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxBlock.FormattingEnabled = true;
            this.cboxBlock.Location = new System.Drawing.Point(585, 446);
            this.cboxBlock.Name = "cboxBlock";
            this.cboxBlock.Size = new System.Drawing.Size(289, 34);
            this.cboxBlock.TabIndex = 7;
            this.cboxBlock.Validating += new System.ComponentModel.CancelEventHandler(this.cboxBlock_Validating);
            // 
            // lblFirstname
            // 
            this.lblFirstname.AutoSize = true;
            this.lblFirstname.BackColor = System.Drawing.Color.Transparent;
            this.lblFirstname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstname.Location = new System.Drawing.Point(97, 501);
            this.lblFirstname.Name = "lblFirstname";
            this.lblFirstname.Size = new System.Drawing.Size(116, 25);
            this.lblFirstname.TabIndex = 8;
            this.lblFirstname.Text = "First Name";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFirstName.Location = new System.Drawing.Point(102, 529);
            this.txtFirstName.MaxLength = 50;
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(289, 32);
            this.txtFirstName.TabIndex = 9;
            this.txtFirstName.Validating += new System.ComponentModel.CancelEventHandler(this.txtFirstName_Validating);
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.BackColor = System.Drawing.Color.Transparent;
            this.lblLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLastName.Location = new System.Drawing.Point(580, 501);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(115, 25);
            this.lblLastName.TabIndex = 10;
            this.lblLastName.Text = "Last Name";
            // 
            // txtLastName
            // 
            this.txtLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLastName.Location = new System.Drawing.Point(585, 529);
            this.txtLastName.MaxLength = 50;
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(289, 32);
            this.txtLastName.TabIndex = 11;
            this.txtLastName.Validating += new System.ComponentModel.CancelEventHandler(this.txtLastName_Validating);
            // 
            // lblDob
            // 
            this.lblDob.AutoSize = true;
            this.lblDob.BackColor = System.Drawing.Color.Transparent;
            this.lblDob.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDob.Location = new System.Drawing.Point(97, 584);
            this.lblDob.Name = "lblDob";
            this.lblDob.Size = new System.Drawing.Size(269, 25);
            this.lblDob.TabIndex = 12;
            this.lblDob.Text = "Date of Birth (mm/dd/yyyy)";
            // 
            // txtDob
            // 
            this.txtDob.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDob.Location = new System.Drawing.Point(102, 612);
            this.txtDob.MaxLength = 10;
            this.txtDob.Name = "txtDob";
            this.txtDob.Size = new System.Drawing.Size(289, 32);
            this.txtDob.TabIndex = 13;
            this.txtDob.Tag = "";
            this.txtDob.Enter += new System.EventHandler(this.txtDob_Enter);
            this.txtDob.Leave += new System.EventHandler(this.txtDob_Leave);
            this.txtDob.Validating += new System.ComponentModel.CancelEventHandler(this.txtDob_Validating);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.Location = new System.Drawing.Point(6, 29);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(95, 29);
            this.radioButton1.TabIndex = 14;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Muslim";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2.Location = new System.Drawing.Point(145, 29);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(138, 29);
            this.radioButton2.TabIndex = 15;
            this.radioButton2.Text = "Non-Muslim";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Checked = true;
            this.radioButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton3.Location = new System.Drawing.Point(6, 29);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(76, 29);
            this.radioButton3.TabIndex = 16;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Male";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton4.Location = new System.Drawing.Point(97, 29);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(98, 29);
            this.radioButton4.TabIndex = 17;
            this.radioButton4.Text = "Female";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton5.Location = new System.Drawing.Point(201, 29);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(82, 29);
            this.radioButton5.TabIndex = 18;
            this.radioButton5.Text = "Other";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // lblCnic
            // 
            this.lblCnic.AutoSize = true;
            this.lblCnic.BackColor = System.Drawing.Color.Transparent;
            this.lblCnic.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCnic.Location = new System.Drawing.Point(566, 237);
            this.lblCnic.Name = "lblCnic";
            this.lblCnic.Size = new System.Drawing.Size(240, 25);
            this.lblCnic.TabIndex = 21;
            this.lblCnic.Text = "CNIC (Without Dashes)";
            // 
            // txtCnic
            // 
            this.txtCnic.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCnic.Location = new System.Drawing.Point(568, 265);
            this.txtCnic.MaxLength = 13;
            this.txtCnic.Name = "txtCnic";
            this.txtCnic.Size = new System.Drawing.Size(289, 32);
            this.txtCnic.TabIndex = 0;
            this.txtCnic.Validating += new System.ComponentModel.CancelEventHandler(this.txtCnic_Validating);
            // 
            // lblHouse
            // 
            this.lblHouse.AutoSize = true;
            this.lblHouse.BackColor = System.Drawing.Color.Transparent;
            this.lblHouse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHouse.Location = new System.Drawing.Point(101, 657);
            this.lblHouse.Name = "lblHouse";
            this.lblHouse.Size = new System.Drawing.Size(113, 25);
            this.lblHouse.TabIndex = 23;
            this.lblHouse.Text = "House No.";
            // 
            // lblStreet
            // 
            this.lblStreet.AutoSize = true;
            this.lblStreet.BackColor = System.Drawing.Color.Transparent;
            this.lblStreet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStreet.Location = new System.Drawing.Point(580, 657);
            this.lblStreet.Name = "lblStreet";
            this.lblStreet.Size = new System.Drawing.Size(109, 25);
            this.lblStreet.TabIndex = 24;
            this.lblStreet.Text = "Street No.";
            // 
            // txtHouse
            // 
            this.txtHouse.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHouse.Location = new System.Drawing.Point(102, 685);
            this.txtHouse.MaxLength = 50;
            this.txtHouse.Name = "txtHouse";
            this.txtHouse.Size = new System.Drawing.Size(289, 32);
            this.txtHouse.TabIndex = 25;
            this.txtHouse.Validating += new System.ComponentModel.CancelEventHandler(this.txtHouse_Validating);
            // 
            // txtStreet
            // 
            this.txtStreet.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStreet.Location = new System.Drawing.Point(585, 685);
            this.txtStreet.MaxLength = 50;
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.Size = new System.Drawing.Size(289, 32);
            this.txtStreet.TabIndex = 26;
            this.txtStreet.Validating += new System.ComponentModel.CancelEventHandler(this.txtStreet_Validating);
            // 
            // lblMobile
            // 
            this.lblMobile.AutoSize = true;
            this.lblMobile.BackColor = System.Drawing.Color.Transparent;
            this.lblMobile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMobile.Location = new System.Drawing.Point(580, 584);
            this.lblMobile.Name = "lblMobile";
            this.lblMobile.Size = new System.Drawing.Size(115, 25);
            this.lblMobile.TabIndex = 27;
            this.lblMobile.Text = "Mobile No.";
            // 
            // txtMobile
            // 
            this.txtMobile.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMobile.Location = new System.Drawing.Point(585, 612);
            this.txtMobile.MaxLength = 20;
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.Size = new System.Drawing.Size(289, 32);
            this.txtMobile.TabIndex = 28;
            this.txtMobile.Validating += new System.ComponentModel.CancelEventHandler(this.txtMobile_Validating);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(1093, 653);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(116, 25);
            this.label13.TabIndex = 29;
            this.label13.Text = "Add Image";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(97, 418);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(215, 25);
            this.label1.TabIndex = 30;
            this.label1.Text = "Select Electoral Area";
            // 
            // cboxMauza
            // 
            this.cboxMauza.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxMauza.FormattingEnabled = true;
            this.cboxMauza.Location = new System.Drawing.Point(102, 446);
            this.cboxMauza.Name = "cboxMauza";
            this.cboxMauza.Size = new System.Drawing.Size(289, 34);
            this.cboxMauza.TabIndex = 31;
            this.cboxMauza.SelectedIndexChanged += new System.EventHandler(this.cboxMauza_SelectedIndexChanged);
            this.cboxMauza.Validating += new System.ComponentModel.CancelEventHandler(this.cboxMauza_Validating);
            // 
            // gboxGender
            // 
            this.gboxGender.BackColor = System.Drawing.Color.Transparent;
            this.gboxGender.Controls.Add(this.radioButton3);
            this.gboxGender.Controls.Add(this.radioButton4);
            this.gboxGender.Controls.Add(this.radioButton5);
            this.gboxGender.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gboxGender.Location = new System.Drawing.Point(1092, 418);
            this.gboxGender.Name = "gboxGender";
            this.gboxGender.Size = new System.Drawing.Size(289, 62);
            this.gboxGender.TabIndex = 32;
            this.gboxGender.TabStop = false;
            this.gboxGender.Text = "Gender";
            // 
            // gboxReligion
            // 
            this.gboxReligion.BackColor = System.Drawing.Color.Transparent;
            this.gboxReligion.Controls.Add(this.radioButton1);
            this.gboxReligion.Controls.Add(this.radioButton2);
            this.gboxReligion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gboxReligion.Location = new System.Drawing.Point(1092, 501);
            this.gboxReligion.Name = "gboxReligion";
            this.gboxReligion.Size = new System.Drawing.Size(289, 60);
            this.gboxReligion.TabIndex = 33;
            this.gboxReligion.TabStop = false;
            this.gboxReligion.Text = "Religion";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Green;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(623, 758);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(200, 50);
            this.button1.TabIndex = 34;
            this.button1.Text = "Update";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // errDistrict
            // 
            this.errDistrict.ContainerControl = this;
            // 
            // errAdminUnit
            // 
            this.errAdminUnit.ContainerControl = this;
            // 
            // errTehsil
            // 
            this.errTehsil.ContainerControl = this;
            // 
            // errMauza
            // 
            this.errMauza.ContainerControl = this;
            // 
            // errBlock
            // 
            this.errBlock.ContainerControl = this;
            // 
            // errFirstName
            // 
            this.errFirstName.ContainerControl = this;
            // 
            // errLastName
            // 
            this.errLastName.ContainerControl = this;
            // 
            // errDob
            // 
            this.errDob.ContainerControl = this;
            // 
            // errCnic
            // 
            this.errCnic.ContainerControl = this;
            // 
            // errHouse
            // 
            this.errHouse.ContainerControl = this;
            // 
            // errStreet
            // 
            this.errStreet.ContainerControl = this;
            // 
            // errMobile
            // 
            this.errMobile.ContainerControl = this;
            // 
            // lblMsg
            // 
            this.lblMsg.AutoSize = true;
            this.lblMsg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsg.Location = new System.Drawing.Point(941, 734);
            this.lblMsg.Name = "lblMsg";
            this.lblMsg.Size = new System.Drawing.Size(0, 25);
            this.lblMsg.TabIndex = 35;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(1092, 681);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(101, 36);
            this.button2.TabIndex = 36;
            this.button2.Text = "Browse";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "Image Files (JPG,PNG,GIF)|*.JPG;*.PNG;*.GIF";
            // 
            // pboxVoter
            // 
            this.pboxVoter.BackColor = System.Drawing.Color.Transparent;
            this.pboxVoter.Location = new System.Drawing.Point(1231, 612);
            this.pboxVoter.Name = "pboxVoter";
            this.pboxVoter.Size = new System.Drawing.Size(150, 150);
            this.pboxVoter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pboxVoter.TabIndex = 37;
            this.pboxVoter.TabStop = false;
            // 
            // calendarDob
            // 
            this.calendarDob.Location = new System.Drawing.Point(357, 612);
            this.calendarDob.MaxDate = new System.DateTime(2017, 4, 23, 0, 0, 0, 0);
            this.calendarDob.Name = "calendarDob";
            this.calendarDob.TabIndex = 38;
            this.calendarDob.Visible = false;
            this.calendarDob.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.calendarDob_DateSelected);
            this.calendarDob.Validating += new System.ComponentModel.CancelEventHandler(this.calendarDob_Validating);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Green;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(388, 758);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(200, 50);
            this.button3.TabIndex = 39;
            this.button3.Text = "Enroll Thumb";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            this.button3.Validating += new System.ComponentModel.CancelEventHandler(this.button3_Validating);
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.Green;
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ForeColor = System.Drawing.Color.White;
            this.btnSearch.Location = new System.Drawing.Point(876, 265);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(83, 32);
            this.btnSearch.TabIndex = 40;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            this.btnSearch.Validating += new System.ComponentModel.CancelEventHandler(this.btnSearch_Validating);
            // 
            // errSearch
            // 
            this.errSearch.ContainerControl = this;
            // 
            // errThumb
            // 
            this.errThumb.ContainerControl = this;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Script MT Bold", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(589, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(296, 61);
            this.label2.TabIndex = 45;
            this.label2.Text = "Update Voter";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Green;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(854, 758);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(200, 50);
            this.button4.TabIndex = 46;
            this.button4.Text = "Delete";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // UpdateVoter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1582, 853);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.calendarDob);
            this.Controls.Add(this.pboxVoter);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.lblMsg);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.gboxReligion);
            this.Controls.Add(this.gboxGender);
            this.Controls.Add(this.cboxMauza);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtMobile);
            this.Controls.Add(this.lblMobile);
            this.Controls.Add(this.txtStreet);
            this.Controls.Add(this.txtHouse);
            this.Controls.Add(this.lblStreet);
            this.Controls.Add(this.lblHouse);
            this.Controls.Add(this.txtCnic);
            this.Controls.Add(this.lblCnic);
            this.Controls.Add(this.txtDob);
            this.Controls.Add(this.lblDob);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.lblFirstname);
            this.Controls.Add(this.cboxBlock);
            this.Controls.Add(this.lblBlock);
            this.Controls.Add(this.cboxTehsil);
            this.Controls.Add(this.lblTehsil);
            this.Controls.Add(this.cboxDistrict);
            this.Controls.Add(this.lblDistrict);
            this.Controls.Add(this.cboxAdminUnit);
            this.Controls.Add(this.lblAdminUnit);
            reader1.Capabilities = null;
            reader1.Description = null;
            reader1.Status = null;
            this.CurrentReader = reader1;
            this.Name = "UpdateVoter";
            this.Text = "Voter Updation";
            this.Load += new System.EventHandler(this.UpdateVoter_Load);
            this.Controls.SetChildIndex(this.lblAdminUnit, 0);
            this.Controls.SetChildIndex(this.cboxAdminUnit, 0);
            this.Controls.SetChildIndex(this.lblDistrict, 0);
            this.Controls.SetChildIndex(this.cboxDistrict, 0);
            this.Controls.SetChildIndex(this.lblTehsil, 0);
            this.Controls.SetChildIndex(this.cboxTehsil, 0);
            this.Controls.SetChildIndex(this.lblBlock, 0);
            this.Controls.SetChildIndex(this.cboxBlock, 0);
            this.Controls.SetChildIndex(this.lblFirstname, 0);
            this.Controls.SetChildIndex(this.txtFirstName, 0);
            this.Controls.SetChildIndex(this.lblLastName, 0);
            this.Controls.SetChildIndex(this.txtLastName, 0);
            this.Controls.SetChildIndex(this.lblDob, 0);
            this.Controls.SetChildIndex(this.txtDob, 0);
            this.Controls.SetChildIndex(this.lblCnic, 0);
            this.Controls.SetChildIndex(this.txtCnic, 0);
            this.Controls.SetChildIndex(this.lblHouse, 0);
            this.Controls.SetChildIndex(this.lblStreet, 0);
            this.Controls.SetChildIndex(this.txtHouse, 0);
            this.Controls.SetChildIndex(this.txtStreet, 0);
            this.Controls.SetChildIndex(this.lblMobile, 0);
            this.Controls.SetChildIndex(this.txtMobile, 0);
            this.Controls.SetChildIndex(this.label13, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.cboxMauza, 0);
            this.Controls.SetChildIndex(this.gboxGender, 0);
            this.Controls.SetChildIndex(this.gboxReligion, 0);
            this.Controls.SetChildIndex(this.button1, 0);
            this.Controls.SetChildIndex(this.lblMsg, 0);
            this.Controls.SetChildIndex(this.button2, 0);
            this.Controls.SetChildIndex(this.pboxVoter, 0);
            this.Controls.SetChildIndex(this.calendarDob, 0);
            this.Controls.SetChildIndex(this.button3, 0);
            this.Controls.SetChildIndex(this.btnSearch, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.button4, 0);
            this.gboxGender.ResumeLayout(false);
            this.gboxGender.PerformLayout();
            this.gboxReligion.ResumeLayout(false);
            this.gboxReligion.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errDistrict)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errAdminUnit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errTehsil)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errMauza)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errBlock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errFirstName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errLastName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errDob)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errCnic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errHouse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errStreet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errMobile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pboxVoter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errSearch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errThumb)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox gboxReligion;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.GroupBox gboxGender;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.ComboBox cboxMauza;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ErrorProvider errDistrict;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label lblMsg;
        private System.Windows.Forms.PictureBox pboxVoter;
        private System.Windows.Forms.MonthCalendar calendarDob;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtMobile;
        private System.Windows.Forms.Label lblMobile;
        private System.Windows.Forms.TextBox txtStreet;
        private System.Windows.Forms.TextBox txtHouse;
        private System.Windows.Forms.Label lblStreet;
        private System.Windows.Forms.Label lblHouse;
        private System.Windows.Forms.TextBox txtCnic;
        private System.Windows.Forms.Label lblCnic;
        private System.Windows.Forms.TextBox txtDob;
        private System.Windows.Forms.Label lblDob;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label lblFirstname;
        private System.Windows.Forms.ComboBox cboxBlock;
        private System.Windows.Forms.Label lblBlock;
        private System.Windows.Forms.ComboBox cboxTehsil;
        private System.Windows.Forms.Label lblTehsil;
        private System.Windows.Forms.ComboBox cboxDistrict;
        private System.Windows.Forms.Label lblDistrict;
        private System.Windows.Forms.ComboBox cboxAdminUnit;
        private System.Windows.Forms.Label lblAdminUnit;
        private System.Windows.Forms.ErrorProvider errAdminUnit;
        private System.Windows.Forms.ErrorProvider errTehsil;
        private System.Windows.Forms.ErrorProvider errMauza;
        private System.Windows.Forms.ErrorProvider errBlock;
        private System.Windows.Forms.ErrorProvider errFirstName;
        private System.Windows.Forms.ErrorProvider errLastName;
        private System.Windows.Forms.ErrorProvider errDob;
        private System.Windows.Forms.ErrorProvider errCnic;
        private System.Windows.Forms.ErrorProvider errHouse;
        private System.Windows.Forms.ErrorProvider errStreet;
        private System.Windows.Forms.ErrorProvider errMobile;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.ErrorProvider errSearch;
        private System.Windows.Forms.ErrorProvider errThumb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button4;
    }
}