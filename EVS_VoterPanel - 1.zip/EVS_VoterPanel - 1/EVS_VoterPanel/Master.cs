﻿using DPUruNet;
using EVS_VoterPanel.Helper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EVS_VoterPanel
{
    public partial class Master : Form
    {
        protected FingerprintReader objReader = new FingerprintReader();
        protected EnrollmentControl enrollmentControl;

        protected ReaderSelection _readerSelection;

        protected Reader _reader;
        public Reader CurrentReader
        {
            get { return _reader; }
            set { _reader = value; }
        }

        // Holds fmds enrolled by the enrollment GUI.
        protected Dictionary<int, Fmd> fmds = new Dictionary<int, Fmd>();
        public Dictionary<int, Fmd> Fmds
        {
            get { return fmds; }
            set { fmds = value; }
        }

        public Master()
        {
            InitializeComponent();
        }

        private void Master_Load(object sender, EventArgs e)
        {
            if (objReader.getReaders() == null)
            {
                if (_readerSelection == null)
                {
                    _readerSelection = new ReaderSelection();
                    _readerSelection.Sender = this;
                }
                _readerSelection.ShowDialog();

                _readerSelection.Dispose();
                _readerSelection = null;
            }
            else
            {
                CurrentReader = objReader.getReaders();
            }
        }

        private void registerVoterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RegisterVoter form = new RegisterVoter();
            form.Show();
            this.Hide();
        }

        private void updateVoterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateVoter form = new UpdateVoter();
            form.Show();
            this.Hide();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Login form = new Login();
            form.Show();
            this.Hide();
        }

        private void shutdownToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CausesValidation = false;
            foreach (Control control in this.Controls)
            {
                control.CausesValidation = false;
            }
            Application.Exit();
        }

        private void Master_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }

        private void biometricReaderCollectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_readerSelection == null)
            {
                _readerSelection = new ReaderSelection();
                _readerSelection.Sender = this;
            }
            _readerSelection.ShowDialog();

            _readerSelection.Dispose();
            _readerSelection = null;
        }
    }
}
