﻿namespace EVS_VoterPanel
{
    partial class Master
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.registerVoterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateVoterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.biometricReaderCollectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shutdownToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Script MT Bold", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(682, 81);
            this.label3.TabIndex = 48;
            this.label3.Text = "Electronic Voting System";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Green;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registerVoterToolStripMenuItem,
            this.updateVoterToolStripMenuItem,
            this.biometricReaderCollectionToolStripMenuItem,
            this.logoutToolStripMenuItem,
            this.shutdownToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1582, 48);
            this.menuStrip1.TabIndex = 49;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // registerVoterToolStripMenuItem
            // 
            this.registerVoterToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.registerVoterToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.registerVoterToolStripMenuItem.Margin = new System.Windows.Forms.Padding(50, 5, 50, 5);
            this.registerVoterToolStripMenuItem.Name = "registerVoterToolStripMenuItem";
            this.registerVoterToolStripMenuItem.Padding = new System.Windows.Forms.Padding(25, 0, 25, 0);
            this.registerVoterToolStripMenuItem.Size = new System.Drawing.Size(215, 34);
            this.registerVoterToolStripMenuItem.Text = "Register Voter";
            this.registerVoterToolStripMenuItem.Click += new System.EventHandler(this.registerVoterToolStripMenuItem_Click);
            // 
            // updateVoterToolStripMenuItem
            // 
            this.updateVoterToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.updateVoterToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.updateVoterToolStripMenuItem.Margin = new System.Windows.Forms.Padding(50, 5, 50, 5);
            this.updateVoterToolStripMenuItem.Name = "updateVoterToolStripMenuItem";
            this.updateVoterToolStripMenuItem.Padding = new System.Windows.Forms.Padding(25, 0, 25, 0);
            this.updateVoterToolStripMenuItem.Size = new System.Drawing.Size(207, 34);
            this.updateVoterToolStripMenuItem.Text = "Update Voter";
            this.updateVoterToolStripMenuItem.Click += new System.EventHandler(this.updateVoterToolStripMenuItem_Click);
            // 
            // biometricReaderCollectionToolStripMenuItem
            // 
            this.biometricReaderCollectionToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.biometricReaderCollectionToolStripMenuItem.Margin = new System.Windows.Forms.Padding(40, 0, 40, 0);
            this.biometricReaderCollectionToolStripMenuItem.Name = "biometricReaderCollectionToolStripMenuItem";
            this.biometricReaderCollectionToolStripMenuItem.Padding = new System.Windows.Forms.Padding(25, 0, 25, 0);
            this.biometricReaderCollectionToolStripMenuItem.Size = new System.Drawing.Size(345, 44);
            this.biometricReaderCollectionToolStripMenuItem.Text = "Biometric Reader Selection";
            this.biometricReaderCollectionToolStripMenuItem.Click += new System.EventHandler(this.biometricReaderCollectionToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.logoutToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.logoutToolStripMenuItem.Margin = new System.Windows.Forms.Padding(50, 5, 50, 5);
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Padding = new System.Windows.Forms.Padding(25, 0, 25, 0);
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(140, 34);
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // shutdownToolStripMenuItem
            // 
            this.shutdownToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.shutdownToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.shutdownToolStripMenuItem.Margin = new System.Windows.Forms.Padding(50, 5, 50, 5);
            this.shutdownToolStripMenuItem.Name = "shutdownToolStripMenuItem";
            this.shutdownToolStripMenuItem.Padding = new System.Windows.Forms.Padding(50, 0, 50, 0);
            this.shutdownToolStripMenuItem.Size = new System.Drawing.Size(222, 34);
            this.shutdownToolStripMenuItem.Text = "Shutdown";
            this.shutdownToolStripMenuItem.Click += new System.EventHandler(this.shutdownToolStripMenuItem_Click);
            // 
            // Master
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleGreen;
            this.BackgroundImage = global::EVS_VoterPanel.Properties.Resources.Screenshot__280_2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1582, 853);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Master";
            this.Text = "Voter Panel";
            this.Load += new System.EventHandler(this.Master_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem registerVoterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateVoterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shutdownToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem biometricReaderCollectionToolStripMenuItem;
    }
}