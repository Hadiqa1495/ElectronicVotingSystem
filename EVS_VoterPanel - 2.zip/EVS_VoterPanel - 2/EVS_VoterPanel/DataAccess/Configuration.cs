﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace EVS_VoterPanel.DataAccess
{
    class Configuration
    {
        // Caches the connection string
        private static string dbConnectionString;
        // Caches the data provider name 
        private static string dbProviderName;
        // Store the number of products per page

        static Configuration()
        {
            dbConnectionString = ConfigurationManager.ConnectionStrings["EVS_Connection"].ConnectionString;
            dbProviderName = ConfigurationManager.ConnectionStrings["EVS_Connection"].ProviderName;
        }

        // Returns the connection string for the BalloonShop database
        public static string DbConnectionString
        {
            get
            {
                return dbConnectionString;
            }
        }

        // Returns the data provider name
        public static string DbProviderName
        {
            get
            {
                return dbProviderName;
            }
        }
    }
}
