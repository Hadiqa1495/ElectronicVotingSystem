﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EVS_VoterPanel.DataAccess
{
    class LocationModel
    {
        public DataTable GetAdminUnit()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_AdministrativeUnit";

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetDistrictByAdminUnit(int adminUnitId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_District_ByAdminUnit";

            DbParameter adminId = comm.CreateParameter();
            adminId.ParameterName = "@adminUnitId";
            adminId.Value = adminUnitId;
            adminId.DbType = DbType.Int32;
            comm.Parameters.Add(adminId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetTehsilByDistrictId(int distId)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Tehsil_ByDistrictId";
            // execute the stored procedure and return the results

            DbParameter districtId = comm.CreateParameter();
            districtId.ParameterName = "@distId";
            districtId.Value = distId;
            districtId.DbType = DbType.Int32;
            comm.Parameters.Add(districtId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetMauzaByTehsilId(int tehsil_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Mauza_ByTehsilId";
            // execute the stored procedure and return the results

            DbParameter tehsilId = comm.CreateParameter();
            tehsilId.ParameterName = "@mauza_TehsilId";
            tehsilId.Value = tehsil_Id;
            tehsilId.DbType = DbType.Int32;
            comm.Parameters.Add(tehsilId);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetBlockByMauzaId(int mauza_Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Block_ByMauzaId";
            // execute the stored procedure and return the results

            DbParameter mauzaId = comm.CreateParameter();
            mauzaId.ParameterName = "@block_MauzaId";
            mauzaId.Value = mauza_Id;
            mauzaId.DbType = DbType.Int32;
            comm.Parameters.Add(mauzaId);

            return GenericDataAccess.ExecuteReader(comm);
        }

    }
}
