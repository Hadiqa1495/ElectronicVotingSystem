﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EVS_VoterPanel.DataAccess
{
    class VoterModel
    {
        public bool SaveVoter(string fName, string lName, DateTime dob, string cnic, string gender, string religion, int houseNo, string street, string mobile, string imageName, string imageType, byte[] n_Image_Size, int blockId, string fingerprint)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_InsertInto_Voter";
            // execute the stored procedure and return the results

            DbParameter voter_HouseNo = comm.CreateParameter();
            voter_HouseNo.ParameterName = "@voter_HouseNo";
            voter_HouseNo.Value = houseNo;
            voter_HouseNo.DbType = DbType.Int32;
            comm.Parameters.Add(voter_HouseNo);

            DbParameter voter_Religion = comm.CreateParameter();
            voter_Religion.ParameterName = "@voter_Religion";
            voter_Religion.Value = religion;
            voter_Religion.DbType = DbType.String;
            voter_Religion.Size = 50;
            comm.Parameters.Add(voter_Religion);

            DbParameter voter_Gender = comm.CreateParameter();
            voter_Gender.ParameterName = "@voter_Gender";
            voter_Gender.Value = gender;
            voter_Gender.DbType = DbType.String;
            voter_Gender.Size = 50;
            comm.Parameters.Add(voter_Gender);

            DbParameter voter_CNIC = comm.CreateParameter();
            voter_CNIC.ParameterName = "@voter_CNIC";
            voter_CNIC.Value = cnic;
            voter_CNIC.DbType = DbType.String;
            voter_CNIC.Size = 50;
            comm.Parameters.Add(voter_CNIC);

            DbParameter voter_DateOfBirth = comm.CreateParameter();
            voter_DateOfBirth.ParameterName = "@voter_DateOfBirth";
            voter_DateOfBirth.Value = dob;
            voter_DateOfBirth.DbType = DbType.Date;
            comm.Parameters.Add(voter_DateOfBirth);

            DbParameter voter_LastName = comm.CreateParameter();
            voter_LastName.ParameterName = "@voter_LastName";
            voter_LastName.Value = lName;
            voter_LastName.DbType = DbType.String;
            voter_LastName.Size = 50;
            comm.Parameters.Add(voter_LastName);

            DbParameter voter_FirstName = comm.CreateParameter();
            voter_FirstName.ParameterName = "@voter_FirstName";
            voter_FirstName.Value = fName;
            voter_FirstName.DbType = DbType.String;
            voter_FirstName.Size = 50;
            comm.Parameters.Add(voter_FirstName);

            DbParameter voter_Street = comm.CreateParameter();
            voter_Street.ParameterName = "@voter_Street";
            voter_Street.Value = street;
            voter_Street.DbType = DbType.String;
            voter_Street.Size = 50;
            comm.Parameters.Add(voter_Street);

            DbParameter voter_Mobile = comm.CreateParameter();
            voter_Mobile.ParameterName = "@voter_Mobile";
            voter_Mobile.Value = mobile;
            voter_Mobile.DbType = DbType.String;
            voter_Mobile.Size = 50;
            comm.Parameters.Add(voter_Mobile);

            DbParameter Image_Name = comm.CreateParameter();
            Image_Name.ParameterName = "@voter_ImageName";
            Image_Name.Value = imageName;
            Image_Name.DbType = DbType.String;
            Image_Name.Size = 500;
            comm.Parameters.Add(Image_Name);

            DbParameter Image_Type = comm.CreateParameter();
            Image_Type.ParameterName = "@voter_ImageType";
            Image_Type.Value = imageType;
            Image_Type.DbType = DbType.String;
            Image_Type.Size = 500;
            comm.Parameters.Add(Image_Type);

            DbParameter N_Image_Size = comm.CreateParameter();
            N_Image_Size.ParameterName = "@voter_ImageContent";
            N_Image_Size.Value = n_Image_Size;
            N_Image_Size.DbType = DbType.Binary;
            N_Image_Size.Size = n_Image_Size.Length;
            comm.Parameters.Add(N_Image_Size);

            DbParameter voter_BlockId = comm.CreateParameter();
            voter_BlockId.ParameterName = "@voter_BlockId";
            voter_BlockId.Value = blockId;
            voter_BlockId.DbType = DbType.Int32;
            comm.Parameters.Add(voter_BlockId);

            DbParameter voter_ThumbImpression = comm.CreateParameter();
            voter_ThumbImpression.ParameterName = "@voter_ThumbImpression";
            voter_ThumbImpression.Value = fingerprint;
            voter_ThumbImpression.DbType = DbType.String;
            comm.Parameters.Add(voter_ThumbImpression);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public bool UpdateVoter(int id, string fName, string lName, DateTime dob, string gender, string religion, int houseNo, string street, string mobile, string imageName, string imageType, byte[] n_Image_Size, int blockId, string fingerprint)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_UpdateSet_Voter";
            // execute the stored procedure and return the results

            DbParameter voter_Id = comm.CreateParameter();
            voter_Id.ParameterName = "@voter_Id";
            voter_Id.Value = id;
            voter_Id.DbType = DbType.Int32;
            comm.Parameters.Add(voter_Id);

            DbParameter voter_HouseNo = comm.CreateParameter();
            voter_HouseNo.ParameterName = "@voter_HouseNo";
            voter_HouseNo.Value = houseNo;
            voter_HouseNo.DbType = DbType.Int32;
            comm.Parameters.Add(voter_HouseNo);

            DbParameter voter_Religion = comm.CreateParameter();
            voter_Religion.ParameterName = "@voter_Religion";
            voter_Religion.Value = religion;
            voter_Religion.DbType = DbType.String;
            voter_Religion.Size = 50;
            comm.Parameters.Add(voter_Religion);

            DbParameter voter_Gender = comm.CreateParameter();
            voter_Gender.ParameterName = "@voter_Gender";
            voter_Gender.Value = gender;
            voter_Gender.DbType = DbType.String;
            voter_Gender.Size = 50;
            comm.Parameters.Add(voter_Gender);

            DbParameter voter_DateOfBirth = comm.CreateParameter();
            voter_DateOfBirth.ParameterName = "@voter_DateOfBirth";
            voter_DateOfBirth.Value = dob;
            voter_DateOfBirth.DbType = DbType.Date;
            comm.Parameters.Add(voter_DateOfBirth);

            DbParameter voter_LastName = comm.CreateParameter();
            voter_LastName.ParameterName = "@voter_LastName";
            voter_LastName.Value = lName;
            voter_LastName.DbType = DbType.String;
            voter_LastName.Size = 50;
            comm.Parameters.Add(voter_LastName);

            DbParameter voter_FirstName = comm.CreateParameter();
            voter_FirstName.ParameterName = "@voter_FirstName";
            voter_FirstName.Value = fName;
            voter_FirstName.DbType = DbType.String;
            voter_FirstName.Size = 50;
            comm.Parameters.Add(voter_FirstName);

            DbParameter voter_Street = comm.CreateParameter();
            voter_Street.ParameterName = "@voter_Street";
            voter_Street.Value = street;
            voter_Street.DbType = DbType.String;
            voter_Street.Size = 50;
            comm.Parameters.Add(voter_Street);

            DbParameter voter_Mobile = comm.CreateParameter();
            voter_Mobile.ParameterName = "@voter_Mobile";
            voter_Mobile.Value = mobile;
            voter_Mobile.DbType = DbType.String;
            voter_Mobile.Size = 50;
            comm.Parameters.Add(voter_Mobile);

            DbParameter Image_Name = comm.CreateParameter();
            Image_Name.ParameterName = "@voter_ImageName";
            Image_Name.Value = imageName;
            Image_Name.DbType = DbType.String;
            Image_Name.Size = 500;
            comm.Parameters.Add(Image_Name);

            DbParameter Image_Type = comm.CreateParameter();
            Image_Type.ParameterName = "@voter_ImageType";
            Image_Type.Value = imageType;
            Image_Type.DbType = DbType.String;
            Image_Type.Size = 500;
            comm.Parameters.Add(Image_Type);

            DbParameter N_Image_Size = comm.CreateParameter();
            N_Image_Size.ParameterName = "@voter_ImageContent";
            N_Image_Size.Value = n_Image_Size;
            N_Image_Size.DbType = DbType.Binary;
            N_Image_Size.Size = n_Image_Size.Length;
            comm.Parameters.Add(N_Image_Size);

            DbParameter voter_ThumbImpression = comm.CreateParameter();
            voter_ThumbImpression.ParameterName = "@voter_ThumbImpression";
            voter_ThumbImpression.Value = fingerprint;
            voter_ThumbImpression.DbType = DbType.String;
            comm.Parameters.Add(voter_ThumbImpression);

            DbParameter voter_BlockId = comm.CreateParameter();
            voter_BlockId.ParameterName = "@voter_BlockId";
            voter_BlockId.Value = blockId;
            voter_BlockId.DbType = DbType.Int32;
            comm.Parameters.Add(voter_BlockId);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public bool DeleteVoter(int Id)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_DeleteFrom_Voter";
            // execute the stored procedure and return the results

            DbParameter id = comm.CreateParameter();
            id.ParameterName = "@voter_Id";
            id.Value = Id;
            id.DbType = DbType.Int32;
            comm.Parameters.Add(id);

            // result will represent the number of changed rows
            int result = -1;
            try
            {
                // execute the stored procedure
                result = GenericDataAccess.ExecuteNonQuery(comm);
            }
            catch
            {
                // any errors are logged in GenericDataAccess, we ignore them here
            }
            // result will be 1 in case of success 
            return (result >= 1);
        }

        public DataTable GetVoterByCnic(string cnic)
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Voter_ByCnic";
            // execute the stored procedure and return the results

            DbParameter CNIC = comm.CreateParameter();
            CNIC.ParameterName = "@cnic";
            CNIC.Value = cnic;
            CNIC.DbType = DbType.String;
            CNIC.Size = 50;
            comm.Parameters.Add(CNIC);

            return GenericDataAccess.ExecuteReader(comm);
        }

        public DataTable GetVoters()
        {
            // get a configured DbCommand object
            DbCommand comm = GenericDataAccess.CreateCommand();
            // set the stored procedure name
            comm.CommandText = "sp_SelectFrom_Voter";
            // execute the stored procedure and return the results

            return GenericDataAccess.ExecuteReader(comm);
        }

    }
}
